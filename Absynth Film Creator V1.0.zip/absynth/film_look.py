"""
@author: Absynth
@title: Absynth Film Look Creator v1.0
@nickname: Absynth Film Look Creator v1.0
@description: A node to apply various color grading adjustments and LUTs to create a film look.
"""

import torch
import cv2
import numpy as np
import os
import json
import time
import re

# --- Robust Preset Management ---

current_dir = os.path.dirname(os.path.realpath(__file__))
presets_file = os.path.join(current_dir, "film_look_presets.json")
lut_dir = os.path.join(current_dir, "luts")

def get_presets():
    """Directly loads and returns presets from the JSON file."""
    default_presets = {
        "Custom": {},
        # --- Film Emulations ---
        "Vintage": {"brightness": 10.0, "contrast": 0.9, "saturation": 0.8, "temperature": 20.0, "tint": -10.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.0, "clarity": 0.1, "bloom": 0.0, "vignette": 0.2, "chromatic_aberration": 1.0, "hue_shift": 0.0, "shadow_tint_color": "#000000", "shadow_tint_intensity": 0.0, "highlight_tint_color": "#FFFFFF", "highlight_tint_intensity": 0.0, "halation_intensity": 0.0},
        "Kodachrome": {"brightness": 5.0, "contrast": 1.4, "saturation": 1.2, "temperature": 12.0, "tint": -5.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.1, "clarity": 0.15, "bloom": 0.0, "vignette": 0.1, "chromatic_aberration": 0.5, "hue_shift": 0.0, "shadow_tint_color": "#001005", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#FFF0E0", "highlight_tint_intensity": 0.05, "halation_intensity": 0.1},
        "Portra 400": {"brightness": 8.0, "contrast": 1.15, "saturation": 1.1, "temperature": 20.0, "tint": -10.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.05, "clarity": 0.1, "bloom": 0.0, "vignette": 0.0, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#000000", "shadow_tint_intensity": 0.0, "highlight_tint_color": "#FFFFFF", "highlight_tint_intensity": 0.0, "halation_intensity": 0.0},
        "Fuji Velvia": {"brightness": -5.0, "contrast": 1.3, "saturation": 1.4, "temperature": -10.0, "tint": 15.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.15, "clarity": 0.2, "bloom": 0.0, "vignette": 0.0, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#001500", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#F0FFF0", "highlight_tint_intensity": 0.0, "halation_intensity": 0.05},
        "Agfa Vista": {"brightness": 10.0, "contrast": 1.2, "saturation": 1.1, "temperature": 25.0, "tint": -15.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.0, "clarity": 0.1, "bloom": 0.0, "vignette": 0.0, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#000000", "shadow_tint_intensity": 0.0, "highlight_tint_color": "#FFFFFF", "highlight_tint_intensity": 0.0, "halation_intensity": 0.0},
        "Polaroid": {"brightness": 20.0, "contrast": 0.8, "saturation": 0.9, "temperature": 15.0, "tint": 10.0, "grain_intensity": 0.00, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.0, "clarity": 0.0, "bloom": 0.15, "vignette": 0.3, "chromatic_aberration": 3.0, "hue_shift": 0.0, "shadow_tint_color": "#101000", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#FFFFE0", "highlight_tint_intensity": 0.1, "halation_intensity": 0.0},
        "Daguerreotype": {"brightness": 5.0, "contrast": 1.3, "saturation": 0.1, "temperature": -15.0, "tint": 0.0, "grain_intensity": 0.00, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.0, "clarity": 0.15, "bloom": 0.0, "vignette": 0.4, "chromatic_aberration": 1.0, "hue_shift": 0.0, "shadow_tint_color": "#101020", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#E0E0FF", "highlight_tint_intensity": 0.05, "halation_intensity": 0.0},

        # --- Cyberpunk Looks ---
        "Neon Noir": {"brightness": -5.0, "contrast": 1.6, "saturation": 1.3, "temperature": -25.0, "tint": -10.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.2, "clarity": 0.15, "bloom": 0.3, "vignette": 0.2, "chromatic_aberration": 2.0, "hue_shift": -10.0, "shadow_tint_color": "#200030", "shadow_tint_intensity": 0.2, "highlight_tint_color": "#E0FFFF", "highlight_tint_intensity": 0.1, "halation_intensity": 0.2},
        "Blade Runner Blues": {"brightness": -10.0, "contrast": 1.7, "saturation": 0.9, "temperature": -35.0, "tint": 5.0, "grain_intensity": 0.00, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.1, "clarity": 0.2, "bloom": 0.2, "vignette": 0.3, "chromatic_aberration": 1.5, "hue_shift": 15.0, "shadow_tint_color": "#001525", "shadow_tint_intensity": 0.25, "highlight_tint_color": "#A0D0FF", "highlight_tint_intensity": 0.15, "halation_intensity": 0.15},
        "Matrix Green": {"brightness": -20.0, "contrast": 1.6, "saturation": 0.9, "temperature": -60.0, "tint": 50.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.1, "clarity": 0.1, "bloom": 0.1, "vignette": 0.2, "chromatic_aberration": 1.0, "hue_shift": 55.0, "shadow_tint_color": "#001000", "shadow_tint_intensity": 0.4, "highlight_tint_color": "#D0FFD0", "highlight_tint_intensity": 0.1, "halation_intensity": 0.0},
        "Ghost in the Shell": {"brightness": 0.0, "contrast": 1.2, "saturation": 0.8, "temperature": -20.0, "tint": 10.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": -0.1, "clarity": 0.25, "bloom": 0.25, "vignette": 0.1, "chromatic_aberration": 0.5, "hue_shift": 0.0, "shadow_tint_color": "#050515", "shadow_tint_intensity": 0.15, "highlight_tint_color": "#E0E8FF", "highlight_tint_intensity": 0.1, "halation_intensity": 0.1},
        "Post-Apocalyptic": {"brightness": -5.0, "contrast": 1.4, "saturation": 0.6, "temperature": 30.0, "tint": 20.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": -0.2, "clarity": 0.3, "bloom": 0.0, "vignette": 0.3, "chromatic_aberration": 1.0, "hue_shift": 0.0, "shadow_tint_color": "#100500", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#FFE8D0", "highlight_tint_intensity": 0.0, "halation_intensity": 0.0},
        
        # --- Creative & Cinematic ---
        "Hollywood Teal & Orange": {"brightness": 0.0, "contrast": 1.1, "saturation": 1.0, "temperature": 0.0, "tint": 0.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.0, "clarity": 0.1, "bloom": 0.0, "vignette": 0.0, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#00334d", "shadow_tint_intensity": 0.3, "highlight_tint_color": "#ff9900", "highlight_tint_intensity": 0.15, "halation_intensity": 0.0},
        "Golden Hour": {"brightness": 10.0, "contrast": 1.1, "saturation": 1.1, "temperature": 40.0, "tint": -15.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.1, "clarity": 0.05, "bloom": 0.4, "vignette": 0.0, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#000000", "shadow_tint_intensity": 0.0, "highlight_tint_color": "#FFFFFF", "highlight_tint_intensity": 0.0, "halation_intensity": 0.2},
        "Moonlight": {"brightness": -20.0, "contrast": 1.3, "saturation": 0.8, "temperature": -60.0, "tint": 0.0, "grain_intensity": 0.00, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.0, "clarity": 0.15, "bloom": 0.2, "vignette": 0.3, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#050015", "shadow_tint_intensity": 0.2, "highlight_tint_color": "#E0E8FF", "highlight_tint_intensity": 0.1, "halation_intensity": 0.0},
        "Dreamy Haze": {"brightness": 15.0, "contrast": 0.9, "saturation": 1.0, "temperature": 10.0, "tint": -10.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.0, "clarity": -0.2, "bloom": 0.6, "vignette": 0.0, "chromatic_aberration": 5.0, "hue_shift": 0.0, "shadow_tint_color": "#000000", "shadow_tint_intensity": 0.0, "highlight_tint_color": "#FFFFFF", "highlight_tint_intensity": 0.0, "halation_intensity": 0.3},
        "Gritty Urban": {"brightness": -10.0, "contrast": 1.6, "saturation": 0.7, "temperature": -10.0, "tint": 5.0, "grain_intensity": 0.00, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": -0.1, "clarity": 0.35, "bloom": 0.0, "vignette": 0.3, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#000510", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#FFFFFF", "highlight_tint_intensity": 0.0, "halation_intensity": 0.0},
        "Infrared": {"brightness": 0.0, "contrast": 1.4, "saturation": 1.5, "temperature": 0.0, "tint": 0.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.2, "clarity": 0.1, "bloom": 0.1, "vignette": 0.0, "chromatic_aberration": 0.0, "hue_shift": 120.0, "shadow_tint_color": "#000000", "shadow_tint_intensity": 0.0, "highlight_tint_color": "#FFFFFF", "highlight_tint_intensity": 0.0, "halation_intensity": 0.0},
        "Cross-Processed": {"brightness": -5.0, "contrast": 1.5, "saturation": 1.3, "temperature": -20.0, "tint": 30.0, "grain_intensity": 0.00, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.1, "clarity": 0.1, "bloom": 0.0, "vignette": 0.1, "chromatic_aberration": 2.0, "hue_shift": 0.0, "shadow_tint_color": "#002010", "shadow_tint_intensity": 0.2, "highlight_tint_color": "#FFFFD0", "highlight_tint_intensity": 0.1, "halation_intensity": 0.0},
        "Solarized": {"brightness": 0.0, "contrast": 2.0, "saturation": 1.0, "temperature": 0.0, "tint": 0.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.0, "clarity": 0.0, "bloom": 0.0, "vignette": 0.0, "chromatic_aberration": 0.0, "hue_shift": 180.0, "shadow_tint_color": "#000000", "shadow_tint_intensity": 0.0, "highlight_tint_color": "#FFFFFF", "highlight_tint_intensity": 0.0, "halation_intensity": 0.0},
        "Inferno": {"brightness": 5.0, "contrast": 1.6, "saturation": 1.5, "temperature": 50.0, "tint": -20.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.3, "clarity": 0.15, "bloom": 0.3, "vignette": 0.2, "chromatic_aberration": 1.0, "hue_shift": 0.0, "shadow_tint_color": "#300000", "shadow_tint_intensity": 0.2, "highlight_tint_color": "#FFD000", "highlight_tint_intensity": 0.1, "halation_intensity": 0.2},
        "Arctic Night": {"brightness": -15.0, "contrast": 1.4, "saturation": 0.9, "temperature": -70.0, "tint": 10.0, "grain_intensity": 0.00, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.0, "clarity": 0.15, "bloom": 0.2, "vignette": 0.3, "chromatic_aberration": 2.0, "hue_shift": 0.0, "shadow_tint_color": "#000515", "shadow_tint_intensity": 0.2, "highlight_tint_color": "#C0E0FF", "highlight_tint_intensity": 0.1, "halation_intensity": 0.0},
        "Wasteland": {"brightness": 10.0, "contrast": 1.3, "saturation": 0.5, "temperature": 35.0, "tint": 15.0, "grain_intensity": 0.00, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": -0.3, "clarity": 0.35, "bloom": 0.0, "vignette": 0.2, "chromatic_aberration": 1.0, "hue_shift": 0.0, "shadow_tint_color": "#151000", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#FFF0C0", "highlight_tint_intensity": 0.0, "halation_intensity": 0.0},
        "Pastel Dream": {"brightness": 20.0, "contrast": 0.8, "saturation": 1.2, "temperature": 10.0, "tint": -15.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.1, "clarity": 0.0, "bloom": 0.5, "vignette": 0.0, "chromatic_aberration": 4.0, "hue_shift": 5.0, "shadow_tint_color": "#100010", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#FFD0FF", "highlight_tint_intensity": 0.1, "halation_intensity": 0.2},
        "Emerald City": {"brightness": -5.0, "contrast": 1.2, "saturation": 1.1, "temperature": -30.0, "tint": 30.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.1, "clarity": 0.1, "bloom": 0.1, "vignette": 0.1, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#001505", "shadow_tint_intensity": 0.25, "highlight_tint_color": "#D0FFE0", "highlight_tint_intensity": 0.15, "halation_intensity": 0.0},
        "Crimson Peak": {"brightness": -10.0, "contrast": 1.5, "saturation": 1.2, "temperature": 20.0, "tint": -30.0, "grain_intensity": 0.00, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.1, "clarity": 0.15, "bloom": 0.0, "vignette": 0.3, "chromatic_aberration": 1.0, "hue_shift": 0.0, "shadow_tint_color": "#200000", "shadow_tint_intensity": 0.2, "highlight_tint_color": "#FFD0D0", "highlight_tint_intensity": 0.1, "halation_intensity": 0.1},
        "Oppenheimer": {"brightness": -5.0, "contrast": 1.6, "saturation": 0.2, "temperature": 10.0, "tint": 0.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": -0.1, "clarity": 0.25, "bloom": 0.0, "vignette": 0.2, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#000000", "shadow_tint_intensity": 0.0, "highlight_tint_color": "#FFFFFF", "highlight_tint_intensity": 0.0, "halation_intensity": 0.0},
        "Dune": {"brightness": 10.0, "contrast": 1.4, "saturation": 0.4, "temperature": 25.0, "tint": 10.0, "grain_intensity": 0.00, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": -0.2, "clarity": 0.2, "bloom": 0.1, "vignette": 0.1, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#100800", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#FFF5E0", "highlight_tint_intensity": 0.05, "halation_intensity": 0.1},
        "Joker": {"brightness": -8.0, "contrast": 1.3, "saturation": 1.1, "temperature": -15.0, "tint": 20.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.0, "clarity": 0.15, "bloom": 0.0, "vignette": 0.2, "chromatic_aberration": 1.0, "hue_shift": 0.0, "shadow_tint_color": "#001510", "shadow_tint_intensity": 0.2, "highlight_tint_color": "#F0FFF0", "highlight_tint_intensity": 0.0, "halation_intensity": 0.0},
        "Wes Anderson": {"brightness": 15.0, "contrast": 1.1, "saturation": 1.2, "temperature": 30.0, "tint": -20.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.2, "clarity": 0.1, "bloom": 0.0, "vignette": 0.0, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#000000", "shadow_tint_intensity": 0.0, "highlight_tint_color": "#FFFFD0", "highlight_tint_intensity": 0.1, "halation_intensity": 0.0},
        "Mad Max Fury Road": {"brightness": 0.0, "contrast": 1.8, "saturation": 1.6, "temperature": 20.0, "tint": -10.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.1, "clarity": 0.35, "bloom": 0.0, "vignette": 0.2, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#002030", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#FFAA00", "highlight_tint_intensity": 0.1, "halation_intensity": 0.0},
        "Amelie": {"brightness": 10.0, "contrast": 1.2, "saturation": 1.3, "temperature": 20.0, "tint": 15.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.1, "clarity": 0.1, "bloom": 0.1, "vignette": 0.1, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#100000", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#FFFFD0", "highlight_tint_intensity": 0.1, "halation_intensity": 0.1},
        "Sin City": {"brightness": -20.0, "contrast": 2.5, "saturation": 0.0, "temperature": 0.0, "tint": 0.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.0, "clarity": 0.4, "bloom": 0.0, "vignette": 0.4, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#000000", "shadow_tint_intensity": 0.0, "highlight_tint_color": "#FFFFFF", "highlight_tint_intensity": 0.0, "halation_intensity": 0.0},
        "300": {"brightness": -10.0, "contrast": 1.7, "saturation": 0.6, "temperature": 25.0, "tint": -10.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": -0.1, "clarity": 0.3, "bloom": 0.0, "vignette": 0.3, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#100500", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#FFD0A0", "highlight_tint_intensity": 0.05, "halation_intensity": 0.0},
        "Lomo": {"brightness": 10.0, "contrast": 1.4, "saturation": 1.5, "temperature": 0.0, "tint": 0.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.2, "clarity": 0.0, "bloom": 0.0, "vignette": 0.5, "chromatic_aberration": 5.0, "hue_shift": 0.0, "shadow_tint_color": "#000020", "shadow_tint_intensity": 0.2, "highlight_tint_color": "#FFFF00", "highlight_tint_intensity": 0.1, "halation_intensity": 0.0},
        "Autumn Warmth": {"brightness": 5.0, "contrast": 1.1, "saturation": 1.1, "temperature": 35.0, "tint": -10.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": 0.1, "clarity": 0.1, "bloom": 0.2, "vignette": 0.1, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#100500", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#FFE0B0", "highlight_tint_intensity": 0.1, "halation_intensity": 0.1},
        "Winter Chill": {"brightness": 10.0, "contrast": 1.1, "saturation": 0.9, "temperature": -30.0, "tint": 5.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": -0.05, "clarity": 0.1, "bloom": 0.1, "vignette": 0.0, "chromatic_aberration": 0.0, "hue_shift": 0.0, "shadow_tint_color": "#000510", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#D0E0FF", "highlight_tint_intensity": 0.1, "halation_intensity": 0.0},
        "Silent Hill Fog": {"brightness": 5.0, "contrast": 1.2, "saturation": 0.3, "temperature": -10.0, "tint": 10.0, "grain_intensity": 0.0, "lut_file": "None", "lut_intensity": 1.0, "enable_creative_effects": True, "vibrance": -0.2, "clarity": -0.1, "bloom": 0.3, "vignette": 0.2, "chromatic_aberration": 1.0, "hue_shift": 0.0, "shadow_tint_color": "#101010", "shadow_tint_intensity": 0.1, "highlight_tint_color": "#E0E0E0", "highlight_tint_intensity": 0.0, "halation_intensity": 0.0},
    }
    if os.path.exists(presets_file):
        try:
            with open(presets_file, 'r', encoding='utf-8') as f:
                saved_presets = json.load(f)
                default_presets.update(saved_presets)
        except Exception as e:
            print(f"Film Look Creator: ERROR reading presets file: {e}")
    return default_presets

def save_presets(presets_dict):
    """Directly saves a dictionary of presets to the JSON file."""
    try:
        with open(presets_file, 'w', encoding='utf-8') as f:
            json.dump(presets_dict, f, indent=4)
        return True, None
    except Exception as e:
        print(f"Film Look Creator: ERROR writing to presets file: {e}")
        return False, str(e)

def hex_to_bgr(hex_color):
    """Safely converts a hex color string to a BGR tuple."""
    hex_color = str(hex_color).lstrip('#')
    if not re.match(r'^[0-9a-fA-F]{6}$', hex_color):
        return (0, 0, 0)
    return tuple(int(hex_color[i:i+2], 16) for i in (4, 2, 0))

def apply_3d_lut(image, lut_table, intensity):
    if intensity == 0: return image
    original_image = image.copy()
    lut_size = lut_table.shape[0]
    b, g, r = cv2.split(image)
    scaled_r, scaled_g, scaled_b = r * (lut_size - 1), g * (lut_size - 1), b * (lut_size - 1)
    r_int, g_int, b_int = scaled_r.astype(np.int32), scaled_g.astype(np.int32), scaled_b.astype(np.int32)
    r_frac, g_frac, b_frac = scaled_r - r_int, scaled_g - g_int, scaled_b - b_int
    r_int, g_int, b_int = np.clip(r_int, 0, lut_size - 2), np.clip(g_int, 0, lut_size - 2), np.clip(b_int, 0, lut_size - 2)
    c000, c001 = lut_table[b_int, g_int, r_int], lut_table[b_int, g_int, r_int + 1]
    c010, c011 = lut_table[b_int, g_int + 1, r_int], lut_table[b_int, g_int + 1, r_int + 1]
    c100, c101 = lut_table[b_int + 1, g_int, r_int], lut_table[b_int + 1, g_int, r_int + 1]
    c110, c111 = lut_table[b_int + 1, g_int + 1, r_int], lut_table[b_int + 1, g_int + 1, r_int + 1]
    r_frac_3d, g_frac_3d, b_frac_3d = r_frac[..., np.newaxis], g_frac[..., np.newaxis], b_frac[..., np.newaxis]
    c00 = c000 * (1 - r_frac_3d) + c001 * r_frac_3d
    c01 = c010 * (1 - r_frac_3d) + c011 * r_frac_3d
    c10 = c100 * (1 - r_frac_3d) + c101 * r_frac_3d
    c11 = c110 * (1 - r_frac_3d) + c111 * r_frac_3d
    c0 = c00 * (1 - g_frac_3d) + c01 * g_frac_3d
    c1 = c10 * (1 - g_frac_3d) + c11 * g_frac_3d
    interpolated = c0 * (1 - b_frac_3d) + c1 * b_frac_3d
    lut_applied_image = interpolated[..., ::-1].astype(np.float32)
    return cv2.addWeighted(original_image, 1.0 - intensity, lut_applied_image, intensity, 0)


class FilmLookCreator:

    @classmethod
    def INPUT_TYPES(cls):
        presets = get_presets()
        preset_names = list(presets.keys())
        deletable_presets = ["None"] + [p for p in preset_names if p != "Custom"]
        if not os.path.exists(lut_dir): os.makedirs(lut_dir)
        lut_files = ["None"] + [f for f in os.listdir(lut_dir) if f.lower().endswith('.cube')]
        
        return {
            "required": {
                "image": ("IMAGE",),
                "preset": (preset_names,),
                "brightness": ("FLOAT", {"default": 0.0, "min": -100.0, "max": 100.0, "step": 0.1, "display": "slider"}),
                "contrast": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 3.0, "step": 0.01, "display": "slider"}),
                "saturation": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 3.0, "step": 0.01, "display": "slider"}),
                "temperature": ("FLOAT", {"default": 0.0, "min": -100.0, "max": 100.0, "step": 0.1, "display": "slider"}),
                "tint": ("FLOAT", {"default": 0.0, "min": -100.0, "max": 100.0, "step": 0.1, "display": "slider"}),
                "grain_intensity": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 1.0, "step": 0.01, "display": "slider"}),
                "lut_file": (lut_files,),
                "lut_intensity": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 1.0, "step": 0.01, "display": "slider"}),
            },
            "optional": {
                "save_preset_name": ("STRING", {"default": ""}),
                "delete_preset": (deletable_presets, ),
                "ignore_settings": ("BOOLEAN", {"default": False}),
                "enable_creative_effects": ("BOOLEAN", {"default": False}),
                "vibrance": ("FLOAT", {"default": 0.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider"}),
                "hue_shift": ("FLOAT", {"default": 0.0, "min": -180.0, "max": 180.0, "step": 1.0, "display": "slider"}),
                "clarity": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 1.0, "step": 0.01, "display": "slider"}),
                "bloom": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 1.0, "step": 0.01, "display": "slider"}),
                "vignette": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 1.0, "step": 0.01, "display": "slider"}),
                "chromatic_aberration": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 20.0, "step": 0.1, "display": "slider"}),
                "shadow_tint_color": ("STRING", {"default": "#000000"}),
                "shadow_tint_intensity": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 1.0, "step": 0.01, "display": "slider"}),
                "highlight_tint_color": ("STRING", {"default": "#FFFFFF"}),
                "highlight_tint_intensity": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 1.0, "step": 0.01, "display": "slider"}),
                "halation_intensity": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 1.0, "step": 0.01, "display": "slider"}),
                 "info": ("STRING", {"default": """NOTE: Presets only save after you click Run. Presets only update after you restart Comfy. You can`t edit all presets right now - you must set preset to custom, or edit them in the json file.
           (       )    )           )   
   (      (  )\ ) ( /( ( /(  * ) ( /(   
   )\   ( )\(()/( )\()))\()` )  /( )\())  
((((_)( )((_)/(_)((_)\((_)\ ( )(_)((_)\   
 )\ _ )((_)_(_)) ___ ((_)_((_(_(_()) _((_)  
 (_)_\(_ | _ \  /    \ \ / / | \| | |_   _| | || |  
  / _ \  | _ |  \__   \ V /  | .` |   | |   | __ |  
 /_/ \_\ |___/  ___/   |_|   |_|\_|   |_|   |_||_| ©2025  
                                          """, "multiline": True}),
            }
        }

    RETURN_TYPES = ("IMAGE", "STRING")
    RETURN_NAMES = ("image", "status")
    FUNCTION = "apply_film_look"
    CATEGORY = "absynth/Color"
    
    @classmethod
    def IS_CHANGED(cls, **kwargs):
        # This forces the node to re-run every time any input changes.
        return float("nan")

    def apply_film_look(self, image, preset, brightness, contrast, saturation, temperature, tint, grain_intensity, lut_file, lut_intensity, save_preset_name="", delete_preset="None", ignore_settings=False, enable_creative_effects=False, vibrance=0.0, hue_shift=0.0, clarity=0.0, bloom=0.0, vignette=0.0, chromatic_aberration=0.0, shadow_tint_color="#000000", shadow_tint_intensity=0.0, highlight_tint_color="#FFFFFF", highlight_tint_intensity=0.0, halation_intensity=0.0, info=""):
        
        status_message = f"Executed. Ignore Settings = {ignore_settings}"

        if ignore_settings:
            status_message = "Settings IGNORED. Bypassing all effects."
            return (image, status_message)

        current_presets = get_presets()
        
        if delete_preset != "None":
            if delete_preset in current_presets:
                del current_presets[delete_preset]
                success, error_msg = save_presets(current_presets)
                status_message = f"Deleted '{delete_preset}'. Restart needed." if success else f"ERROR deleting: {error_msg}"
            else:
                status_message = f"Preset '{delete_preset}' not found."

        elif preset != "Custom" and preset in current_presets:
            p = current_presets[preset]
            brightness, contrast, saturation, temperature, tint, grain_intensity, lut_file, lut_intensity, enable_creative_effects, vibrance, hue_shift, clarity, bloom, vignette, chromatic_aberration, shadow_tint_color, shadow_tint_intensity, highlight_tint_color, highlight_tint_intensity, halation_intensity = (
                p.get("brightness", brightness), p.get("contrast", contrast), p.get("saturation", saturation),
                p.get("temperature", temperature), p.get("tint", tint), p.get("grain_intensity", grain_intensity),
                p.get("lut_file", lut_file), p.get("lut_intensity", lut_intensity),
                p.get("enable_creative_effects", enable_creative_effects), p.get("vibrance", vibrance), p.get("hue_shift", hue_shift), p.get("clarity", clarity),
                p.get("bloom", bloom), p.get("vignette", vignette), p.get("chromatic_aberration", chromatic_aberration),
                p.get("shadow_tint_color", shadow_tint_color), p.get("shadow_tint_intensity", shadow_tint_intensity), p.get("highlight_tint_color", highlight_tint_color), p.get("highlight_tint_intensity", highlight_tint_intensity), p.get("halation_intensity", halation_intensity)
            )
        
        elif save_preset_name.strip() and save_preset_name.strip().lower() != "custom":
            clean_preset_name = save_preset_name.strip()
            current_settings = { "brightness": brightness, "contrast": contrast, "saturation": saturation, "temperature": temperature, "tint": tint, "grain_intensity": grain_intensity, "lut_file": lut_file, "lut_intensity": lut_intensity, "enable_creative_effects": enable_creative_effects, "vibrance": vibrance, "hue_shift": hue_shift, "clarity": clarity, "bloom": bloom, "vignette": vignette, "chromatic_aberration": chromatic_aberration, "shadow_tint_color": shadow_tint_color, "shadow_tint_intensity": shadow_tint_intensity, "highlight_tint_color": highlight_tint_color, "highlight_tint_intensity": highlight_tint_intensity, "halation_intensity": halation_intensity }
            current_presets[clean_preset_name] = current_settings
            success, error_msg = save_presets(current_presets)
            status_message = f"Saved '{clean_preset_name}'. Restart needed." if success else f"ERROR saving: {error_msg}"
        
        lut_table = None
        if lut_file != "None":
            lut_path = os.path.join(lut_dir, lut_file)
            if os.path.exists(lut_path):
                try:
                    with open(lut_path, 'r') as f: lines = [line.strip() for line in f if line.strip() and not line.startswith('#')]
                    size = 0
                    for line in lines:
                        if line.upper().startswith('LUT_3D_SIZE'): size = int(line.split()[1]); break
                    if size > 0:
                        data_start_index = next((i for i, line in enumerate(lines) if len(line.split()) == 3 and all(c in '0123456789.eE-+' for c in line.replace(' ', ''))), -1)
                        if data_start_index != -1:
                            lut_data_lines = lines[data_start_index : data_start_index + (size**3)]
                            lut_data = [list(map(float, l.split())) for l in lut_data_lines]
                            if len(lut_data) == (size**3): lut_table = np.array(lut_data, dtype=np.float32).reshape(size, size, size, 3); status_message = f"Loaded LUT: {lut_file}"
                            else: status_message = f"ERROR: LUT data size mismatch"
                        else: status_message = "ERROR: Could not find LUT data."
                except Exception as e: status_message = f"ERROR loading LUT: {e}"
            else: status_message = f"LUT file not found: {lut_file}"

        image_np = image.cpu().numpy()
        processed_images = []
        
        for i in range(image_np.shape[0]):
            img_slice_rgb = image_np[i].astype(np.float32)
            adjusted_img = cv2.cvtColor(img_slice_rgb, cv2.COLOR_RGB2BGR)

            if lut_table is not None: adjusted_img = apply_3d_lut(adjusted_img, lut_table, lut_intensity)

            adjusted_img = np.clip(adjusted_img * float(contrast) + (float(brightness) / 255.0), 0.0, 1.0)

            blue, green, red = cv2.split(adjusted_img)
            temp_val, tint_val = float(temperature) / 255.0, float(tint) / 255.0
            if temp_val > 0: red = np.clip(red + temp_val, 0.0, 1.0)
            elif temp_val < 0: blue = np.clip(blue - temp_val, 0.0, 1.0)
            if tint_val > 0: green = np.clip(green + tint_val, 0.0, 1.0)
            elif tint_val < 0: red, blue = np.clip(red - tint_val * 0.5, 0.0, 1.0), np.clip(blue - tint_val * 0.5, 0.0, 1.0)
            adjusted_img = cv2.merge((blue, green, red))

            temp_uint8 = (np.clip(adjusted_img, 0.0, 1.0) * 255).astype(np.uint8)
            hsv_image = cv2.cvtColor(temp_uint8, cv2.COLOR_BGR2HSV)
            s_channel = hsv_image[:,:,1].astype(np.float32)
            s_channel *= float(saturation)
            hsv_image[:,:,1] = np.clip(s_channel, 0, 255).astype(np.uint8)
            adjusted_img = cv2.cvtColor(hsv_image, cv2.COLOR_HSV2BGR).astype(np.float32) / 255.0

            if enable_creative_effects:
                # Split Toning
                if shadow_tint_intensity > 0 or highlight_tint_intensity > 0:
                    lab = cv2.cvtColor((adjusted_img * 255).astype(np.uint8), cv2.COLOR_BGR2Lab)
                    l, a, b = cv2.split(lab)
                    l_float = l.astype(np.float32) / 255.0

                    if shadow_tint_intensity > 0:
                        shadow_color_bgr = np.uint8([[hex_to_bgr(shadow_tint_color)]])
                        shadow_color_lab = cv2.cvtColor(shadow_color_bgr, cv2.COLOR_BGR2Lab)[0][0]
                        shadow_mask = np.clip(1.0 - l_float, 0.0, 1.0) ** 2.0
                        a = np.clip(a + (shadow_color_lab[1] - 128) * shadow_mask * shadow_tint_intensity, 0, 255).astype(np.uint8)
                        b = np.clip(b + (shadow_color_lab[2] - 128) * shadow_mask * shadow_tint_intensity, 0, 255).astype(np.uint8)
                    
                    if highlight_tint_intensity > 0:
                        highlight_color_bgr = np.uint8([[hex_to_bgr(highlight_tint_color)]])
                        highlight_color_lab = cv2.cvtColor(highlight_color_bgr, cv2.COLOR_BGR2Lab)[0][0]
                        highlight_mask = l_float ** 2.0
                        a = np.clip(a + (highlight_color_lab[1] - 128) * highlight_mask * highlight_tint_intensity, 0, 255).astype(np.uint8)
                        b = np.clip(b + (highlight_color_lab[2] - 128) * highlight_mask * highlight_tint_intensity, 0, 255).astype(np.uint8)

                    adjusted_img = cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_Lab2BGR).astype(np.float32) / 255.0

                if vibrance != 0:
                    hsv = cv2.cvtColor((adjusted_img * 255).astype(np.uint8), cv2.COLOR_BGR2HSV)
                    s = hsv[:, :, 1].astype(np.float32)
                    s = np.clip(s + (s * (1 - s/255) * vibrance), 0, 255)
                    hsv[:, :, 1] = s.astype(np.uint8)
                    adjusted_img = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR).astype(np.float32) / 255.0
                
                if hue_shift != 0:
                    hsv = cv2.cvtColor((adjusted_img * 255).astype(np.uint8), cv2.COLOR_BGR2HSV)
                    h = hsv[:, :, 0].astype(np.int32)
                    h = (h + int(hue_shift)) % 180
                    hsv[:, :, 0] = h.astype(np.uint8)
                    adjusted_img = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR).astype(np.float32) / 255.0

                if clarity > 0:
                    blurred = cv2.GaussianBlur(adjusted_img, (0, 0), 3)
                    adjusted_img = cv2.addWeighted(adjusted_img, 1.0 + clarity, blurred, -clarity, 0)
                
                # Halation
                if halation_intensity > 0:
                    gray = cv2.cvtColor((adjusted_img * 255).astype(np.uint8), cv2.COLOR_BGR2GRAY)
                    _, threshold = cv2.threshold(gray, 220, 255, cv2.THRESH_BINARY)
                    blur = cv2.GaussianBlur(threshold, (0,0), 25)
                    blur = cv2.cvtColor(blur, cv2.COLOR_GRAY2BGR).astype(np.float32) / 255.0
                    halation_color = np.full_like(adjusted_img, (0.1, 0.1, 1.0)) # Reddish glow
                    halation_layer = halation_color * blur
                    adjusted_img = cv2.addWeighted(adjusted_img, 1.0, halation_layer, halation_intensity, 0)
                
                if bloom > 0:
                    blur = cv2.GaussianBlur(adjusted_img, (0,0), 20)
                    adjusted_img = cv2.addWeighted(adjusted_img, 1.0, blur, bloom, 0)
                
                if vignette > 0:
                    rows, cols = adjusted_img.shape[:2]
                    kernel_x = cv2.getGaussianKernel(cols, int(cols * (1 - vignette)))
                    kernel_y = cv2.getGaussianKernel(rows, int(rows * (1 - vignette)))
                    kernel = (kernel_y * kernel_x.T).astype(np.float32)
                    mask = kernel / np.max(kernel)
                    mask = mask[:, :, np.newaxis]
                    adjusted_img = adjusted_img * mask

                if chromatic_aberration > 0:
                    b, g, r = cv2.split(adjusted_img)
                    offset = int(chromatic_aberration)
                    b = np.roll(b, (offset, offset), axis=(0, 1))
                    r = np.roll(r, (-offset, -offset), axis=(0, 1))
                    adjusted_img = cv2.merge((b, g, r))

            if grain_intensity > 0:
                noise = np.random.normal(0, float(grain_intensity), adjusted_img.shape).astype(np.float32)
                adjusted_img = np.clip(adjusted_img + noise, 0.0, 1.0)
            
            final_rgb = cv2.cvtColor(adjusted_img, cv2.COLOR_BGR2RGB)
            processed_images.append(torch.from_numpy(final_rgb.astype(np.float32)).to(image.device))
            
        final_tensor = torch.stack(processed_images)
        
        return (final_tensor, status_message)

NODE_CLASS_MAPPINGS = { "FilmLookCreator": FilmLookCreator }
NODE_DISPLAY_NAME_MAPPINGS = { "FilmLookCreator": "Absynth Film Look Creator v1.0" }