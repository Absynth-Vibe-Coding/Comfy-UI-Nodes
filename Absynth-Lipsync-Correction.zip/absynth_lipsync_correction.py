import torch
import numpy as np
from typing import Tuple, Optional
import folder_paths
import comfy.model_management as model_management

class AbsynthLipSyncCorrection:
    """
    Absynth LipSync Tracker - ComfyUI Node for enhanced lip-sync with audio analysis.
    Works without external dependencies using pure audio-based sync correction.
    Created for the Absynth Finetune workflow.
    """
    
    def __init__(self):
        pass
        
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "video_frames": ("IMAGE",),
                "audio": ("AUDIO",),
                "sync_offset_frames": ("INT", {
                    "default": 0,
                    "min": -10,
                    "max": 10,
                    "step": 1,
                    "display": "number"
                }),
                "audio_sensitivity": ("FLOAT", {
                    "default": 1.0,
                    "min": 0.1,
                    "max": 3.0,
                    "step": 0.1,
                    "display": "number"
                }),
                "auto_detect_offset": ("BOOLEAN", {"default": True}),
                "smoothing_factor": ("FLOAT", {
                    "default": 0.3,
                    "min": 0.1,
                    "max": 1.0,
                    "step": 0.1,
                    "display": "number"
                })
            }
        }
    
    RETURN_TYPES = ("IMAGE", "IMAGE", "AUDIO", "STRING")
    RETURN_NAMES = ("synced_video", "debug_overlay", "processed_audio", "sync_report")
    FUNCTION = "process_lipsync"
    CATEGORY = "video/audio"
    
    def get_audio_tensor(self, audio_data):
        """Safely extract audio tensor from ComfyUI audio object"""
        try:
            # Debug: Print audio object info
            print(f"Audio object type: {type(audio_data)}")
            print(f"Audio object dir: {[attr for attr in dir(audio_data) if not attr.startswith('_')]}")
            
            # Try different ways to access audio data
            if hasattr(audio_data, 'waveform') and audio_data.waveform is not None:
                print("Found waveform attribute")
                return audio_data.waveform
            elif hasattr(audio_data, 'audio') and audio_data.audio is not None:
                print("Found audio attribute")
                return audio_data.audio
            elif hasattr(audio_data, 'data') and audio_data.data is not None:
                print("Found data attribute")
                return audio_data.data
            elif hasattr(audio_data, 'tensor') and audio_data.tensor is not None:
                print("Found tensor attribute")
                return audio_data.tensor
            elif isinstance(audio_data, dict):
                print("Audio is dict format")
                if 'waveform' in audio_data:
                    return audio_data['waveform']
                elif 'audio' in audio_data:
                    return audio_data['audio']
                elif 'data' in audio_data:
                    return audio_data['data']
            elif hasattr(audio_data, '__getitem__'):
                print("Audio supports indexing")
                try:
                    return audio_data[0] if len(audio_data) > 0 else None
                except:
                    pass
            
            # If all else fails, try to call it or iterate
            if callable(audio_data):
                print("Audio is callable")
                try:
                    return audio_data()
                except:
                    pass
                    
            print("Could not extract audio tensor, using dummy data")
            return torch.randn(16000)  # 1 second of dummy audio at 16kHz
            
        except Exception as e:
            print(f"Error extracting audio: {e}")
            return torch.randn(16000)
    
    def extract_audio_features(self, audio_data, sample_rate=16000, sensitivity=1.0):
        """Extract audio energy envelope for lip sync correlation"""
        # Get the actual audio tensor
        audio_tensor = self.get_audio_tensor(audio_data)
        
        if audio_tensor is None:
            print("No audio tensor found, returning dummy features")
            return np.array([0.1] * 100)
        
        # Convert to numpy
        try:
            if hasattr(audio_tensor, 'shape') and len(audio_tensor.shape) > 1:
                audio_np = audio_tensor.mean(dim=-1).cpu().numpy()  # Convert stereo to mono
            else:
                audio_np = audio_tensor.cpu().numpy()
        except Exception as e:
            print(f"Error converting audio to numpy: {e}")
            return np.array([0.1] * 100)
        
        # Calculate RMS energy in sliding windows
        window_size = int(sample_rate * 0.025)  # 25ms windows
        hop_size = int(sample_rate * 0.0625)    # 16fps timing (1/16 = 0.0625)
        
        if len(audio_np) < window_size:
            print(f"Audio too short: {len(audio_np)} samples")
            return np.array([0.1] * 10)
        
        energy = []
        for i in range(0, len(audio_np) - window_size, hop_size):
            window = audio_np[i:i + window_size]
            rms = np.sqrt(np.mean(window ** 2))
            energy.append(rms * sensitivity)
        
        return np.array(energy)
    
    def detect_frame_changes(self, frames):
        """Detect frame-to-frame changes as proxy for movement"""
        changes = []
        prev_frame = None
        
        for frame in frames:
            if isinstance(frame, torch.Tensor):
                frame_np = frame.cpu().numpy()
            else:
                frame_np = frame
                
            # Focus on center region where face typically is
            h, w = frame_np.shape[:2]
            center_region = frame_np[h//4:3*h//4, w//4:3*w//4]
            
            if prev_frame is not None:
                # Calculate mean absolute difference
                diff = np.mean(np.abs(center_region - prev_frame))
                changes.append(diff)
            else:
                changes.append(0)
                
            prev_frame = center_region
            
        return np.array(changes)
    
    def create_debug_overlay(self, frame, frame_idx, audio_energy, frame_change, sync_offset):
        """Create simple debug overlay showing sync information"""
        # Convert to numpy if tensor
        if isinstance(frame, torch.Tensor):
            overlay = frame.clone()
        else:
            overlay = torch.from_numpy(frame.copy())
        
        # Create simple colored indicators in corners
        h, w = overlay.shape[:2]
        
        # Audio energy indicator (top-left, red)
        energy_intensity = min(audio_energy * 255, 255)
        overlay[10:30, 10:60] = torch.tensor([energy_intensity/255, 0, 0])
        
        # Frame change indicator (top-right, green)
        change_intensity = min(frame_change * 1000, 255)
        overlay[10:30, w-60:w-10] = torch.tensor([0, change_intensity/255, 0])
        
        # Sync offset indicator (bottom-left, blue)
        if sync_offset != 0:
            overlay[h-30:h-10, 10:60] = torch.tensor([0, 0, 0.8])
        
        # Frame number (bottom-right)
        # Simple frame counter visualization
        counter_intensity = (frame_idx % 16) / 16.0
        overlay[h-30:h-10, w-60:w-10] = torch.tensor([counter_intensity, counter_intensity, counter_intensity])
        
        return overlay
    
    def calculate_optimal_sync(self, frame_changes, audio_energies, smoothing=0.3):
        """Calculate optimal sync offset using cross-correlation"""
        if len(frame_changes) == 0 or len(audio_energies) == 0:
            return 0
        
        # Ensure same length for comparison
        min_len = min(len(frame_changes), len(audio_energies))
        frame_changes = frame_changes[:min_len]
        audio_energies = audio_energies[:min_len]
        
        # Apply smoothing
        frame_smooth = np.convolve(frame_changes, np.ones(3)/3, mode='same')
        audio_smooth = np.convolve(audio_energies, np.ones(3)/3, mode='same')
        
        # Normalize signals
        if np.std(frame_smooth) > 1e-8:
            frame_norm = (frame_smooth - np.mean(frame_smooth)) / np.std(frame_smooth)
        else:
            frame_norm = frame_smooth
            
        if np.std(audio_smooth) > 1e-8:
            audio_norm = (audio_smooth - np.mean(audio_smooth)) / np.std(audio_smooth)
        else:
            audio_norm = audio_smooth
        
        # Compute cross-correlation for small offsets only
        max_offset = 10
        correlations = []
        
        for offset in range(-max_offset, max_offset + 1):
            if offset < 0:
                if len(frame_norm) + offset > 0:
                    corr = np.corrcoef(audio_norm[-offset:], frame_norm[:len(frame_norm)+offset])[0,1]
                else:
                    corr = 0
            elif offset > 0:
                if len(frame_norm) - offset > 0:
                    corr = np.corrcoef(audio_norm[:-offset], frame_norm[offset:])[0,1]
                else:
                    corr = 0
            else:
                corr = np.corrcoef(audio_norm, frame_norm)[0,1]
                
            if np.isnan(corr):
                corr = 0
            correlations.append(corr)
        
        # Find best correlation
        best_idx = np.argmax(correlations)
        optimal_offset = best_idx - max_offset
        
        return int(optimal_offset)
    
    def apply_sync_correction(self, frames, audio, offset_frames):
        """Apply temporal offset correction"""
        if offset_frames == 0:
            return frames, audio
        
        if offset_frames > 0:
            # Delay video (add frames at beginning)
            first_frame = frames[0:1]
            padding = first_frame.repeat(offset_frames, 1, 1, 1)
            corrected_frames = torch.cat([padding, frames], dim=0)
            corrected_audio = audio  # Keep original audio object
        else:
            # For negative offset, just trim video instead of modifying audio
            abs_offset = abs(offset_frames)
            if abs_offset < len(frames):
                corrected_frames = frames[abs_offset:]
            else:
                corrected_frames = frames
            corrected_audio = audio
        
        return corrected_frames, corrected_audio
    
    def process_lipsync(self, video_frames, audio, sync_offset_frames, audio_sensitivity, 
                       auto_detect_offset, smoothing_factor):
        """Main processing function"""
        
        print(f"Processing {len(video_frames)} video frames")
        
        # Extract audio features
        audio_energies = self.extract_audio_features(audio, sensitivity=audio_sensitivity)
        print(f"Extracted {len(audio_energies)} audio energy values")
        
        # Detect frame changes
        frame_changes = self.detect_frame_changes(video_frames)
        print(f"Detected {len(frame_changes)} frame changes")
        
        # Calculate optimal sync if auto-detect is enabled
        if auto_detect_offset and sync_offset_frames == 0:
            optimal_offset = self.calculate_optimal_sync(
                frame_changes, audio_energies, smoothing_factor
            )
            print(f"Auto-detected optimal offset: {optimal_offset}")
        else:
            optimal_offset = sync_offset_frames
            print(f"Using manual offset: {optimal_offset}")
        
        # Apply sync correction
        synced_frames, synced_audio = self.apply_sync_correction(
            video_frames, audio, optimal_offset
        )
        
        # Create debug overlays
        debug_overlays = []
        for i, frame in enumerate(video_frames):
            audio_idx = min(i, len(audio_energies) - 1) if len(audio_energies) > 0 else 0
            change_idx = min(i, len(frame_changes) - 1) if len(frame_changes) > 0 else 0
            
            audio_energy = audio_energies[audio_idx] if len(audio_energies) > 0 else 0
            frame_change = frame_changes[change_idx] if len(frame_changes) > 0 else 0
            
            debug_overlay = self.create_debug_overlay(
                frame, i, audio_energy, frame_change, optimal_offset
            )
            debug_overlays.append(debug_overlay)
        
        # Calculate correlation for report
        if len(frame_changes) > 0 and len(audio_energies) > 0:
            min_len = min(len(frame_changes), len(audio_energies))
            correlation = np.corrcoef(
                frame_changes[:min_len], 
                audio_energies[:min_len]
            )[0, 1] if min_len > 1 else 0
        else:
            correlation = 0
        
        if np.isnan(correlation):
            correlation = 0
        
        # Generate sync report
        sync_report = f"""Absynth LipSync Analysis:
Applied Offset: {optimal_offset} frames
Audio-Visual Correlation: {correlation:.3f}
Total Frames: {len(video_frames)}
Audio Energy (avg): {np.mean(audio_energies):.4f}
Frame Changes (avg): {np.mean(frame_changes):.4f}
Sync Method: {'Auto-detected' if auto_detect_offset else 'Manual'}
Status: {'Good sync' if abs(correlation) > 0.3 else 'Weak correlation - check audio/video quality'}"""
        
        return (
            synced_frames,
            torch.stack(debug_overlays) if debug_overlays else video_frames.clone(),
            synced_audio,
            sync_report
        )

# Node registration for ComfyUI
NODE_CLASS_MAPPINGS = {
    "AbsynthLipSyncCorrection": AbsynthLipSyncCorrection
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AbsynthLipSyncCorrection": "Absynth LipSync Correction"
}