"""
Absynth LipSync Correction - ComfyUI Custom Node
Enhanced lip-sync correction with audio-visual analysis for Wan 2.2 S2V workflows
"""

from .absynth_lipsync_correction import NODE_CLASS_MAPPINGS, NODE_DISPLAY_NAME_MAPPINGS

__all__ = ['NODE_CLASS_MAPPINGS', 'NODE_DISPLAY_NAME_MAPPINGS']