// file: film_look_creator.js

import { app } from "/scripts/app.js";
import { api } from "/scripts/api.js";

// Funktion zum Abrufen der Presets vom Backend.
async function getFilmLookPresets() {
    try {
        const response = await api.fetchApi('/absynth/get_presets');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const presets = await response.json();
        return presets;
    } catch (error) {
        console.error("Absynth Film Look Creator: Failed to fetch presets.", error);
        return { "Custom": {} };
    }
}

// Hilfsfunktion zum Anwenden der Preset-Werte auf die Widgets.
function applyPresetValues(node, presetValues) {
    if (!presetValues) {
        console.log("Absynth Film Look Creator: No values to apply for this preset.");
        return;
    }

    for (const key in presetValues) {
        if (Object.prototype.hasOwnProperty.call(presetValues, key)) {
            const widget = node.widgets.find(w => w.name === key);
            
            if (widget) {
                widget.value = presetValues[key];
            }
        }
    }
    // Erzwinge ein Neuzeichnen des Canvas, um die UI-Änderungen sichtbar zu machen.
    node.setDirtyCanvas(true, true);
}

// Helper function to get the current widget values
function getWidgetValues(node) {
    const values = {};
    for (const widget of node.widgets) {
        // Skip the preset dropdown and buttons
        if (widget.name === "preset" || widget.name === "save_preset") {
            continue;
        }
        values[widget.name] = widget.value;
    }
    return values;
}

app.registerExtension({
    name: "Absynth.FilmLookCreator",
    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        if (nodeData.name === "FilmLookCreator") {
            const onNodeCreated = nodeType.prototype.onNodeCreated;
            nodeType.prototype.onNodeCreated = function () {
                onNodeCreated?.apply(this, arguments);

                const presetWidget = this.widgets.find(w => w.name === "preset");

                if (presetWidget) {
                    // Speichere den Original-Callback.
                    const originalCallback = presetWidget.callback;

                    // Überschreibe den Callback mit unserer Logik.
                    presetWidget.callback = async (value) => {
                        // Manuelle Zuweisung des Wertes, um sicherzustellen, dass das Widget ihn hält.
                        presetWidget.value = value;
                        
                        // Lade die Presets und wende sie an.
                        const presets = await getFilmLookPresets();
                        const presetValues = presets[value];
                        applyPresetValues(this, presetValues);
                        
                        // Rufe den ursprünglichen Callback auf, um die normale Logik auszuführen.
                        originalCallback?.(value);
                    };
                }

                // Add the Save Preset button
                const self = this;
                const saveButton = this.addWidget("button", "Save Current Settings as Preset", "save_preset", async () => {
                    const presetName = prompt("Enter a name for the new preset:");
                    if (presetName) {
                        const presetData = getWidgetValues(self);
                        try {
                            const response = await api.fetchApi('/absynth/save_preset', {
                                method: 'POST',
                                body: JSON.stringify({ preset_name: presetName, preset_data: presetData }),
                                headers: { 'Content-Type': 'application/json' },
                            });

                            if (!response.ok) {
                                throw new Error(`HTTP error! status: ${response.status}`);
                            }
                            
                            alert(`Preset '${presetName}' saved successfully! Please refresh your browser to see the new preset.`);
                        } catch (error) {
                            console.error("Absynth Film Look Creator: Failed to save preset.", error);
                            alert("Failed to save preset. Check the console for details.");
                        }
                    }
                });
            };
        }
    },
});