"""
@author: Your Name
@title: Adjust Saturation
@nickname: Adjust Saturation
@description: This node adjusts the saturation of an image.
"""

import torch
import cv2
import numpy as np

class AdjustSaturation:
    """
    A custom node for ComfyUI to adjust the saturation of an image.
    It converts the image to HSV color space, modifies the saturation channel,
    and then converts it back to RGB.
    """
    
    def __init__(self):
        pass
    
    @classmethod
    def INPUT_TYPES(s):
        """
        Defines the input types for the node, which include an image
        and a saturation factor.
        """
        return {
            "required": {
                "image": ("IMAGE",),
                "saturation_factor": ("FLOAT", {
                    "default": 1.0,
                    "min": 0.0,      # 0.0 results in a grayscale image
                    "max": 3.0,      # Values > 1.0 increase saturation
                    "step": 0.01,
                    "round": 0.01,
                    "display": "slider"  # Use a slider for user-friendly input
                }),
            }
        }

    RETURN_TYPES = ("IMAGE",)
    FUNCTION = "adjust_saturation"
    CATEGORY = "Image/Color" # You can change the category to your preference

    def adjust_saturation(self, image, saturation_factor):
        """
        This function performs the core logic of adjusting the saturation.
        - image: A PyTorch tensor of shape (N, H, W, C) with values in [0.0, 1.0].
        - saturation_factor: The float value to multiply the saturation channel by.
        """
        
        # Detach tensor from the computation graph and move to CPU for NumPy conversion
        image_np = image.cpu().numpy()
        
        processed_images = []
        
        # Process each image in the batch
        for i in range(image_np.shape[0]):
            img_slice = image_np[i]
            
            # Handle alpha channel if it exists by separating it before color conversion
            if img_slice.shape[2] == 4:
                alpha_channel = img_slice[:, :, 3]
                rgb_channels = img_slice[:, :, :3]
            else:
                alpha_channel = None
                rgb_channels = img_slice

            # Convert image from [0, 1] float to [0, 255] uint8 for OpenCV
            rgb_uint8 = (rgb_channels * 255).astype(np.uint8)
            
            # Convert RGB to HSV color space
            hsv_image = cv2.cvtColor(rgb_uint8, cv2.COLOR_RGB2HSV)
            
            # Modify the saturation channel
            # Cast saturation channel to float for multiplication
            hsv_image[:, :, 1] = np.clip(hsv_image[:, :, 1].astype(np.float32) * saturation_factor, 0, 255)
            
            # Convert back to uint8
            hsv_image = hsv_image.astype(np.uint8)
            
            # Convert HSV back to RGB color space
            rgb_saturated = cv2.cvtColor(hsv_image, cv2.COLOR_HSV2RGB)
            
            # Convert back to [0, 1] float
            rgb_saturated_float = rgb_saturated.astype(np.float32) / 255.0

            # Re-attach the alpha channel if it was present
            if alpha_channel is not None:
                # Add the alpha channel back to the image
                final_image_np = np.dstack((rgb_saturated_float, alpha_channel))
            else:
                final_image_np = rgb_saturated_float

            processed_images.append(final_image_np)
            
        # Stack the processed numpy arrays into a single array
        final_np_array = np.stack(processed_images)
        
        # Convert the final numpy array back to a PyTorch tensor
        final_tensor = torch.from_numpy(final_np_array).to(image.device)
        
        return (final_tensor,)

# A dictionary that maps class names to class objects
NODE_CLASS_MAPPINGS = {
    "AdjustSaturation": AdjustSaturation
}

# A dictionary that maps class names to their display names
NODE_DISPLAY_NAME_MAPPINGS = {
    "AdjustSaturation": "Adjust Saturation"
}
