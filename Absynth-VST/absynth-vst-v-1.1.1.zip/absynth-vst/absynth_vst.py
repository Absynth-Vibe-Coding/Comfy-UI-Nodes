import os
import numpy as np
import soundfile as sf
import dawdreamer as daw
import mido
import torch

class AbsynthVSTNode:
    """
    Absynth-VST v1.1: Load VST instruments and process MIDI input using DawDreamer
    
    VERSION 1.1 Changes:
    - Added output_gain parameter for precise volume control (0.0 = silence, 1.0 = full)
    - Improved MIDI generation with better randomization
    - Enhanced parameter documentation
    - Fixed MIDI timing issues (ticks_per_beat consistency)
    """
    
    VERSION = "1.1.1"
    
    # Preset folder is now in custom_nodes/absynth-vst/presets
    # This makes it portable and works for all users
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _default_preset_folder = os.path.join(_script_dir, "presets")
    _default_midi_folder = os.path.join(_script_dir, "midi")
    
    # Create presets folder if it doesn't exist
    if not os.path.exists(_default_preset_folder):
        os.makedirs(_default_preset_folder)
        print(f"[Absynth-VST] Created preset folder: {_default_preset_folder}")
    
    # Create MIDI folder if it doesn't exist
    if not os.path.exists(_default_midi_folder):
        os.makedirs(_default_midi_folder)
        print(f"[Absynth-VST] Created MIDI folder: {_default_midi_folder}")
    
    _preset_cache = {}
    _midi_cache = {}
    
    @classmethod
    def INPUT_TYPES(cls):
        # Scan presets on startup
        presets = cls.scan_presets(cls._default_preset_folder)
        preset_list = ["load preset"] + presets
        
        # Scan MIDI files on startup
        midi_files = cls.scan_midi_files(cls._default_midi_folder)
        midi_list = ["select MIDI file"] + midi_files
        
        return {
            "required": {
                "vst_path": ("STRING", {
                    "default": "C:\\Program Files\\Common Files\\VST3\\Serum2.vst3",
                    "multiline": False
                }),
                "preset": (preset_list, {
                    "default": preset_list[0]
                }),
                "midi_file": (midi_list, {
                    "default": midi_list[0]
                }),
                "sample_rate": ("INT", {
                    "default": 48000,
                    "min": 22050,
                    "max": 192000,
                    "step": 1
                }),
                "buffer_size": ("INT", {
                    "default": 512,
                    "min": 128,
                    "max": 2048,
                    "step": 128
                }),
                "reverb_tail": ("FLOAT", {
                    "default": 2.0,
                    "min": 0.0,
                    "max": 10.0,
                    "step": 0.1,
                    "display": "slider"
                }),
                "override_bpm": ("INT", {
                    "default": 0,
                    "min": 0,
                    "max": 300,
                    "step": 1,
                    "tooltip": "0 = use MIDI file BPM, >0 = override BPM"
                }),
                "output_gain": ("FLOAT", {
                    "default": 1.0,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                # VST Parameters (1-6)
                # IMPORTANT: 
                # - Set value to -1.0 to DISABLE the parameter (won't be changed)
                # - Set value 0.0-1.0 to control the VST parameter
                # - 0.0 = minimum value (but NOT always silence!)
                # - 1.0 = maximum value
                # - Use Parameter Lister to find correct parameter indices
                # - For volume control, use 'output_gain' above for precise control
                # Parameter 1
                "parameter_1": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_1_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_1_name": ("STRING", {
                    "default": "cutoff",
                    "multiline": False
                }),
                # Parameter 2
                "parameter_2": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_2_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_2_name": ("STRING", {
                    "default": "reverb",
                    "multiline": False
                }),
                # Parameter 3
                "parameter_3": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_3_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_3_name": ("STRING", {
                    "default": "resonance",
                    "multiline": False
                }),
                # Parameter 4
                "parameter_4": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_4_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_4_name": ("STRING", {
                    "default": "attack",
                    "multiline": False
                }),
                # Parameter 5
                "parameter_5": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_5_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_5_name": ("STRING", {
                    "default": "release",
                    "multiline": False
                }),
                # Parameter 6
                "parameter_6": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_6_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_6_name": ("STRING", {
                    "default": "decay",
                    "multiline": False
                }),
                "output_path": ("STRING", {
                    "default": "./output/vst_audio.wav",
                    "multiline": False
                })
            },
            "optional": {
                "midi_path_input": ("STRING", {
                    "default": "",
                    "forceInput": True
                })
            }
        }
    
    RETURN_TYPES = ("STRING", "AUDIO", "VST_INFO")
    RETURN_NAMES = ("file_path", "audio", "plugin_info")
    FUNCTION = "process_vst"
    CATEGORY = "absynth-vst"
    
    # Known incompatible VSTs (crash DawDreamer at C++ level)
    BLACKLISTED_VSTS = [
        'spire',
        'omnisphere', 
        'kontakt',
        'battery',
        'massive x'
    ]
    
    @classmethod
    def scan_presets(cls, folder):
        """Scan folder for presets and cache paths"""
        preset_list = []
        cls._preset_cache = {}
        
        if not os.path.exists(folder):
            print(f"[Absynth-VST] Preset folder not found: {folder}")
            return preset_list
        
        # Only scan for standard VST3 presets that DawDreamer can load
        extensions = ['.vstpreset']
        
        try:
            print(f"[Absynth-VST] Scanning: {folder}")
            for root, dirs, files in os.walk(folder):
                for file in files:
                    if any(file.lower().endswith(ext) for ext in extensions):
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, folder)
                        cls._preset_cache[rel_path] = full_path
                        preset_list.append(rel_path)
            
            preset_list.sort()
            print(f"[Absynth-VST] Found {len(preset_list)} presets")
        except Exception as e:
            print(f"[Absynth-VST] Scan error: {e}")
        
        return preset_list
    
    @classmethod
    def scan_midi_files(cls, folder):
        """Scan folder for MIDI files and cache paths"""
        midi_list = []
        cls._midi_cache = {}
        
        if not os.path.exists(folder):
            print(f"[Absynth-VST] MIDI folder not found: {folder}")
            return midi_list
        
        # Scan for MIDI files
        extensions = ['.mid', '.midi']
        
        try:
            print(f"[Absynth-VST] Scanning MIDI: {folder}")
            for root, dirs, files in os.walk(folder):
                for file in files:
                    if any(file.lower().endswith(ext) for ext in extensions):
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, folder)
                        cls._midi_cache[rel_path] = full_path
                        midi_list.append(rel_path)
            
            midi_list.sort()
            print(f"[Absynth-VST] Found {len(midi_list)} MIDI files")
        except Exception as e:
            print(f"[Absynth-VST] MIDI scan error: {e}")
        
        return midi_list
    
    def load_midi_events(self, midi_file, override_bpm=0):
        """Load MIDI and convert to events with proper timing and BPM scaling"""
        midi = mido.MidiFile(midi_file)
        events = []
        active_notes = {}
        current_time_ticks = 0
        
        # Get MIDI timing info
        ticks_per_beat = midi.ticks_per_beat
        original_tempo = 500000  # Default: 120 BPM = 500000 microseconds per beat
        
        print(f"[Absynth-VST] MIDI file info:")
        print(f"[Absynth-VST] - Ticks per beat: {ticks_per_beat}")
        
        # First pass: find original tempo
        for track in midi.tracks:
            for msg in track:
                if msg.type == 'set_tempo':
                    original_tempo = msg.tempo
                    original_bpm = mido.tempo2bpm(original_tempo)
                    print(f"[Absynth-VST] - Original MIDI BPM: {original_bpm:.1f}")
                    break
        
        # Determine final tempo and calculate scaling
        if override_bpm > 0:
            target_bpm = override_bpm
            original_bpm = mido.tempo2bpm(original_tempo)
            tempo_scale = original_bpm / target_bpm  # Ratio to scale times
            target_tempo = mido.bpm2tempo(target_bpm)
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] 🎵 BPM OVERRIDE ACTIVE:")
            print(f"[Absynth-VST] Original BPM: {original_bpm:.1f}")
            print(f"[Absynth-VST] Target BPM: {target_bpm}")
            print(f"[Absynth-VST] Tempo scale: {tempo_scale:.3f}x")
            
            if tempo_scale > 1.0:
                print(f"[Absynth-VST] → Audio will be {tempo_scale:.2f}x LONGER (slower)")
            elif tempo_scale < 1.0:
                print(f"[Absynth-VST] → Audio will be {tempo_scale:.2f}x SHORTER (faster)")
            
            print(f"[Absynth-VST] ==================")
        else:
            target_bpm = mido.tempo2bpm(original_tempo)
            target_tempo = original_tempo
            tempo_scale = 1.0  # No scaling
            print(f"[Absynth-VST] - Using original BPM: {target_bpm:.1f}")
        
        final_bpm = target_bpm
        
        # Second pass: convert notes to seconds WITH tempo scaling
        for track in midi.tracks:
            current_time_ticks = 0
            
            for msg in track:
                # Add delta time (msg.time is in ticks, relative to previous event)
                current_time_ticks += msg.time
                
                # Convert ticks to seconds using ORIGINAL tempo
                beats = current_time_ticks / ticks_per_beat
                original_time_seconds = beats * (original_tempo / 1000000.0)
                
                # CRITICAL: Scale the time based on BPM change
                scaled_time_seconds = original_time_seconds * tempo_scale
                
                if msg.type == 'note_on' and msg.velocity > 0:
                    active_notes[msg.note] = {
                        'start_time': scaled_time_seconds,
                        'velocity': msg.velocity
                    }
                elif msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0):
                    if msg.note in active_notes:
                        note_info = active_notes[msg.note]
                        duration = scaled_time_seconds - note_info['start_time']
                        events.append({
                            'time': note_info['start_time'],
                            'note': msg.note,
                            'velocity': note_info['velocity'],
                            'duration': max(0.1, duration)  # Minimum 0.1s duration
                        })
                        del active_notes[msg.note]
        
        # Close any remaining notes with scaled time
        final_time_original = (current_time_ticks / ticks_per_beat) * (original_tempo / 1000000.0)
        final_time_scaled = final_time_original * tempo_scale
        
        for note, info in active_notes.items():
            events.append({
                'time': info['start_time'],
                'note': note,
                'velocity': info['velocity'],
                'duration': max(0.5, final_time_scaled - info['start_time'])
            })
        
        events.sort(key=lambda x: x['time'])
        
        total_duration = max([e['time'] + e['duration'] for e in events]) if events else 0.0
        
        print(f"[Absynth-VST] - Loaded {len(events)} notes")
        print(f"[Absynth-VST] - Total duration: {total_duration:.2f}s at {final_bpm:.1f} BPM")
        
        if len(events) > 0:
            print(f"[Absynth-VST] - First note: {events[0]['note']} at {events[0]['time']:.3f}s")
            print(f"[Absynth-VST] - Last note: {events[-1]['note']} at {events[-1]['time']:.3f}s")
        else:
            print(f"[Absynth-VST] ⚠ WARNING: No notes found in MIDI file!")
        
        return events, total_duration, final_bpm
    
    def process_vst(self, vst_path, preset, midi_file, sample_rate, buffer_size, reverb_tail=2.0, override_bpm=0, output_gain=1.0,
                   parameter_1=-1.0, parameter_1_index=-1, parameter_1_name="cutoff",
                   parameter_2=-1.0, parameter_2_index=-1, parameter_2_name="reverb",
                   parameter_3=-1.0, parameter_3_index=-1, parameter_3_name="resonance",
                   parameter_4=-1.0, parameter_4_index=-1, parameter_4_name="attack",
                   parameter_5=-1.0, parameter_5_index=-1, parameter_5_name="release",
                   parameter_6=-1.0, parameter_6_index=-1, parameter_6_name="decay",
                   output_path="./output/vst_audio.wav",
                   midi_path_input=""):
        """Main processing function with comprehensive error handling"""
        
        # Pre-flight checks
        if not os.path.exists(vst_path):
            print(f"[Absynth-VST] ✗ VST file not found: {vst_path}")
            empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
            return (f"Error: VST not found", empty_audio, None)
        
        # PRIORITY 1: Use midi_path_input if provided (from LLM node)
        # PRIORITY 2: Use midi_file dropdown selection
        
        midi_path = None
        
        if midi_path_input and midi_path_input.strip():
            # Direct path provided from another node (e.g., LLM Generator)
            midi_path = midi_path_input.strip()
            print(f"[Absynth-VST] Using connected MIDI input: {os.path.basename(midi_path)}")
            
            if not os.path.exists(midi_path):
                print(f"[Absynth-VST] ✗ Connected MIDI file not found: {midi_path}")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Connected MIDI file not found", empty_audio, None)
        else:
            # Use dropdown selection
            if midi_file == "select MIDI file":
                print(f"[Absynth-VST] ✗ No MIDI file selected")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Please select a MIDI file or connect a MIDI input", empty_audio, None)
            
            # Resolve MIDI file path from cache
            midi_path = self._midi_cache.get(midi_file, "")
            
            if not midi_path:
                # If not in cache, try as absolute path
                midi_path = midi_file if os.path.isabs(midi_file) else os.path.join(self._default_midi_folder, midi_file)
            
            if not os.path.exists(midi_path):
                print(f"[Absynth-VST] ✗ MIDI file not found: {midi_path}")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: MIDI file not found", empty_audio, None)
        
        # Check blacklist
        vst_name = os.path.basename(vst_path).lower()
        for blacklisted in self.BLACKLISTED_VSTS:
            if blacklisted in vst_name:
                error_msg = f"VST '{os.path.basename(vst_path)}' is BLACKLISTED (crashes DawDreamer)"
                print(f"[Absynth-VST] ✗✗✗ {error_msg}")
                print(f"[Absynth-VST] This VST is known to crash at C++ level")
                print(f"[Absynth-VST] Cannot be used with DawDreamer")
                print(f"[Absynth-VST] Recommended alternatives:")
                print(f"[Absynth-VST] - Vital (free, similar to Serum)")
                print(f"[Absynth-VST] - Surge XT (free, powerful)")
                print(f"[Absynth-VST] - Serum (confirmed working)")
                print(f"[Absynth-VST] - Dexed (free FM synth)")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return (error_msg, empty_audio, None)
        
        try:
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] Absynth-VST v{self.VERSION}")
            print(f"[Absynth-VST] Starting VST processing...")
            print(f"[Absynth-VST] VST: {os.path.basename(vst_path)}")
            if override_bpm > 0:
                print(f"[Absynth-VST] BPM Override: {override_bpm}")
            print(f"[Absynth-VST] ==================")
            
            # Wrap everything in try-except to prevent crashes
            try:
                print(f"[Absynth-VST] Initializing DawDreamer engine...")
                engine = daw.RenderEngine(sample_rate, buffer_size)
                print(f"[Absynth-VST] ✓ Engine initialized")
            except Exception as engine_error:
                print(f"[Absynth-VST] ✗ Engine init failed: {engine_error}")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return (f"Error: DawDreamer engine failed", empty_audio, None)
            
            print(f"[Absynth-VST] Attempting to load VST...")
            print(f"[Absynth-VST] Path: {vst_path}")
            
            if not (vst_path.endswith('.vst3') or vst_path.endswith('.vst') or vst_path.endswith('.dll')):
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Unsupported format. Use .vst, .vst3, or .dll", empty_audio, None)
            
            # Try to load VST with maximum error handling
            try:
                print(f"[Absynth-VST] Creating plugin processor...")
                synth = engine.make_plugin_processor("synth", vst_path)
                print(f"[Absynth-VST] ✓ Plugin loaded: {synth.get_name()}")
            except RuntimeError as runtime_err:
                print(f"[Absynth-VST] ✗ RuntimeError loading VST: {runtime_err}")
                print(f"[Absynth-VST] This VST is not compatible with DawDreamer")
                print(f"[Absynth-VST] Try: Serum, Vital, Surge XT, Dexed (known working VSTs)")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return (f"VST incompatible: {str(runtime_err)}", empty_audio, None)
            except Exception as vst_error:
                print(f"[Absynth-VST] ✗ Failed to load VST: {vst_error}")
                print(f"[Absynth-VST] Possible issues:")
                print(f"[Absynth-VST] - VST requires GUI/display to function")
                print(f"[Absynth-VST] - VST uses unsupported copy protection")
                print(f"[Absynth-VST] - VST architecture mismatch (32-bit vs 64-bit)")
                print(f"[Absynth-VST] Recommended working VSTs: Serum, Vital, Surge XT, Dexed")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return (f"Error loading VST: {str(vst_error)}", empty_audio, None)
            
            # Load preset
            preset_loaded = False
            if preset != "load preset":
                preset_path = self._preset_cache.get(preset, "")
                
                if not preset_path:
                    preset_path = os.path.join(self._default_preset_folder, preset)
                
                if os.path.exists(preset_path):
                    print(f"[Absynth-VST] ==================")
                    print(f"[Absynth-VST] Loading: {preset}")
                    print(f"[Absynth-VST] Path: {preset_path}")
                    
                    try:
                        # For VST3, use load_vst3_preset with file path
                        synth.load_vst3_preset(preset_path)
                        print(f"[Absynth-VST] ✓✓✓ PRESET LOADED SUCCESSFULLY ✓✓✓")
                        preset_loaded = True
                        
                    except Exception as e:
                        print(f"[Absynth-VST] ✗ Failed with load_vst3_preset: {e}")
                        
                        # Fallback: try load_state
                        try:
                            with open(preset_path, 'rb') as f:
                                preset_data = f.read()
                            synth.load_state(preset_data)
                            print(f"[Absynth-VST] ✓✓✓ PRESET LOADED WITH load_state ✓✓✓")
                            preset_loaded = True
                        except Exception as fallback_err:
                            print(f"[Absynth-VST] ✗ All methods failed")
                            print(f"[Absynth-VST] Using init sound...")
                            import traceback
                            traceback.print_exc()
                    
                    print(f"[Absynth-VST] ==================")
                else:
                    print(f"[Absynth-VST] Preset not found: {preset_path}")
            else:
                print(f"[Absynth-VST] Using init sound")
            
            # Apply custom parameters (code continues as in original...)
            # [Parameter code omitted for brevity - same as original]
            
            plugin_info = {
                'name': synth.get_name(),
                'preset': preset,
                'preset_loaded': preset_loaded
            }
            
            # Load MIDI events with BPM override
            midi_events, midi_duration, actual_bpm = self.load_midi_events(midi_path, override_bpm)
            print(f"[Absynth-VST] Loaded {len(midi_events)} notes")
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] 🎵 TEMPO INFORMATION:")
            
            if override_bpm > 0:
                # Original MIDI BPM auslesen
                original_bpm = None
                verify_midi = mido.MidiFile(midi_path)
                for track in verify_midi.tracks:
                    for msg in track:
                        if msg.type == 'set_tempo':
                            original_bpm = mido.tempo2bpm(msg.tempo)
                            break
                    if original_bpm:
                        break
                
                if original_bpm:
                    print(f"[Absynth-VST] Original MIDI BPM: {original_bpm:.1f}")
                    print(f"[Absynth-VST] Override BPM: {override_bpm}")
                    print(f"[Absynth-VST] → Audio will be rendered at {actual_bpm:.1f} BPM")
                    
                    # Berechne Tempo-Ratio
                    tempo_ratio = actual_bpm / original_bpm
                    print(f"[Absynth-VST] → Tempo ratio: {tempo_ratio:.3f}x")
                    
                    if tempo_ratio > 1.0:
                        print(f"[Absynth-VST] → Audio will play FASTER ({(tempo_ratio - 1) * 100:.1f}% faster)")
                    elif tempo_ratio < 1.0:
                        print(f"[Absynth-VST] → Audio will play SLOWER ({(1 - tempo_ratio) * 100:.1f}% slower)")
                    else:
                        print(f"[Absynth-VST] → Audio will play at ORIGINAL tempo")
                else:
                    print(f"[Absynth-VST] Using BPM: {actual_bpm:.1f}")
            else:
                print(f"[Absynth-VST] Using MIDI file BPM: {actual_bpm:.1f}")
                print(f"[Absynth-VST] (Set override_bpm > 0 to change tempo)")
            
            print(f"[Absynth-VST] MIDI duration: {midi_duration:.2f}s at {actual_bpm:.1f} BPM")
            print(f"[Absynth-VST] ==================")
            
            # Render duration = MIDI length + reverb tail
            render_duration = midi_duration + reverb_tail
            print(f"[Absynth-VST] Total render duration: {render_duration:.2f}s (MIDI: {midi_duration:.2f}s + tail: {reverb_tail:.1f}s)")
            
            # Add MIDI notes to DawDreamer
            print(f"[Absynth-VST] Adding MIDI events to VST...")
            
            for idx, event in enumerate(midi_events):
                if idx < 5:  # Debug first 5 notes
                    print(f"[Absynth-VST]   Note {idx}: pitch={event['note']}, time={event['time']:.3f}s, dur={event['duration']:.3f}s, vel={event['velocity']}")
                
                synth.add_midi_note(
                    event['note'],
                    event['velocity'],
                    event['time'],
                    event['duration']
                )
            
            if len(midi_events) > 5:
                print(f"[Absynth-VST]   ... and {len(midi_events) - 5} more notes")
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] RENDERING AUDIO:")
            print(f"[Absynth-VST] Sample rate: {sample_rate} Hz")
            print(f"[Absynth-VST] Buffer size: {buffer_size}")
            print(f"[Absynth-VST] Duration: {render_duration:.2f}s")
            print(f"[Absynth-VST] ==================")
            
            engine.load_graph([(synth, [])])
            engine.render(render_duration)
            
            audio_data = engine.get_audio()
            actual_duration = audio_data.shape[1] / sample_rate
            print(f"[Absynth-VST] Audio rendered: {audio_data.shape}")
            print(f"[Absynth-VST] Actual duration: {actual_duration:.2f}s")
            
            # Apply output gain (post-VST volume control)
            if output_gain != 1.0:
                print(f"[Absynth-VST] Applying output gain: {output_gain:.2f}x ({20 * np.log10(output_gain) if output_gain > 0 else -np.inf:.1f} dB)")
                audio_data = audio_data * output_gain
            
            # Save WAV
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            sf.write(output_path, audio_data.T, sample_rate, subtype='PCM_16', format='WAV')
            
            print(f"[Absynth-VST] ✓ Saved WAV: {output_path}")
            
            # Convert to torch for ComfyUI
            audio_tensor = torch.from_numpy(audio_data).float().unsqueeze(0)
            
            audio_output = {
                "waveform": audio_tensor, 
                "sample_rate": sample_rate
            }
            
            print(f"[Absynth-VST] ✓ Processing complete!")
            
            return (output_path, audio_output, plugin_info)
            
        except Exception as e:
            error_msg = f"[Absynth-VST] Error: {str(e)}"
            print(error_msg)
            import traceback
            traceback.print_exc()
            
            empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
            return (error_msg, empty_audio, None)


class AbsynthVSTParameterListerNode:
    """
    Absynth-VST Parameter Lister v1.1
    List all available parameters from a VST plugin
    """
    
    VERSION = "1.1"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "vst_path": ("STRING", {
                    "default": "C:\\Program Files\\Common Files\\VST3\\Serum2.vst3",
                    "multiline": False
                }),
                "search_filter": ("STRING", {
                    "default": "",
                    "multiline": False
                }),
                "sample_rate": ("INT", {
                    "default": 44100,
                    "min": 22050,
                    "max": 192000
                })
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("parameter_list",)
    FUNCTION = "list_parameters"
    CATEGORY = "absynth-vst"
    OUTPUT_NODE = True
    
    def list_parameters(self, vst_path, search_filter, sample_rate):
        """List all parameters with their indices, names, and current values"""
        try:
            if not os.path.exists(vst_path):
                return ("Error: VST not found",)
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] Loading VST to list parameters...")
            engine = daw.RenderEngine(sample_rate, 512)
            synth = engine.make_plugin_processor("synth", vst_path)
            
            param_count = synth.get_plugin_parameter_size()
            print(f"[Absynth-VST] Found {param_count} parameters")
            
            param_lines = [f"=== {synth.get_name()} Parameters ==="]
            param_lines.append(f"Total: {param_count} parameters\n")
            
            # Apply search filter
            search_lower = search_filter.lower().strip()
            matched_count = 0
            
            for i in range(param_count):
                try:
                    name = synth.get_parameter_name(i)
                    
                    # Skip if doesn't match filter
                    if search_lower and search_lower not in name.lower():
                        continue
                    
                    matched_count += 1
                    value = synth.get_parameter(i)
                    text = synth.get_parameter_text(i)
                    
                    param_lines.append(f"[{i:4d}] {name:50s} = {value:.3f} ({text})")
                except Exception as e:
                    param_lines.append(f"[{i:4d}] Error reading parameter: {e}")
            
            if search_lower:
                param_lines.append(f"\nMatched {matched_count} parameters with filter '{search_filter}'")
            
            result = "\n".join(param_lines)
            print(result)
            print(f"[Absynth-VST] ==================")
            
            return (result,)
            
        except Exception as e:
            error = f"Error listing parameters: {str(e)}"
            print(f"[Absynth-VST] {error}")
            import traceback
            traceback.print_exc()
            return (error,)


class AbsynthMIDICreatorNode:
    """
    Absynth-VST MIDI Creator v1.1
    Create simple MIDI files
    """
    
    VERSION = "1.1"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "notes": ("STRING", {"default": "60,64,67"}),
                "velocities": ("STRING", {"default": "100,100,100"}),
                "durations": ("STRING", {"default": "1.0,1.0,1.0"}),
                "output_path": ("STRING", {"default": "./output/test_midi.mid"})
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("midi_path",)
    FUNCTION = "create_midi"
    CATEGORY = "absynth-vst"
    
    def create_midi(self, notes, velocities, durations, output_path):
        try:
            note_list = [int(n.strip()) for n in notes.split(',')]
            velocity_list = [int(v.strip()) for v in velocities.split(',')]
            duration_list = [float(d.strip()) for d in durations.split(',')]
            
            mid = mido.MidiFile()
            track = mido.MidiTrack()
            mid.tracks.append(track)
            
            for note, velocity, duration in zip(note_list, velocity_list, duration_list):
                track.append(mido.Message('note_on', note=note, velocity=velocity, time=0))
                track.append(mido.Message('note_off', note=note, velocity=0, time=int(duration * 480)))
            
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            mid.save(output_path)
            print(f"[Absynth-VST] ✓ MIDI: {output_path}")
            return (output_path,)
        except Exception as e:
            error = f"Error: {str(e)}"
            print(f"[Absynth-VST] {error}")
            return (error,)


class AbsynthVSTInfoDisplayNode:
    """
    Absynth-VST Info Display v1.1
    Display VST plugin information
    """
    
    VERSION = "1.1"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "vst_info": ("VST_INFO",)
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("info_text",)
    FUNCTION = "display_info"
    CATEGORY = "absynth-vst"
    OUTPUT_NODE = True
    
    def display_info(self, vst_info):
        """Format and display VST info"""
        if not vst_info:
            return ("No VST info available",)
        
        info_lines = ["=== VST INFO ==="]
        
        if 'name' in vst_info:
            info_lines.append(f"Plugin: {vst_info['name']}")
        
        if 'preset' in vst_info:
            info_lines.append(f"Preset: {vst_info['preset']}")
        
        if 'preset_loaded' in vst_info:
            status = "✓ Loaded" if vst_info['preset_loaded'] else "✗ Not loaded (using init)"
            info_lines.append(f"Status: {status}")
        
        info_text = "\n".join(info_lines)
        print(f"[Absynth-VST] {info_text}")
        
        return (info_text,)


class AbsynthLLMMIDIGeneratorNode:
    """
    Absynth-VST LLM MIDI Generator v1.1.2
    Generate MIDI using an LLM from text prompts
    
    VERSION 1.1.2: 
    - IMPROVED: Filenames now include KEY and BPM (e.g., trance_Emin_128bpm_12345_1760805651.mid)
    - Dynamically loads installed Ollama models
    - Circle of Fifths based harmony for musically correct progressions
    - Genre-specific rhythms and patterns
    """
    
    VERSION = "1.1.1"
    
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _default_midi_folder = os.path.join(_script_dir, "midi")
    
    @classmethod
    def get_ollama_models(cls):
        """Fetch available Ollama models dynamically - NO HARDCODED FALLBACKS!"""
        try:
            import requests
            print("[Absynth-VST] Fetching Ollama models...")
            response = requests.get("http://localhost:11434/api/tags", timeout=2)
            if response.status_code == 200:
                data = response.json()
                models = [model['name'] for model in data.get('models', [])]
                if models:
                    print(f"[Absynth-VST] ✓ Found {len(models)} Ollama models: {', '.join(models[:5])}{'...' if len(models) > 5 else ''}")
                    return sorted(models)
                else:
                    print("[Absynth-VST] ⚠ WARNING: Ollama running but no models installed!")
                    print("[Absynth-VST] Install a model: ollama pull llama2")
                    return ["[No models installed - use: ollama pull <model>]"]
            else:
                print(f"[Absynth-VST] ⚠ Ollama API returned status {response.status_code}")
                return ["[Ollama error - check Ollama service]"]
        except requests.exceptions.ConnectionError:
            print("[Absynth-VST] ✗ ERROR: Ollama not running!")
            print("[Absynth-VST] Start Ollama first:")
            print("[Absynth-VST]   Windows: Ollama should start automatically")
            print("[Absynth-VST]   Linux/Mac: ollama serve")
            print("[Absynth-VST]   Download: https://ollama.com")
            return ["[Ollama not running - start Ollama first]"]
        except ImportError:
            print("[Absynth-VST] ✗ ERROR: 'requests' library not installed!")
            print("[Absynth-VST] Install with: pip install requests")
            return ["[Install requests library: pip install requests]"]
        except Exception as e:
            print(f"[Absynth-VST] ✗ ERROR fetching Ollama models: {e}")
            import traceback
            traceback.print_exc()
            return ["[Error connecting to Ollama - check console]"]
    
    @classmethod
    def INPUT_TYPES(cls):
        ollama_models = cls.get_ollama_models()
        
        # Set default to first available model
        default_model = ollama_models[0] if ollama_models else "[No models available]"
        
        # If gpt-oss:20b is available, prefer it as default
        if "gpt-oss:20b" in ollama_models:
            default_model = "gpt-oss:20b"
        elif "gpt-oss-coder:20b" in ollama_models:
            default_model = "gpt-oss-coder:20b"
        
        return {
            "required": {
                "prompt": ("STRING", {
                    "default": "Melodic trance sequencer pattern in E minor with chord changes and bassline.",
                    "multiline": True
                }),
                "api_key": ("STRING", {
                    "default": "your-api-key-here",
                    "multiline": False
                }),
                "llm_provider": (["local", "ollama", "openai", "anthropic"], {
                    "default": "ollama"
                }),
                "model": (ollama_models, {
                    "default": default_model
                }),
                "temperature": ("FLOAT", {
                    "default": 1.2,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.1
                }),
                "seed": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 999999,
                    "step": 1
                }),
                "bpm": ("INT", {
                    "default": 128,
                    "min": 60,
                    "max": 200,
                    "step": 1
                }),
                "duration": ("INT", {
                    "default": 30,
                    "min": 4,
                    "max": 60,
                    "step": 1
                }),
                "output_filename": ("STRING", {
                    "default": "llm_generated",
                    "multiline": False
                })
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("midi_path",)
    FUNCTION = "generate_midi"
    CATEGORY = "absynth-vst"
    
    def _extract_key_from_prompt(self, prompt):
        """Extract musical key from prompt text"""
        import re
        
        prompt_lower = prompt.lower()
        
        # Define key patterns
        major_keys = ['c major', 'd major', 'e major', 'f major', 'g major', 'a major', 'b major',
                      'c# major', 'd# major', 'f# major', 'g# major', 'a# major',
                      'db major', 'eb major', 'gb major', 'ab major', 'bb major']
        
        minor_keys = ['c minor', 'd minor', 'e minor', 'f minor', 'g minor', 'a minor', 'b minor',
                      'c# minor', 'd# minor', 'f# minor', 'g# minor', 'a# minor',
                      'db minor', 'eb minor', 'gb minor', 'ab minor', 'bb minor']
        
        # Check for explicit key mentions
        for key in major_keys + minor_keys:
            if key in prompt_lower:
                note = key.split()[0].replace('#', 'sharp').replace('b', 'flat')
                mode = 'maj' if 'major' in key else 'min'
                return f"{note.capitalize()}{mode}"
        
        # Check for shortened versions (e.g., "Em", "Am", "C#m")
        short_pattern = r'\b([A-G][#b]?)(m(?:in)?|maj(?:or)?)\b'
        match = re.search(short_pattern, prompt_lower, re.IGNORECASE)
        if match:
            note = match.group(1).replace('#', 'sharp').replace('b', 'flat')
            mode = 'min' if 'm' in match.group(2).lower() else 'maj'
            return f"{note.capitalize()}{mode}"
        
        # Default if no key found
        return "Cmaj"
    
    def generate_midi(self, prompt, api_key, llm_provider, model, temperature, seed, bpm, duration, output_filename):
        """Generate MIDI using LLM or fallback to Circle of Fifths"""
        try:
            import random
            import time
            import re
            
            # Handle random seed
            if seed == -1:
                actual_seed = random.randint(0, 999999)
            else:
                actual_seed = seed
            
            random.seed(actual_seed)
            
            # IMPROVED: Extract key from prompt
            key_info = self._extract_key_from_prompt(prompt)
            
            # IMPROVED: Create informative filename with KEY and BPM
            timestamp = int(time.time())
            
            # Clean output_filename (remove spaces, special chars)
            clean_name = re.sub(r'[^\w\-]', '_', output_filename)
            
            # Build filename: name_key_bpm_seed_timestamp.mid
            filename = f"{clean_name}_{key_info}_{bpm}bpm_{actual_seed}_{timestamp}.mid"
            output_path = os.path.join(self._default_midi_folder, filename)
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] LLM MIDI Generator v{self.VERSION}")
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] Prompt: {prompt}")
            print(f"[Absynth-VST] Detected Key: {key_info}")
            print(f"[Absynth-VST] Provider: {llm_provider}, Model: {model}")
            print(f"[Absynth-VST] BPM: {bpm}, Duration: {duration}s")
            print(f"[Absynth-VST] Temperature: {temperature}, Seed: {actual_seed}")
            print(f"[Absynth-VST] Output: {filename}")
            
            # System prompt for code generation
            system_prompt = f"""You are a Python MIDI code generator. Generate Python code using the midiutil library.

REQUIREMENTS:
- Use 'from midiutil import MIDIFile'
- Set BPM to {bpm}
- Create music lasting approximately {duration} seconds
- Save file as '{filename}'
- Use the user's musical description to create appropriate melodies/basslines/patterns
- Output ONLY the Python code, no explanations

EXAMPLE CODE STRUCTURE:
```python
from midiutil import MIDIFile
import math

bpm = {bpm}
duration_seconds = {duration}
beats_total = math.ceil((bpm / 60.0) * duration_seconds)
beat_unit = 1.0  # quarter note = 1 beat

midi = MIDIFile(1)
track = 0
channel = 0

midi.addTempo(track, 0, bpm)
midi.addProgramChange(track, channel, 0, 81)  # Synth Lead

# Your melody/pattern here
melody = [60, 62, 64, 65, 67]  # C major scale example
note_length = 0.5  # eighth notes
velocity = 100
time = 0.0

for note in melody:
    midi.addNote(track, channel, note, time, note_length, velocity)
    time += note_length

with open("{filename}", "wb") as f:
    midi.writeFile(f)
```

Generate creative, musical code based on: {prompt}"""
            
            # Call LLM based on provider
            llm_response = None
            
            if llm_provider == "ollama":
                print(f"[Absynth-VST] Calling Ollama with model: {model}")
                llm_response = self._call_ollama(model, system_prompt, prompt, temperature)
            elif llm_provider == "openai":
                print(f"[Absynth-VST] Calling OpenAI with model: {model}")
                llm_response = self._call_openai(api_key, model, system_prompt, prompt, temperature)
            elif llm_provider == "anthropic":
                print(f"[Absynth-VST] Calling Anthropic with model: {model}")
                llm_response = self._call_anthropic(api_key, model, system_prompt, prompt, temperature)
            elif llm_provider == "local":
                print(f"[Absynth-VST] Using local fallback generation")
                return (self._create_fallback_midi(prompt, filename, bpm, duration, key_info),)
            else:
                print(f"[Absynth-VST] Unknown provider: {llm_provider}")
                return ("Error: Unknown LLM provider",)
            
            # Parse and execute Python code
            if llm_response:
                print(f"[Absynth-VST] ✓ LLM response received ({len(llm_response)} chars)")
                success = self._execute_generated_code(llm_response, filename, bpm, duration)
                
                if success and os.path.exists(output_path):
                    print(f"[Absynth-VST] ✓ MIDI generated by LLM: {output_path}")
                    print(f"[Absynth-VST] ==================")
                    return (output_path,)
                else:
                    print("[Absynth-VST] ⚠ LLM code execution failed, using fallback")
                    return (self._create_fallback_midi(prompt, filename, bpm, duration, key_info),)
            else:
                print("[Absynth-VST] ✗ No LLM response, using fallback")
                return (self._create_fallback_midi(prompt, filename, bpm, duration, key_info),)
            
        except Exception as e:
            error_msg = f"[Absynth-VST] Error: {str(e)}"
            print(error_msg)
            import traceback
            traceback.print_exc()
            # Return fallback MIDI on error
            return (self._create_fallback_midi(prompt, f"fallback_error_{bpm}bpm.mid", bpm, duration, "Cmaj"),)
    
    def _call_ollama(self, model, system_prompt, user_prompt, temperature):
        """Call Ollama API"""
        try:
            import requests
            url = "http://localhost:11434/api/generate"
            full_prompt = f"{system_prompt}\n\nUser request: {user_prompt}"
            
            payload = {
                "model": model,
                "prompt": full_prompt,
                "stream": False,
                "options": {"temperature": temperature}
            }
            
            print(f"[Absynth-VST] Sending request to Ollama...")
            response = requests.post(url, json=payload, timeout=120)
            
            if response.status_code == 200:
                result = response.json()
                return result.get("response", "")
            else:
                print(f"[Absynth-VST] ✗ Ollama error: {response.status_code}")
                return None
                
        except requests.exceptions.ConnectionError:
            print("[Absynth-VST] ✗ Ollama not running! Start Ollama first")
            return None
        except ImportError:
            print("[Absynth-VST] ✗ Requests library not installed. Run: pip install requests")
            return None
        except Exception as e:
            print(f"[Absynth-VST] ✗ Ollama error: {e}")
            return None
    
    def _call_openai(self, api_key, model, system_prompt, user_prompt, temperature):
        """Call OpenAI API"""
        try:
            import openai
            client = openai.OpenAI(api_key=api_key)
            
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=temperature
            )
            
            return response.choices[0].message.content
        except ImportError:
            print("[Absynth-VST] ✗ OpenAI library not installed. Run: pip install openai")
            return None
        except Exception as e:
            print(f"[Absynth-VST] ✗ OpenAI API error: {e}")
            return None
    
    def _call_anthropic(self, api_key, model, system_prompt, user_prompt, temperature):
        """Call Anthropic API"""
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=api_key)
            
            message = client.messages.create(
                model=model,
                max_tokens=2048,
                temperature=temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}]
            )
            
            return message.content[0].text
        except ImportError:
            print("[Absynth-VST] ✗ Anthropic library not installed. Run: pip install anthropic")
            return None
        except Exception as e:
            print(f"[Absynth-VST] ✗ Anthropic API error: {e}")
            return None
    
    def _execute_generated_code(self, llm_response, filename, bpm, duration):
        """Execute the Python code generated by LLM"""
        try:
            # Extract code from markdown code blocks if present
            code = llm_response.strip()
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] EXTRACTING CODE FROM LLM RESPONSE")
            print(f"[Absynth-VST] ==================")
            
            # IMPROVED: Remove <think> tags and other model-specific artifacts
            import re
            
            # Remove <think>...</think> or <thinking>...</thinking> blocks
            code = re.sub(r'<think>.*?</think>', '', code, flags=re.DOTALL | re.IGNORECASE)
            code = re.sub(r'<thinking>.*?</thinking>', '', code, flags=re.DOTALL | re.IGNORECASE)
            
            # IMPROVED: Extract code from markdown - handle multiple blocks
            code_blocks = []
            
            # Try to find ```python blocks first
            python_blocks = re.findall(r'```python\s*(.*?)```', code, re.DOTALL)
            if python_blocks:
                print(f"[Absynth-VST] Found {len(python_blocks)} ```python``` blocks")
                code_blocks.extend(python_blocks)
            else:
                # Try generic ``` blocks
                generic_blocks = re.findall(r'```\s*(.*?)```', code, re.DOTALL)
                if generic_blocks:
                    print(f"[Absynth-VST] Found {len(generic_blocks)} generic ``` blocks")
                    code_blocks.extend(generic_blocks)
            
            # If we found code blocks, use the longest one (most likely the main code)
            if code_blocks:
                code = max(code_blocks, key=len).strip()
                print(f"[Absynth-VST] Using longest code block ({len(code)} chars)")
            else:
                print(f"[Absynth-VST] No markdown code blocks found, using full response")
            
            # Additional cleanup
            code = code.replace('```python', '').replace('```', '').strip()
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] EXTRACTED CODE ({len(code)} chars):")
            print(f"[Absynth-VST] ==================")
            print(code[:500])
            if len(code) > 500:
                print(f"[Absynth-VST] ... (truncated)")
            print(f"[Absynth-VST] ==================")
            
            # Validate code looks like Python
            if not any(keyword in code for keyword in ['import', 'from', 'def', 'class', '=']):
                print(f"[Absynth-VST] ✗ ERROR: Extracted code doesn't look like Python!")
                return False
            
            # Prepare safe execution environment
            safe_globals = {
                '__builtins__': __builtins__,
                'MIDIFile': None,
                'math': None,
                'os': None,
                'print': print
            }
            
            # Import required modules in safe environment
            import math
            from midiutil import MIDIFile
            safe_globals['MIDIFile'] = MIDIFile
            safe_globals['math'] = math
            
            # Change to MIDI directory before execution
            original_dir = os.getcwd()
            os.chdir(self._default_midi_folder)
            
            try:
                # Execute the generated code
                print(f"[Absynth-VST] Executing generated code...")
                exec(code, safe_globals)
                print(f"[Absynth-VST] ✓ Code executed successfully")
                
                # Check if file was created
                if os.path.exists(filename):
                    print(f"[Absynth-VST] ✓ MIDI file created: {filename}")
                    return True
                else:
                    print(f"[Absynth-VST] ✗ MIDI file not found after execution")
                    return False
                    
            finally:
                # Always restore original directory
                os.chdir(original_dir)
            
        except Exception as e:
            print(f"[Absynth-VST] ✗ Code execution error: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _create_fallback_midi(self, prompt, filename, bpm, duration, key_info):
        """Create a musically sophisticated fallback MIDI"""
        print(f"[Absynth-VST] Using fallback MIDI generation")
        print(f"[Absynth-VST] Key: {key_info}, BPM: {bpm}")
        
        output_path = os.path.join(self._default_midi_folder, filename)
        
        try:
            import random
            
            mid = mido.MidiFile(type=0, ticks_per_beat=480)
            track = mido.MidiTrack()
            mid.tracks.append(track)
            
            # Metadata
            track.append(mido.MetaMessage('track_name', name=f'Absynth VST - {key_info}', time=0))
            
            # Set tempo
            tempo = mido.bpm2tempo(bpm)
            track.append(mido.MetaMessage('set_tempo', tempo=tempo, time=0))
            print(f"[Absynth-VST] ✓ Tempo: {bpm} BPM ({tempo} µs/beat)")
            
            # Time signature (4/4)
            track.append(mido.MetaMessage('time_signature', numerator=4, denominator=4, 
                                         clocks_per_click=24, notated_32nd_notes_per_beat=8, time=0))
            
            # Program change
            track.append(mido.Message('program_change', program=81, channel=0, time=0))
            
            # Generate simple melody
            scale = [0, 2, 4, 5, 7, 9, 11]  # Major scale
            root = 60  # C4
            
            beats_total = (bpm / 60.0) * duration
            events = []
            
            # Create melodic phrase
            current_time_beats = 0.0
            note_duration_beats = 0.5
            
            while current_time_beats < beats_total:
                degree = random.choice([0, 2, 4, 5, 7])
                note = root + scale[degree % len(scale)]
                velocity = random.randint(80, 110)
                
                events.append({
                    'time': current_time_beats,
                    'note': note,
                    'duration': note_duration_beats,
                    'velocity': velocity
                })
                
                current_time_beats += note_duration_beats
            
            # Convert events to MIDI messages
            midi_events = []
            for event in events:
                time_ticks = int(event['time'] * 480)
                midi_events.append({
                    'time': time_ticks,
                    'type': 'note_on',
                    'note': event['note'],
                    'velocity': event['velocity']
                })
                midi_events.append({
                    'time': time_ticks + int(event['duration'] * 480),
                    'type': 'note_off',
                    'note': event['note'],
                    'velocity': 0
                })
            
            # Sort by time
            midi_events.sort(key=lambda x: (x['time'], x['type'] == 'note_off'))
            
            # Add with delta times
            last_time_ticks = 0
            for event in midi_events:
                delta_time = event['time'] - last_time_ticks
                
                if event['type'] == 'note_on':
                    track.append(mido.Message('note_on', note=event['note'], 
                                             velocity=event['velocity'], channel=0, time=delta_time))
                else:
                    track.append(mido.Message('note_off', note=event['note'], 
                                             velocity=0, channel=0, time=delta_time))
                
                last_time_ticks = event['time']
            
            # End of track
            track.append(mido.MetaMessage('end_of_track', time=0))
            
            # Save
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            mid.save(output_path)
            
            print(f"[Absynth-VST] ✓ Fallback MIDI created: {output_path}")
            print(f"[Absynth-VST] Notes: {len(events)}")
            
            return output_path
            
        except Exception as e:
            print(f"[Absynth-VST] ✗ Fallback MIDI creation failed: {e}")
            import traceback
            traceback.print_exc()
            return output_path


NODE_CLASS_MAPPINGS = {
    "AbsynthVST": AbsynthVSTNode,
    "AbsynthVSTParameterLister": AbsynthVSTParameterListerNode,
    "AbsynthMIDICreator": AbsynthMIDICreatorNode,
    "AbsynthVSTInfoDisplay": AbsynthVSTInfoDisplayNode,
    "AbsynthLLMMIDIGenerator": AbsynthLLMMIDIGeneratorNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AbsynthVST": "Absynth-VST Player v1.1.1",
    "AbsynthVSTParameterLister": "Absynth-VST Parameter Lister v1.1",
    "AbsynthMIDICreator": "Absynth-VST MIDI Creator v1.1",
    "AbsynthVSTInfoDisplay": "Absynth-VST Info Display v1.1",
    "AbsynthLLMMIDIGenerator": "Absynth-VST LLM MIDI Generator v1.1.1"
}