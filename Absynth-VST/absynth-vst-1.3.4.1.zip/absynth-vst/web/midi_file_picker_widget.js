// Absynth-VST MIDI File Picker Widget
// Adds a Browse button with native file picker dialog

import { app } from "../../scripts/app.js";

app.registerExtension({
    name: "Absynth.MIDIFilePicker",

    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        if (nodeData.name === "AbsynthMIDIFilePicker") {

            const onNodeCreated = nodeType.prototype.onNodeCreated;
            nodeType.prototype.onNodeCreated = function() {
                const result = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;

                // Find the midi_file_path widget
                const pathWidget = this.widgets?.find(w => w.name === "midi_file_path");

                if (pathWidget) {
                    // Create file input element (hidden)
                    const fileInput = document.createElement("input");
                    fileInput.type = "file";
                    fileInput.accept = ".mid,.midi";
                    fileInput.style.display = "none";
                    document.body.appendChild(fileInput);

                    // Add browse button widget
                    const browseButton = this.addWidget(
                        "button",
                        "Browse for MIDI",
                        "browse",
                        () => {
                            // Trigger file picker
                            fileInput.click();
                        }
                    );

                    // Handle file selection
                    fileInput.addEventListener("change", async (e) => {
                        if (e.target.files && e.target.files[0]) {
                            const file = e.target.files[0];

                            console.log(`[MIDI Picker] Selected file: ${file.name} (${file.size} bytes)`);

                            // Update helper text to show uploading
                            helpText.value = `⏳ Uploading ${file.name}...`;

                            // Upload file to server
                            try {
                                const formData = new FormData();
                                formData.append('file', file);

                                const response = await fetch('/absynth-vst/upload-midi', {
                                    method: 'POST',
                                    body: formData
                                });

                                const result = await response.json();

                                if (result.status === 'success') {
                                    // Set the server-side path
                                    pathWidget.value = result.path;
                                    helpText.value = `✓ ${result.filename}`;

                                    console.log(`[MIDI Picker] Upload success: ${result.path}`);

                                    // Mark graph as needing execution
                                    if (this.graph) {
                                        this.graph.setDirtyCanvas(true);
                                    }
                                } else {
                                    console.error(`[MIDI Picker] Upload failed: ${result.message}`);
                                    helpText.value = `✗ Upload failed: ${result.message}`;
                                }
                            } catch (error) {
                                console.error(`[MIDI Picker] Upload error:`, error);
                                helpText.value = `✗ Upload error: ${error.message}`;
                            }

                            // Reset file input so same file can be selected again
                            fileInput.value = '';
                        }
                    });

                    // Cleanup on node removal
                    const onRemoved = this.onRemoved;
                    this.onRemoved = function() {
                        fileInput.remove();
                        if (onRemoved) {
                            onRemoved.apply(this, arguments);
                        }
                    };

                    // Add helper text widget
                    const helpText = this.addWidget(
                        "text",
                        "Status",
                        "No file selected",
                        () => {},
                        {
                            serialize: false,
                            multiline: false
                        }
                    );
                    helpText.disabled = true;
                }

                return result;
            };
        }
    }
});
