// Absynth-VST Ollama Model Scanner Widget
// Dynamically loads Ollama models and provides dropdown for STRING model widgets

import { app } from "../../scripts/app.js";

// Track if we've scanned Ollama models already this session
let ollamaModelsScanned = false;
let cachedOllamaModels = [];

// Node types that have model widgets for LLM
const LLM_NODE_TYPES = [
    "AbsynthLLMMIDIGenerator",
    "AbsynthLLMPresetMaker",
    "AbsynthLoopMIDIGenerator"
];

async function scanOllamaModels() {
    console.log("[Ollama Scanner] Scanning for Ollama models...");

    try {
        const response = await fetch('/absynth-vst/scan-ollama-models');
        const result = await response.json();

        if (result.status === 'success') {
            ollamaModelsScanned = true;
            cachedOllamaModels = result.models;
            console.log(`[Ollama Scanner] Found ${result.count} Ollama models:`, result.models);
            return result.models;
        } else {
            console.error("[Ollama Scanner] Scan failed:", result.message);
            return [];
        }
    } catch (error) {
        console.error("[Ollama Scanner] Error scanning:", error);
        return [];
    }
}

function updateComboWidget(widget, models) {
    if (!widget || !models || models.length === 0) return;

    // Build the new options list with refresh option at the end
    const newOptions = [...models, "[Refresh models...]"];

    // Update widget options
    widget.options.values = newOptions;

    // If current value is a placeholder, select the first real model
    if (widget.value && (widget.value.startsWith("[") || !models.includes(widget.value))) {
        // Keep current value if it's a valid model, otherwise select first
        if (!models.includes(widget.value)) {
            widget.value = newOptions[0];
        }
    }

    console.log(`[Ollama Scanner] Updated combo widget with ${models.length} models`);
}

// Convert STRING widget to combo for model selection
function convertStringToCombo(node, widget, models) {
    if (!widget || !models || models.length === 0) return;

    const currentValue = widget.value || "llama3.2:latest";
    const widgetIndex = node.widgets.indexOf(widget);

    if (widgetIndex === -1) return;

    // Create options list
    const options = [...models, "[Refresh models...]"];

    // Remove old widget
    node.widgets.splice(widgetIndex, 1);

    // Add combo widget in same position
    const comboWidget = node.addWidget("combo", "model", currentValue, function(value) {
        if (value === "[Refresh models...]") {
            // Force rescan
            ollamaModelsScanned = false;
            scanOllamaModels().then(newModels => {
                if (newModels && newModels.length > 0) {
                    comboWidget.options.values = [...newModels, "[Refresh models...]"];
                    comboWidget.value = newModels[0];
                    node.setDirtyCanvas(true);
                }
            });
            return;
        }
    }, { values: options });

    // Move to correct position
    const movedWidget = node.widgets.pop();
    node.widgets.splice(widgetIndex, 0, movedWidget);

    // Restore value if it exists in models
    if (models.includes(currentValue)) {
        comboWidget.value = currentValue;
    } else if (currentValue && !currentValue.startsWith("[")) {
        // Keep custom value even if not in list
        comboWidget.value = currentValue;
    }

    console.log(`[Ollama Scanner] Converted STRING widget to combo with ${models.length} models`);
    node.setDirtyCanvas(true);

    return comboWidget;
}

app.registerExtension({
    name: "Absynth.OllamaModelScanner",

    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        if (!LLM_NODE_TYPES.includes(nodeData.name)) {
            return;
        }

        const onNodeCreated = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function() {
            const result = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;
            const node = this;

            // Find the model widget
            const modelWidget = this.widgets?.find(w => w.name === "model");

            if (!modelWidget) return result;

            // Handle COMBO type widgets (legacy nodes)
            if (modelWidget.type === "combo") {
                // Store original callback
                const originalCallback = modelWidget.callback;

                // Track if we've populated this widget
                let widgetPopulated = false;

                // Override the callback to detect "[Refresh models...]" selection
                modelWidget.callback = async function(value, graphCanvas, node, pos, event) {
                    if (value === "[Refresh models...]") {
                        console.log("[Ollama Scanner] Refresh requested...");
                        // Force rescan
                        ollamaModelsScanned = false;
                        const models = await scanOllamaModels();
                        if (models && models.length > 0) {
                            updateComboWidget(modelWidget, models);
                            // Select first model after refresh
                            modelWidget.value = models[0];
                            widgetPopulated = true;
                        }
                        return;
                    }

                    if (originalCallback) {
                        return originalCallback.apply(this, arguments);
                    }
                };

                // Override mouse down to trigger scan on first click
                const originalOnMouseDown = modelWidget.onMouseDown;
                modelWidget.onMouseDown = async function(e, pos, graphNode) {
                    if (!widgetPopulated && !ollamaModelsScanned) {
                        const models = await scanOllamaModels();
                        if (models && models.length > 0) {
                            updateComboWidget(modelWidget, models);
                            widgetPopulated = true;
                        }
                    }

                    if (originalOnMouseDown) {
                        return originalOnMouseDown.apply(this, arguments);
                    }
                };

                // If models are already cached, populate immediately
                if (ollamaModelsScanned && cachedOllamaModels.length > 0) {
                    updateComboWidget(modelWidget, cachedOllamaModels);
                    widgetPopulated = true;
                }
            }
            // Handle STRING type widgets (new approach)
            else if (modelWidget.type === "text" || modelWidget.type === "string") {
                // Scan models and convert to combo
                setTimeout(async () => {
                    let models = cachedOllamaModels;
                    if (!ollamaModelsScanned || models.length === 0) {
                        models = await scanOllamaModels();
                    }
                    if (models && models.length > 0) {
                        convertStringToCombo(node, modelWidget, models);
                    }
                }, 100);
            }

            return result;
        };
    },

    // Handle when nodes are loaded from a workflow
    async nodeCreated(node) {
        if (!LLM_NODE_TYPES.includes(node.comfyClass)) {
            return;
        }

        const modelWidget = node.widgets?.find(w => w.name === "model");
        if (!modelWidget) return;

        // Handle COMBO widgets
        if (modelWidget.type === "combo") {
            const currentValue = modelWidget.value;

            // If value is a real model name (not a placeholder), ensure it's in the options
            if (currentValue && !currentValue.startsWith("[")) {
                // Scan to get the full list
                if (!ollamaModelsScanned) {
                    const models = await scanOllamaModels();
                    if (models && models.length > 0) {
                        updateComboWidget(modelWidget, models);
                        // Restore the saved value if it exists
                        if (models.includes(currentValue)) {
                            modelWidget.value = currentValue;
                        }
                    }
                } else if (cachedOllamaModels.length > 0) {
                    updateComboWidget(modelWidget, cachedOllamaModels);
                    if (cachedOllamaModels.includes(currentValue)) {
                        modelWidget.value = currentValue;
                    }
                }
            }
        }
        // Handle STRING widgets - convert to combo
        else if (modelWidget.type === "text" || modelWidget.type === "string") {
            setTimeout(async () => {
                let models = cachedOllamaModels;
                if (!ollamaModelsScanned || models.length === 0) {
                    models = await scanOllamaModels();
                }
                if (models && models.length > 0) {
                    convertStringToCombo(node, modelWidget, models);
                }
            }, 100);
        }
    }
});
