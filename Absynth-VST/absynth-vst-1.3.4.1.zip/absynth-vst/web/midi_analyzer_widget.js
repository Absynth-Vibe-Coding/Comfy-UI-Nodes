import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

app.registerExtension({
    name: "Absynth.MIDIAnalyzer",
    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        if (nodeData.name === "AbsynthMIDIAnalyzer") {
            const onNodeCreated = nodeType.prototype.onNodeCreated;

            nodeType.prototype.onNodeCreated = function() {
                const result = onNodeCreated?.apply(this, arguments);

                // Find the path widget and hide it
                const pathWidget = this.widgets.find(w => w.name === "midi_file_path");
                if (pathWidget) {
                    pathWidget.type = "converted-widget";
                    pathWidget.computeSize = () => [0, -4]; // Hide it
                }

                // Create hidden file input for browsing
                const fileInput = document.createElement("input");
                fileInput.type = "file";
                fileInput.accept = ".mid,.midi";
                fileInput.style.display = "none";
                document.body.appendChild(fileInput);

                // Add browse button - ONLY control needed!
                const browseBtn = this.addWidget("button", "📁 Browse MIDI File", "browse", () => {
                    fileInput.click();
                });

                // Add status text to show current file
                const statusWidget = this.addWidget("text", "📄 Selected File", "No file selected", () => {}, {
                    serialize: false
                });
                statusWidget.disabled = true;

                // Handle file selection - upload and auto-load
                fileInput.addEventListener("change", async (e) => {
                    const file = e.target.files[0];
                    if (!file) return;

                    statusWidget.value = `⏳ Loading ${file.name}...`;

                    // Upload file to plugin folder
                    const formData = new FormData();
                    formData.append('file', file);

                    try {
                        const response = await fetch('/absynth-vst/upload-midi', {
                            method: 'POST',
                            body: formData
                        });

                        const result = await response.json();

                        if (result.status === 'success') {
                            // Set the hidden path widget to the uploaded file path
                            pathWidget.value = result.path;
                            statusWidget.value = `✅ ${result.filename}`;

                            console.log('[MIDI Analyzer] File loaded:', result.filename);
                            console.log('[MIDI Analyzer] Path:', result.path);

                            // Force the node to update
                            if (pathWidget.callback) {
                                pathWidget.callback(result.path);
                            }
                        } else {
                            statusWidget.value = `❌ Error: ${result.message}`;
                            console.error('[MIDI Analyzer] Upload failed:', result.message);
                        }
                    } catch (error) {
                        statusWidget.value = `❌ Failed to load file`;
                        console.error('[MIDI Analyzer] Error:', error);
                    }

                    // Reset file input so same file can be re-selected
                    fileInput.value = '';
                });

                // Cleanup on remove
                const onRemoved = this.onRemoved;
                this.onRemoved = function() {
                    fileInput.remove();
                    if (onRemoved) {
                        onRemoved.apply(this, arguments);
                    }
                };

                return result;
            };
        }
    }
});
