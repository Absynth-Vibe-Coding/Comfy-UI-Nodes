// Absynth-VST Plugin Scanner Widget
// Dynamically loads VST plugins when the dropdown is clicked

import { app } from "../../scripts/app.js";

// Track if we've scanned VST plugins already this session
let vstPluginsScanned = false;
let cachedVstPlugins = [];
let vstCache = {};

// Node types that have VST_PLUGIN or vst_plugin combo widgets
const VST_NODE_TYPES = [
    "AbsynthVST",
    "AbsynthVSTEditor",
    "AbsynthLLMPresetMaker"
];

async function scanVstPlugins() {
    if (vstPluginsScanned && cachedVstPlugins.length > 0) {
        console.log("[VST Scanner] Using cached plugins:", cachedVstPlugins.length);
        return { plugins: cachedVstPlugins, cache: vstCache };
    }

    console.log("[VST Scanner] Scanning for VST plugins...");

    try {
        const response = await fetch('/absynth-vst/scan-vst-plugins');
        const result = await response.json();

        if (result.status === 'success') {
            vstPluginsScanned = true;
            cachedVstPlugins = result.plugins;
            vstCache = result.cache;
            console.log(`[VST Scanner] Found ${result.count} VST plugins`);
            return result;
        } else {
            console.error("[VST Scanner] Scan failed:", result.message);
            return { plugins: [], cache: {} };
        }
    } catch (error) {
        console.error("[VST Scanner] Error scanning:", error);
        return { plugins: [], cache: {} };
    }
}

function updateComboWidget(widget, plugins, nodeType) {
    if (!widget || !plugins || plugins.length === 0) return;

    // Build the new options list based on node type
    let newOptions;
    if (nodeType === "AbsynthVST") {
        // AbsynthVST has special "[Receive from Editor]" option
        newOptions = ["[Receive from Editor]", ...plugins];
    } else {
        newOptions = [...plugins];
    }

    // Update widget options
    widget.options.values = newOptions;

    // If current value is a placeholder, select the first real plugin
    if (widget.value && widget.value.startsWith("[Click to scan")) {
        widget.value = newOptions[0];
    }

    console.log(`[VST Scanner] Updated ${nodeType} widget with ${newOptions.length} options`);
}

app.registerExtension({
    name: "Absynth.VSTPluginScanner",

    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        if (!VST_NODE_TYPES.includes(nodeData.name)) {
            return;
        }

        const onNodeCreated = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function() {
            const result = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;

            // Find the VST plugin widget (could be VST_PLUGIN or vst_plugin)
            const vstWidget = this.widgets?.find(w =>
                w.name === "VST_PLUGIN" || w.name === "vst_plugin"
            );

            if (vstWidget && vstWidget.type === "combo") {
                // Store original callback
                const originalCallback = vstWidget.callback;

                // Track if we've populated this widget
                let widgetPopulated = false;

                // Override the mouse down handler to trigger scan on first click
                const originalOnMouseDown = vstWidget.onMouseDown;
                vstWidget.onMouseDown = async function(e, pos, node) {
                    // Scan plugins if not yet populated
                    if (!widgetPopulated) {
                        const scanResult = await scanVstPlugins();
                        if (scanResult.plugins && scanResult.plugins.length > 0) {
                            updateComboWidget(vstWidget, scanResult.plugins, nodeData.name);
                            widgetPopulated = true;
                        }
                    }

                    // Call original handler
                    if (originalOnMouseDown) {
                        return originalOnMouseDown.apply(this, arguments);
                    }
                };

                // Also trigger scan when combo is drawn and options are accessed
                const originalDrawOptions = vstWidget.drawOptions;
                vstWidget.drawOptions = async function() {
                    if (!widgetPopulated) {
                        const scanResult = await scanVstPlugins();
                        if (scanResult.plugins && scanResult.plugins.length > 0) {
                            updateComboWidget(vstWidget, scanResult.plugins, nodeData.name);
                            widgetPopulated = true;
                        }
                    }
                    if (originalDrawOptions) {
                        return originalDrawOptions.apply(this, arguments);
                    }
                };

                // Wrap callback to ensure cache is available
                vstWidget.callback = async function(value, graphCanvas, node, pos, event) {
                    // Make sure we've scanned
                    if (!vstPluginsScanned) {
                        await scanVstPlugins();
                    }

                    if (originalCallback) {
                        return originalCallback.apply(this, arguments);
                    }
                };

                // If plugins are already cached, populate immediately
                if (vstPluginsScanned && cachedVstPlugins.length > 0) {
                    updateComboWidget(vstWidget, cachedVstPlugins, nodeData.name);
                    widgetPopulated = true;
                }
            }

            return result;
        };
    },

    // Also handle when nodes are loaded from a workflow
    async nodeCreated(node) {
        if (!VST_NODE_TYPES.includes(node.comfyClass)) {
            return;
        }

        // Find the VST plugin widget
        const vstWidget = node.widgets?.find(w =>
            w.name === "VST_PLUGIN" || w.name === "vst_plugin"
        );

        if (vstWidget && vstWidget.type === "combo") {
            // Check if the saved value is valid (not a placeholder)
            const currentValue = vstWidget.value;

            // If value is a real plugin name, we need to make sure it's in the options
            if (currentValue && !currentValue.startsWith("[")) {
                // This is a real plugin name from a saved workflow
                // Scan to get the full list and ensure this plugin is available
                const scanResult = await scanVstPlugins();
                if (scanResult.plugins && scanResult.plugins.length > 0) {
                    updateComboWidget(vstWidget, scanResult.plugins, node.comfyClass);

                    // Restore the saved value if it exists in the new options
                    if (scanResult.plugins.includes(currentValue)) {
                        vstWidget.value = currentValue;
                    }
                }
            }
        }
    }
});
