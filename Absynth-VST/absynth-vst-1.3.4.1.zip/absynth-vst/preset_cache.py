#!/usr/bin/env python3
"""
Preset Generation Cache System - Persistent memory for LLM-generated presets
Stores generation history on user's PC to prevent repetitive outputs
"""

import os
import json
import hashlib
import time
from collections import defaultdict


class PresetGenerationCache:
    """Persistent cache system for tracking preset generations"""

    def __init__(self, cache_file="preset_generation_cache.json"):
        self._script_dir = os.path.dirname(os.path.abspath(__file__))
        self.cache_file = os.path.join(self._script_dir, cache_file)
        self.cache = self._load_cache()

    def _load_cache(self):
        """Load generation history from disk"""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"[Preset Cache] Warning: Could not load cache: {e}")
                return self._empty_cache()
        return self._empty_cache()

    def _empty_cache(self):
        """Create empty cache structure"""
        return {
            "version": "1.0",
            "created": time.time(),
            "total_generations": 0,
            "generations": [],
            "preset_signatures": {}
        }

    def _save_cache(self):
        """Save cache to user's PC"""
        try:
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.cache, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[Preset Cache] Warning: Could not save cache: {e}")

    def _extract_preset_signature(self, parameters):
        """Extract preset fingerprint from parameters for similarity comparison"""
        try:
            # Create a compact signature of the preset's characteristics
            signature = {
                "components": list(parameters.keys()),
                "param_count": sum(len(params) if isinstance(params, dict) else 0 for params in parameters.values()),
                "param_hash": self._hash_parameters(parameters),
            }

            # Extract key parameter values for comparison
            key_params = {}

            # Oscillator parameters
            if "Oscillator0" in parameters and isinstance(parameters["Oscillator0"], dict):
                osc = parameters["Oscillator0"]
                key_params["osc0"] = {
                    "volume": osc.get("kParamVolume", 0),
                    "unison": osc.get("kParamUnison", 0),
                    "detune": osc.get("kParamDetune", 0),
                }

            # Filter parameters
            if "Filter0" in parameters and isinstance(parameters["Filter0"], dict):
                flt = parameters["Filter0"]
                key_params["filter0"] = {
                    "cutoff": flt.get("kParamCutoff", 0),
                    "resonance": flt.get("kParamResonance", 0),
                }

            # Envelope parameters
            if "Env0" in parameters and isinstance(parameters["Env0"], dict):
                env = parameters["Env0"]
                key_params["env0"] = {
                    "attack": env.get("kParamAttack", 0),
                    "decay": env.get("kParamDecay", 0),
                    "sustain": env.get("kParamSustain", 0),
                    "release": env.get("kParamRelease", 0),
                }

            # FX presence
            if "FXRack0" in parameters and isinstance(parameters["FXRack0"], dict):
                fx_rack = parameters["FXRack0"]
                if "FX" in fx_rack and isinstance(fx_rack["FX"], list):
                    key_params["fx_types"] = []
                    for fx in fx_rack["FX"]:
                        if isinstance(fx, dict):
                            # Extract FX type names
                            for fx_name in fx.keys():
                                if fx_name != "type":
                                    key_params["fx_types"].append(fx_name)

            signature["key_params"] = key_params
            return signature

        except Exception as e:
            print(f"[Preset Cache] Warning: Could not extract signature: {e}")
            return None

    def _hash_parameters(self, parameters):
        """Create hash from parameters"""
        try:
            # Create a deterministic string representation
            param_str = json.dumps(parameters, sort_keys=True)
            return hashlib.md5(param_str.encode()).hexdigest()[:16]
        except:
            return "unknown"

    def add_generation(self, preset_path, prompt, parameters, llm_provider, model, temperature, seed, metadata=None):
        """Store new generation in cache"""
        try:
            signature = self._extract_preset_signature(parameters)

            generation_record = {
                "id": self.cache["total_generations"] + 1,
                "timestamp": time.time(),
                "preset_path": preset_path,
                "filename": os.path.basename(preset_path),
                "prompt": prompt,
                "llm_provider": llm_provider,
                "model": model,
                "temperature": temperature,
                "seed": seed,
                "signature": signature,
                "metadata": metadata or {}
            }

            self.cache["generations"].append(generation_record)
            self.cache["total_generations"] += 1

            # Store signature for fast lookup
            if signature:
                sig_hash = signature.get("param_hash", "unknown")
                if sig_hash not in self.cache["preset_signatures"]:
                    self.cache["preset_signatures"][sig_hash] = []
                self.cache["preset_signatures"][sig_hash].append(generation_record["id"])

            self._save_cache()
            print(f"[Preset Cache] Added generation #{generation_record['id']} to cache")

        except Exception as e:
            print(f"[Preset Cache] Warning: Could not add to cache: {e}")

    def find_similar_generations(self, parameters, threshold=0.8, limit=5):
        """Find similar presets in cache based on parameters"""
        try:
            current_signature = self._extract_preset_signature(parameters)
            if not current_signature:
                return []

            similar = []

            for gen in self.cache["generations"]:
                if not gen.get("signature"):
                    continue

                similarity = self._calculate_similarity(current_signature, gen["signature"])
                if similarity >= threshold:
                    similar.append({
                        "generation_id": gen["id"],
                        "filename": gen["filename"],
                        "prompt": gen["prompt"],
                        "similarity": similarity,
                        "timestamp": gen["timestamp"]
                    })

            # Sort by similarity (highest first)
            similar.sort(key=lambda x: x["similarity"], reverse=True)
            return similar[:limit]

        except Exception as e:
            print(f"[Preset Cache] Warning: Could not find similar presets: {e}")
            return []

    def _calculate_similarity(self, sig1, sig2):
        """Calculate similarity score between two preset signatures (0-1)"""
        try:
            score = 0.0
            checks = 0

            # Compare component structure
            if sig1.get("components") == sig2.get("components"):
                score += 0.2
            checks += 1

            # Compare key parameters
            key_params1 = sig1.get("key_params", {})
            key_params2 = sig2.get("key_params", {})

            # Compare oscillator params
            if "osc0" in key_params1 and "osc0" in key_params2:
                osc_sim = self._compare_param_dict(key_params1["osc0"], key_params2["osc0"])
                score += osc_sim * 0.3
                checks += 1

            # Compare filter params
            if "filter0" in key_params1 and "filter0" in key_params2:
                flt_sim = self._compare_param_dict(key_params1["filter0"], key_params2["filter0"])
                score += flt_sim * 0.2
                checks += 1

            # Compare envelope params
            if "env0" in key_params1 and "env0" in key_params2:
                env_sim = self._compare_param_dict(key_params1["env0"], key_params2["env0"])
                score += env_sim * 0.2
                checks += 1

            # Compare FX types
            if "fx_types" in key_params1 and "fx_types" in key_params2:
                fx1_set = set(key_params1["fx_types"])
                fx2_set = set(key_params2["fx_types"])
                if fx1_set and fx2_set:
                    fx_sim = len(fx1_set & fx2_set) / len(fx1_set | fx2_set)
                    score += fx_sim * 0.1
                checks += 1

            return score / checks if checks > 0 else 0.0

        except Exception as e:
            print(f"[Preset Cache] Warning: Could not calculate similarity: {e}")
            return 0.0

    def _compare_param_dict(self, params1, params2, tolerance=0.1):
        """Compare two parameter dictionaries and return similarity score"""
        if not params1 or not params2:
            return 0.0

        common_keys = set(params1.keys()) & set(params2.keys())
        if not common_keys:
            return 0.0

        differences = []
        for key in common_keys:
            val1 = params1[key]
            val2 = params2[key]
            if isinstance(val1, (int, float)) and isinstance(val2, (int, float)):
                # Normalized difference
                max_val = max(abs(val1), abs(val2), 1.0)  # Avoid division by zero
                diff = abs(val1 - val2) / max_val
                differences.append(diff)

        if not differences:
            return 0.0

        avg_diff = sum(differences) / len(differences)
        return 1.0 - avg_diff  # Convert difference to similarity

    def create_anti_repetition_prompt(self, limit=20):
        """Create prompt text with recent generation context"""
        try:
            if self.cache["total_generations"] == 0:
                return ""

            recent = self.cache["generations"][-limit:]

            if not recent:
                return ""

            # Build context about recent presets
            context_parts = []
            context_parts.append("\nRECENT PRESET HISTORY (avoid repeating these characteristics):")

            for gen in recent[-10:]:  # Show last 10
                sig = gen.get("signature", {})
                key_params = sig.get("key_params", {})

                desc_parts = []
                if "osc0" in key_params:
                    osc = key_params["osc0"]
                    desc_parts.append(f"unison={osc.get('unison', '?'):.1f}")
                if "filter0" in key_params:
                    flt = key_params["filter0"]
                    desc_parts.append(f"cutoff={flt.get('cutoff', '?'):.2f}")
                if "fx_types" in key_params:
                    fx_list = key_params["fx_types"]
                    desc_parts.append(f"fx={','.join(fx_list)}")

                desc = ", ".join(desc_parts) if desc_parts else "various params"
                context_parts.append(f"- {gen['filename']}: {desc}")

            return "\n".join(context_parts)

        except Exception as e:
            print(f"[Preset Cache] Warning: Could not create anti-repetition prompt: {e}")
            return ""

    def get_cache_stats(self):
        """Get cache statistics"""
        try:
            total_gens = self.cache["total_generations"]
            unique_sigs = len(self.cache["preset_signatures"])

            # Calculate cache file size
            cache_size = 0
            if os.path.exists(self.cache_file):
                cache_size = os.path.getsize(self.cache_file) / 1024  # KB

            return {
                "total_generations": total_gens,
                "unique_patterns": unique_sigs,
                "cache_size_kb": cache_size,
                "generations": self.cache["generations"]
            }

        except Exception as e:
            print(f"[Preset Cache] Warning: Could not get stats: {e}")
            return {
                "total_generations": 0,
                "unique_patterns": 0,
                "cache_size_kb": 0,
                "generations": []
            }

    def get_total_generations(self):
        """Get total number of generations"""
        return self.cache["total_generations"]

    def clear_cache(self):
        """Clear all cache data"""
        self.cache = self._empty_cache()
        self._save_cache()
        print("[Preset Cache] Cache cleared")

    def get_diversity_report(self):
        """Generate diversity report showing preset variety"""
        try:
            stats = {
                "total_generations": self.cache["total_generations"],
                "unique_signatures": len(self.cache["preset_signatures"]),
                "component_usage": defaultdict(int),
                "fx_usage": defaultdict(int),
                "prompts": []
            }

            for gen in self.cache["generations"][-50:]:  # Last 50
                sig = gen.get("signature", {})

                # Count component usage
                for comp in sig.get("components", []):
                    stats["component_usage"][comp] += 1

                # Count FX usage
                key_params = sig.get("key_params", {})
                for fx_type in key_params.get("fx_types", []):
                    stats["fx_usage"][fx_type] += 1

                # Store prompts
                stats["prompts"].append(gen.get("prompt", ""))

            return stats

        except Exception as e:
            print(f"[Preset Cache] Warning: Could not generate diversity report: {e}")
            return {}
