import os
import numpy as np
import soundfile as sf
import dawdreamer as daw
import mido
import torch

class AbsynthVSTNode:
    """
    Absynth-VST: Load VST instruments and process MIDI input using DawDreamer
    """
    
    # Preset folder is now in custom_nodes/absynth-vst/presets
    # This makes it portable and works for all users
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _default_preset_folder = os.path.join(_script_dir, "presets")
    _default_midi_folder = os.path.join(_script_dir, "midi")
    
    # Create presets folder if it doesn't exist
    if not os.path.exists(_default_preset_folder):
        os.makedirs(_default_preset_folder)
        print(f"[Absynth-VST] Created preset folder: {_default_preset_folder}")
    
    # Create MIDI folder if it doesn't exist
    if not os.path.exists(_default_midi_folder):
        os.makedirs(_default_midi_folder)
        print(f"[Absynth-VST] Created MIDI folder: {_default_midi_folder}")
    
    _preset_cache = {}
    _midi_cache = {}
    
    @classmethod
    def INPUT_TYPES(cls):
        # Scan presets on startup
        presets = cls.scan_presets(cls._default_preset_folder)
        preset_list = ["load preset"] + presets
        
        # Scan MIDI files on startup
        midi_files = cls.scan_midi_files(cls._default_midi_folder)
        midi_list = ["select MIDI file"] + midi_files
        
        return {
            "required": {
                "vst_path": ("STRING", {
                    "default": "C:\\Program Files\\Common Files\\VST3\\Serum2.vst3",
                    "multiline": False
                }),
                "preset": (preset_list, {
                    "default": preset_list[0]
                }),
                "midi_file": (midi_list, {
                    "default": midi_list[0]
                }),
                "sample_rate": ("INT", {
                    "default": 44100,
                    "min": 22050,
                    "max": 192000,
                    "step": 1
                }),
                "buffer_size": ("INT", {
                    "default": 512,
                    "min": 128,
                    "max": 2048,
                    "step": 128
                }),
                "reverb_tail": ("FLOAT", {
                    "default": 2.0,
                    "min": 0.0,
                    "max": 10.0,
                    "step": 0.1,
                    "display": "slider"
                }),
                # Parameter 1
                "parameter_1": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_1_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_1_name": ("STRING", {
                    "default": "cutoff",
                    "multiline": False
                }),
                # Parameter 2
                "parameter_2": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_2_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_2_name": ("STRING", {
                    "default": "reverb",
                    "multiline": False
                }),
                # Parameter 3
                "parameter_3": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_3_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_3_name": ("STRING", {
                    "default": "resonance",
                    "multiline": False
                }),
                # Parameter 4
                "parameter_4": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_4_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_4_name": ("STRING", {
                    "default": "attack",
                    "multiline": False
                }),
                # Parameter 5
                "parameter_5": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_5_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_5_name": ("STRING", {
                    "default": "release",
                    "multiline": False
                }),
                # Parameter 6
                "parameter_6": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_6_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_6_name": ("STRING", {
                    "default": "decay",
                    "multiline": False
                }),
                "output_path": ("STRING", {
                    "default": "./output/vst_audio.wav",
                    "multiline": False
                })
            },
            "optional": {
                "midi_path_input": ("STRING", {
                    "default": "",
                    "forceInput": True
                })
            }
        }
    
    RETURN_TYPES = ("STRING", "AUDIO", "VST_INFO")
    RETURN_NAMES = ("file_path", "audio", "plugin_info")
    FUNCTION = "process_vst"
    CATEGORY = "absynth-vst"
    
    # Known incompatible VSTs (crash DawDreamer at C++ level)
    BLACKLISTED_VSTS = [
        'spire',
        'omnisphere', 
        'kontakt',
        'battery',
        'massive x'
    ]
    
    @classmethod
    def scan_presets(cls, folder):
        """Scan folder for presets and cache paths"""
        preset_list = []
        cls._preset_cache = {}
        
        if not os.path.exists(folder):
            print(f"[Absynth-VST] Preset folder not found: {folder}")
            return preset_list
        
        # Only scan for standard VST3 presets that DawDreamer can load
        extensions = ['.vstpreset']
        
        try:
            print(f"[Absynth-VST] Scanning: {folder}")
            for root, dirs, files in os.walk(folder):
                for file in files:
                    if any(file.lower().endswith(ext) for ext in extensions):
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, folder)
                        cls._preset_cache[rel_path] = full_path
                        preset_list.append(rel_path)
            
            preset_list.sort()
            print(f"[Absynth-VST] Found {len(preset_list)} presets")
        except Exception as e:
            print(f"[Absynth-VST] Scan error: {e}")
        
        return preset_list
    
    @classmethod
    def scan_midi_files(cls, folder):
        """Scan folder for MIDI files and cache paths"""
        midi_list = []
        cls._midi_cache = {}
        
        if not os.path.exists(folder):
            print(f"[Absynth-VST] MIDI folder not found: {folder}")
            return midi_list
        
        # Scan for MIDI files
        extensions = ['.mid', '.midi']
        
        try:
            print(f"[Absynth-VST] Scanning MIDI: {folder}")
            for root, dirs, files in os.walk(folder):
                for file in files:
                    if any(file.lower().endswith(ext) for ext in extensions):
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, folder)
                        cls._midi_cache[rel_path] = full_path
                        midi_list.append(rel_path)
            
            midi_list.sort()
            print(f"[Absynth-VST] Found {len(midi_list)} MIDI files")
        except Exception as e:
            print(f"[Absynth-VST] MIDI scan error: {e}")
        
        return midi_list
    
    def load_midi_events(self, midi_file):
        """Load MIDI and convert to events"""
        midi = mido.MidiFile(midi_file)
        events = []
        active_notes = {}
        current_time = 0.0
        
        for msg in midi:
            current_time += msg.time
            
            if msg.type == 'note_on' and msg.velocity > 0:
                active_notes[msg.note] = {
                    'start_time': current_time,
                    'velocity': msg.velocity
                }
            elif msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0):
                if msg.note in active_notes:
                    note_info = active_notes[msg.note]
                    duration = current_time - note_info['start_time']
                    events.append({
                        'time': note_info['start_time'],
                        'note': msg.note,
                        'velocity': note_info['velocity'],
                        'duration': duration
                    })
                    del active_notes[msg.note]
        
        for note, info in active_notes.items():
            events.append({
                'time': info['start_time'],
                'note': note,
                'velocity': info['velocity'],
                'duration': 1.0
            })
        
        events.sort(key=lambda x: x['time'])
        return events, current_time
    
    def process_vst(self, vst_path, preset, midi_file, sample_rate, buffer_size, reverb_tail=2.0,
                   parameter_1=-1.0, parameter_1_index=-1, parameter_1_name="cutoff",
                   parameter_2=-1.0, parameter_2_index=-1, parameter_2_name="reverb",
                   parameter_3=-1.0, parameter_3_index=-1, parameter_3_name="resonance",
                   parameter_4=-1.0, parameter_4_index=-1, parameter_4_name="attack",
                   parameter_5=-1.0, parameter_5_index=-1, parameter_5_name="release",
                   parameter_6=-1.0, parameter_6_index=-1, parameter_6_name="decay",
                   output_path="./output/vst_audio.wav",
                   midi_path_input=""):
        """Main processing function with comprehensive error handling"""
        
        # Pre-flight checks
        if not os.path.exists(vst_path):
            print(f"[Absynth-VST] ✗ VST file not found: {vst_path}")
            empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
            return (f"Error: VST not found", empty_audio, None)
        
        # PRIORITY 1: Use midi_path_input if provided (from LLM node)
        # PRIORITY 2: Use midi_file dropdown selection
        
        midi_path = None
        
        if midi_path_input and midi_path_input.strip():
            # Direct path provided from another node (e.g., LLM Generator)
            midi_path = midi_path_input.strip()
            print(f"[Absynth-VST] Using connected MIDI input: {os.path.basename(midi_path)}")
            
            if not os.path.exists(midi_path):
                print(f"[Absynth-VST] ✗ Connected MIDI file not found: {midi_path}")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Connected MIDI file not found", empty_audio, None)
        else:
            # Use dropdown selection
            if midi_file == "select MIDI file":
                print(f"[Absynth-VST] ✗ No MIDI file selected")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Please select a MIDI file or connect a MIDI input", empty_audio, None)
            
            # Resolve MIDI file path from cache
            midi_path = self._midi_cache.get(midi_file, "")
            
            if not midi_path:
                # If not in cache, try as absolute path
                midi_path = midi_file if os.path.isabs(midi_file) else os.path.join(self._default_midi_folder, midi_file)
            
            if not os.path.exists(midi_path):
                print(f"[Absynth-VST] ✗ MIDI file not found: {midi_path}")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: MIDI file not found", empty_audio, None)
        
        # Check blacklist
        vst_name = os.path.basename(vst_path).lower()
        for blacklisted in self.BLACKLISTED_VSTS:
            if blacklisted in vst_name:
                error_msg = f"VST '{os.path.basename(vst_path)}' is BLACKLISTED (crashes DawDreamer)"
                print(f"[Absynth-VST] ✗✗✗ {error_msg}")
                print(f"[Absynth-VST] This VST is known to crash at C++ level")
                print(f"[Absynth-VST] Cannot be used with DawDreamer")
                print(f"[Absynth-VST] Recommended alternatives:")
                print(f"[Absynth-VST] - Vital (free, similar to Serum)")
                print(f"[Absynth-VST] - Surge XT (free, powerful)")
                print(f"[Absynth-VST] - Serum (confirmed working)")
                print(f"[Absynth-VST] - Dexed (free FM synth)")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return (error_msg, empty_audio, None)
        
        try:
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] Starting VST processing...")
            print(f"[Absynth-VST] VST: {os.path.basename(vst_path)}")
            print(f"[Absynth-VST] ==================")
            
            # Wrap everything in try-except to prevent crashes
            try:
                print(f"[Absynth-VST] Initializing DawDreamer engine...")
                engine = daw.RenderEngine(sample_rate, buffer_size)
                print(f"[Absynth-VST] ✓ Engine initialized")
            except Exception as engine_error:
                print(f"[Absynth-VST] ✗ Engine init failed: {engine_error}")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return (f"Error: DawDreamer engine failed", empty_audio, None)
            
            print(f"[Absynth-VST] Attempting to load VST...")
            print(f"[Absynth-VST] Path: {vst_path}")
            
            if not (vst_path.endswith('.vst3') or vst_path.endswith('.vst') or vst_path.endswith('.dll')):
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Unsupported format. Use .vst, .vst3, or .dll", empty_audio, None)
            
            # Try to load VST with maximum error handling
            try:
                print(f"[Absynth-VST] Creating plugin processor...")
                synth = engine.make_plugin_processor("synth", vst_path)
                print(f"[Absynth-VST] ✓ Plugin loaded: {synth.get_name()}")
            except RuntimeError as runtime_err:
                print(f"[Absynth-VST] ✗ RuntimeError loading VST: {runtime_err}")
                print(f"[Absynth-VST] This VST is not compatible with DawDreamer")
                print(f"[Absynth-VST] Try: Serum, Vital, Surge XT, Dexed (known working VSTs)")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return (f"VST incompatible: {str(runtime_err)}", empty_audio, None)
            except Exception as vst_error:
                print(f"[Absynth-VST] ✗ Failed to load VST: {vst_error}")
                print(f"[Absynth-VST] Possible issues:")
                print(f"[Absynth-VST] - VST requires GUI/display to function")
                print(f"[Absynth-VST] - VST uses unsupported copy protection")
                print(f"[Absynth-VST] - VST architecture mismatch (32-bit vs 64-bit)")
                print(f"[Absynth-VST] Recommended working VSTs: Serum, Vital, Surge XT, Dexed")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return (f"Error loading VST: {str(vst_error)}", empty_audio, None)
            
            # Load preset
            preset_loaded = False
            if preset != "load preset":
                preset_path = self._preset_cache.get(preset, "")
                
                if not preset_path:
                    preset_path = os.path.join(self._default_preset_folder, preset)
                
                if os.path.exists(preset_path):
                    print(f"[Absynth-VST] ==================")
                    print(f"[Absynth-VST] Loading: {preset}")
                    print(f"[Absynth-VST] Path: {preset_path}")
                    
                    try:
                        # For VST3, use load_vst3_preset with file path
                        synth.load_vst3_preset(preset_path)
                        print(f"[Absynth-VST] ✓✓✓ PRESET LOADED SUCCESSFULLY ✓✓✓")
                        preset_loaded = True
                        
                    except Exception as e:
                        print(f"[Absynth-VST] ✗ Failed with load_vst3_preset: {e}")
                        
                        # Fallback: try load_state
                        try:
                            with open(preset_path, 'rb') as f:
                                preset_data = f.read()
                            synth.load_state(preset_data)
                            print(f"[Absynth-VST] ✓✓✓ PRESET LOADED WITH load_state ✓✓✓")
                            preset_loaded = True
                        except Exception as fallback_err:
                            print(f"[Absynth-VST] ✗ All methods failed")
                            print(f"[Absynth-VST] Using init sound...")
                            import traceback
                            traceback.print_exc()
                    
                    print(f"[Absynth-VST] ==================")
                else:
                    print(f"[Absynth-VST] Preset not found: {preset_path}")
            else:
                print(f"[Absynth-VST] Using init sound")
            
            # Apply custom parameters
            # Priority: Manual index > Auto search by name
            params_to_set = []
            
            # Build parameter list
            param_configs = [
                (1, parameter_1, parameter_1_index, parameter_1_name),
                (2, parameter_2, parameter_2_index, parameter_2_name),
                (3, parameter_3, parameter_3_index, parameter_3_name),
                (4, parameter_4, parameter_4_index, parameter_4_name),
                (5, parameter_5, parameter_5_index, parameter_5_name),
                (6, parameter_6, parameter_6_index, parameter_6_name),
            ]
            
            for param_num, value, manual_index, search_name in param_configs:
                if value >= 0.0:
                    # Generate search terms based on the name
                    search_terms = [search_name.lower()]
                    params_to_set.append((f'Parameter {param_num} ({search_name})', value, manual_index, search_terms))
            
            if params_to_set:
                print(f"[Absynth-VST] ==================")
                print(f"[Absynth-VST] PARAMETER CONTROL")
                print(f"[Absynth-VST] ==================")
                
                param_count = synth.get_plugin_parameter_size()
                print(f"[Absynth-VST] VST has {param_count} total parameters")
                
                applied_count = 0
                
                for param_name, value, manual_index, search_terms in params_to_set:
                    print(f"\n[Absynth-VST] ╔═══════════════════════════════")
                    print(f"[Absynth-VST] Setting: '{param_name}' = {value:.3f}")
                    
                    param_index = None
                    
                    # Method 1: Use manual index if specified
                    if manual_index >= 0:
                        print(f"[Absynth-VST] Using MANUAL index: {manual_index}")
                        param_index = manual_index
                        
                        try:
                            param_name_actual = synth.get_parameter_name(manual_index)
                            print(f"[Absynth-VST] Parameter name: '{param_name_actual}'")
                        except:
                            print(f"[Absynth-VST] ⚠ Warning: Index {manual_index} might be invalid")
                    
                    # Method 2: Auto-search by name
                    else:
                        print(f"[Absynth-VST] AUTO-SEARCHING with terms: {search_terms}")
                        matches = []
                        
                        for search_term in search_terms:
                            search_lower = search_term.lower()
                            
                            for i in range(param_count):
                                try:
                                    vst_param_name = synth.get_parameter_name(i)
                                    vst_param_lower = vst_param_name.lower()
                                    
                                    if search_lower in vst_param_lower:
                                        current_val = synth.get_parameter(i)
                                        matches.append({
                                            'index': i,
                                            'name': vst_param_name,
                                            'value': current_val
                                        })
                                except:
                                    continue
                        
                        if matches:
                            print(f"[Absynth-VST] Found {len(matches)} matching parameters:")
                            for match in matches[:5]:  # Show first 5
                                print(f"[Absynth-VST]   [{match['index']:3d}] {match['name']:40s} = {match['value']:.3f}")
                            
                            if len(matches) > 5:
                                print(f"[Absynth-VST]   ... and {len(matches)-5} more")
                            
                            # Use first match
                            param_index = matches[0]['index']
                            print(f"[Absynth-VST] Using: [{param_index}] {matches[0]['name']}")
                        else:
                            print(f"[Absynth-VST] ✗ NO MATCHES FOUND")
                            print(f"[Absynth-VST] TIP: Use Parameter Lister to find the exact parameter")
                            print(f"[Absynth-VST] Then set the parameter index manually")
                            continue
                    
                    # Apply the parameter
                    if param_index is not None:
                        try:
                            print(f"[Absynth-VST] ─────────────────────────────")
                            
                            # Get before
                            old_value = synth.get_parameter(param_index)
                            print(f"[Absynth-VST] Before: {old_value:.3f}")
                            
                            # Set parameter
                            synth.set_parameter(param_index, value)
                            
                            # Get after
                            new_value = synth.get_parameter(param_index)
                            print(f"[Absynth-VST] After:  {new_value:.3f}")
                            
                            # Verify
                            if abs(new_value - value) < 0.001:
                                print(f"[Absynth-VST] ✓✓✓ SUCCESS!")
                                applied_count += 1
                            else:
                                print(f"[Absynth-VST] ⚠⚠⚠ WARNING!")
                                print(f"[Absynth-VST] Expected {value:.3f} but got {new_value:.3f}")
                                print(f"[Absynth-VST] This parameter might be controlled by the preset")
                                print(f"[Absynth-VST] Try loading preset='load preset' (init sound) instead")
                        
                        except Exception as e:
                            print(f"[Absynth-VST] ✗ Error setting parameter: {e}")
                
                print(f"\n[Absynth-VST] ╚═══════════════════════════════")
                print(f"[Absynth-VST] Applied {applied_count}/{len(params_to_set)} parameters")
                print(f"[Absynth-VST] ==================")
            else:
                print(f"[Absynth-VST] No parameters to apply (all are -1.0)")
            
            plugin_info = {
                'name': synth.get_name(),
                'preset': preset,
                'preset_loaded': preset_loaded
            }
            
            print(f"[Absynth-VST] Loading MIDI: {midi_path}")
            midi_events, midi_duration = self.load_midi_events(midi_path)
            print(f"[Absynth-VST] {len(midi_events)} notes, {midi_duration:.2f}s")
            
            # Render duration = MIDI length + reverb tail
            render_duration = midi_duration + reverb_tail
            print(f"[Absynth-VST] Rendering {render_duration:.2f}s (MIDI: {midi_duration:.2f}s + tail: {reverb_tail:.1f}s)")
            
            # Add MIDI notes
            for event in midi_events:
                synth.add_midi_note(
                    event['note'],
                    event['velocity'],
                    event['time'],
                    event['duration']
                )
            
            engine.load_graph([(synth, [])])
            engine.render(render_duration)
            
            audio_data = engine.get_audio()
            print(f"[Absynth-VST] Audio: {audio_data.shape}")
            
            # Save WAV
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            sf.write(output_path, audio_data.T, sample_rate)
            print(f"[Absynth-VST] ✓ Saved: {output_path}")
            
            # Convert to torch for ComfyUI
            audio_tensor = torch.from_numpy(audio_data).float().unsqueeze(0)
            audio_output = {"waveform": audio_tensor, "sample_rate": sample_rate}
            
            return (output_path, audio_output, plugin_info)
            
        except Exception as e:
            error_msg = f"[Absynth-VST] Error: {str(e)}"
            print(error_msg)
            import traceback
            traceback.print_exc()
            
            empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
            return (error_msg, empty_audio, None)


class AbsynthVSTParameterListerNode:
    """List all available parameters from a VST plugin"""
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "vst_path": ("STRING", {
                    "default": "C:\\Program Files\\Common Files\\VST3\\Serum2.vst3",
                    "multiline": False
                }),
                "search_filter": ("STRING", {
                    "default": "",
                    "multiline": False
                }),
                "sample_rate": ("INT", {
                    "default": 44100,
                    "min": 22050,
                    "max": 192000
                })
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("parameter_list",)
    FUNCTION = "list_parameters"
    CATEGORY = "absynth-vst"
    OUTPUT_NODE = True
    
    def list_parameters(self, vst_path, search_filter, sample_rate):
        """List all parameters with their indices, names, and current values"""
        try:
            if not os.path.exists(vst_path):
                return ("Error: VST not found",)
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] Loading VST to list parameters...")
            engine = daw.RenderEngine(sample_rate, 512)
            synth = engine.make_plugin_processor("synth", vst_path)
            
            param_count = synth.get_plugin_parameter_size()
            print(f"[Absynth-VST] Found {param_count} parameters")
            
            param_lines = [f"=== {synth.get_name()} Parameters ==="]
            param_lines.append(f"Total: {param_count} parameters\n")
            
            # Apply search filter
            search_lower = search_filter.lower().strip()
            matched_count = 0
            
            for i in range(param_count):
                try:
                    name = synth.get_parameter_name(i)
                    
                    # Skip if doesn't match filter
                    if search_lower and search_lower not in name.lower():
                        continue
                    
                    matched_count += 1
                    value = synth.get_parameter(i)
                    text = synth.get_parameter_text(i)
                    
                    param_lines.append(f"[{i:4d}] {name:50s} = {value:.3f} ({text})")
                except Exception as e:
                    param_lines.append(f"[{i:4d}] Error reading parameter: {e}")
            
            if search_lower:
                param_lines.append(f"\nMatched {matched_count} parameters with filter '{search_filter}'")
            
            result = "\n".join(param_lines)
            print(result)
            print(f"[Absynth-VST] ==================")
            
            return (result,)
            
        except Exception as e:
            error = f"Error listing parameters: {str(e)}"
            print(f"[Absynth-VST] {error}")
            import traceback
            traceback.print_exc()
            return (error,)


class AbsynthMIDICreatorNode:
    """Create simple MIDI files"""
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "notes": ("STRING", {"default": "60,64,67"}),
                "velocities": ("STRING", {"default": "100,100,100"}),
                "durations": ("STRING", {"default": "1.0,1.0,1.0"}),
                "output_path": ("STRING", {"default": "./output/test_midi.mid"})
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("midi_path",)
    FUNCTION = "create_midi"
    CATEGORY = "absynth-vst"
    
    def create_midi(self, notes, velocities, durations, output_path):
        try:
            note_list = [int(n.strip()) for n in notes.split(',')]
            velocity_list = [int(v.strip()) for v in velocities.split(',')]
            duration_list = [float(d.strip()) for d in durations.split(',')]
            
            mid = mido.MidiFile()
            track = mido.MidiTrack()
            mid.tracks.append(track)
            
            for note, velocity, duration in zip(note_list, velocity_list, duration_list):
                track.append(mido.Message('note_on', note=note, velocity=velocity, time=0))
                track.append(mido.Message('note_off', note=note, velocity=0, time=int(duration * 480)))
            
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            mid.save(output_path)
            print(f"[Absynth-VST] ✓ MIDI: {output_path}")
            return (output_path,)
        except Exception as e:
            error = f"Error: {str(e)}"
            print(f"[Absynth-VST] {error}")
            return (error,)


class AbsynthVSTInfoDisplayNode:
    """Display VST plugin information"""
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "vst_info": ("VST_INFO",)
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("info_text",)
    FUNCTION = "display_info"
    CATEGORY = "absynth-vst"
    OUTPUT_NODE = True
    
    def display_info(self, vst_info):
        """Format and display VST info"""
        if not vst_info:
            return ("No VST info available",)
        
        info_lines = ["=== VST INFO ==="]
        
        if 'name' in vst_info:
            info_lines.append(f"Plugin: {vst_info['name']}")
        
        if 'preset' in vst_info:
            info_lines.append(f"Preset: {vst_info['preset']}")
        
        if 'preset_loaded' in vst_info:
            status = "✓ Loaded" if vst_info['preset_loaded'] else "✗ Not loaded (using init)"
            info_lines.append(f"Status: {status}")
        
        info_text = "\n".join(info_lines)
        print(f"[Absynth-VST] {info_text}")
        
        return (info_text,)


class AbsynthLLMMIDIGeneratorNode:
    """Generate MIDI using an LLM from text prompts"""
    
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _default_midi_folder = os.path.join(_script_dir, "midi")
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": ("STRING", {
                    "default": "Create a dark techno bassline in D minor",
                    "multiline": True
                }),
                "api_key": ("STRING", {
                    "default": "your-api-key-here",
                    "multiline": False
                }),
                "llm_provider": (["local", "ollama", "openai", "anthropic"], {
                    "default": "local"
                }),
                "model": ("STRING", {
                    "default": "llama2",
                    "multiline": False
                }),
                "temperature": ("FLOAT", {
                    "default": 0.8,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.1
                }),
                "seed": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 999999,
                    "step": 1
                }),
                "bpm": ("INT", {
                    "default": 128,
                    "min": 60,
                    "max": 200,
                    "step": 1
                }),
                "duration": ("INT", {
                    "default": 10,
                    "min": 4,
                    "max": 60,
                    "step": 1
                }),
                "control_after_generate": (["randomize", "keep"], {
                    "default": "randomize"
                }),
                "output_filename": ("STRING", {
                    "default": "llm_generated",
                    "multiline": False
                })
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("midi_path",)
    FUNCTION = "generate_midi"
    CATEGORY = "absynth-vst"
    
    def generate_midi(self, prompt, api_key, llm_provider, model, temperature, seed, bpm, duration, control_after_generate, output_filename):
        """Generate MIDI using LLM - now generates Python code!"""
        try:
            # Handle random seed
            import random
            if seed == -1:
                actual_seed = random.randint(0, 999999)
            else:
                actual_seed = seed
            
            # Set random seed for reproducibility
            random.seed(actual_seed)
            
            # Create unique filename
            import time
            timestamp = int(time.time())
            filename = f"{output_filename}_{actual_seed}_{timestamp}.mid"
            output_path = os.path.join(self._default_midi_folder, filename)
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] LLM MIDI Code Generation")
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] Prompt: {prompt}")
            print(f"[Absynth-VST] Provider: {llm_provider}, Model: {model}")
            print(f"[Absynth-VST] BPM: {bpm}, Duration: {duration}s")
            print(f"[Absynth-VST] Temperature: {temperature}, Seed: {actual_seed}")
            
            # System prompt for code generation
            system_prompt = f"""You are a Python MIDI code generator. Generate Python code using the midiutil library.

REQUIREMENTS:
- Use 'from midiutil import MIDIFile'
- Set BPM to {bpm}
- Create music lasting approximately {duration} seconds
- Save file as '{filename}'
- Use the user's musical description to create appropriate melodies/basslines/patterns
- Output ONLY the Python code, no explanations

EXAMPLE CODE STRUCTURE:
```python
from midiutil import MIDIFile
import math

bpm = {bpm}
duration_seconds = {duration}
beats_total = math.ceil((bpm / 60.0) * duration_seconds)
beat_unit = 1.0  # quarter note = 1 beat

midi = MIDIFile(1)
track = 0
channel = 0

midi.addTempo(track, 0, bpm)
midi.addProgramChange(track, channel, 0, 81)  # Synth Lead

# Your melody/pattern here
melody = [60, 62, 64, 65, 67]  # C major scale example
note_length = 0.5  # eighth notes
velocity = 100
time = 0.0

for note in melody:
    midi.addNote(track, channel, note, time, note_length, velocity)
    time += note_length

with open("{filename}", "wb") as f:
    midi.writeFile(f)
```

Generate creative, musical code based on: {prompt}"""
            
            # Call LLM based on provider
            if llm_provider == "ollama":
                llm_response = self._call_ollama(model, system_prompt, prompt, temperature)
            elif llm_provider == "openai":
                llm_response = self._call_openai(api_key, model, system_prompt, prompt, temperature)
            elif llm_provider == "anthropic":
                llm_response = self._call_anthropic(api_key, model, system_prompt, prompt, temperature)
            elif llm_provider == "local":
                return (self._create_fallback_midi(prompt, filename, bpm, duration),)
            else:
                return ("Error: Unknown LLM provider",)
            
            # Parse and execute Python code
            if llm_response:
                success = self._execute_generated_code(llm_response, filename, bpm, duration)
                
                if success and os.path.exists(output_path):
                    print(f"[Absynth-VST] ✓ MIDI generated: {output_path}")
                    print(f"[Absynth-VST] ==================")
                    return (output_path,)
                else:
                    print("[Absynth-VST] Code execution failed, using fallback")
                    return (self._create_fallback_midi(prompt, filename, bpm, duration),)
            else:
                print("[Absynth-VST] No LLM response, using fallback")
                return (self._create_fallback_midi(prompt, filename, bpm, duration),)
            
        except Exception as e:
            error_msg = f"[Absynth-VST] Error: {str(e)}"
            print(error_msg)
            import traceback
            traceback.print_exc()
            # Return fallback MIDI on error
            return (self._create_fallback_midi(prompt, "fallback_error.mid", bpm, duration),)
    
    def _call_ollama(self, model, system_prompt, user_prompt, temperature):
        try:
            import requests
            url = "http://localhost:11434/api/generate"
            full_prompt = f"{system_prompt}\n\nUser request: {user_prompt}"
            
            payload = {
                "model": model,
                "prompt": full_prompt,
                "stream": False,
                "options": {"temperature": temperature}
            }
            
            print(f"[Absynth-VST] Calling Ollama with model: {model}, temp: {temperature}")
            response = requests.post(url, json=payload, timeout=60)
            
            if response.status_code == 200:
                result = response.json()
                return result.get("response", "")
            else:
                print(f"[Absynth-VST] Ollama error: {response.status_code}")
                return None
                
        except requests.exceptions.ConnectionError:
            print("[Absynth-VST] Ollama not running! Start Ollama first: https://ollama.com")
            print("[Absynth-VST] Using fallback generator...")
            return None
        except ImportError:
            print("[Absynth-VST] Requests library not installed. Run: pip install requests")
            return None
        except Exception as e:
            print(f"[Absynth-VST] Ollama error: {e}")
            return None
    
    def _call_openai(self, api_key, model, system_prompt, user_prompt, temperature):
        try:
            import openai
            client = openai.OpenAI(api_key=api_key)
            
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=temperature
            )
            
            return response.choices[0].message.content
        except ImportError:
            print("[Absynth-VST] OpenAI library not installed. Run: pip install openai")
            return None
        except Exception as e:
            print(f"[Absynth-VST] OpenAI API error: {e}")
            return None
    
    def _call_anthropic(self, api_key, model, system_prompt, user_prompt, temperature):
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=api_key)
            
            message = client.messages.create(
                model=model,
                max_tokens=1024,
                temperature=temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}]
            )
            
            return message.content[0].text
        except ImportError:
            print("[Absynth-VST] Anthropic library not installed. Run: pip install anthropic")
            return None
        except Exception as e:
            print(f"[Absynth-VST] Anthropic API error: {e}")
            return None
    
    def _execute_generated_code(self, llm_response, filename, bpm, duration):
        """Execute the Python code generated by LLM"""
        try:
            # Extract code from markdown code blocks if present
            code = llm_response.strip()
            
            # Remove markdown code blocks
            if "```python" in code:
                code = code.split("```python")[1].split("```")[0].strip()
            elif "```" in code:
                code = code.split("```")[1].split("```")[0].strip()
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] GENERATED CODE:")
            print(f"[Absynth-VST] ==================")
            print(code)
            print(f"[Absynth-VST] ==================")
            
            # Ensure the code saves to the correct directory
            output_path = os.path.join(self._default_midi_folder, filename)
            
            # Prepare safe execution environment
            safe_globals = {
                '__builtins__': __builtins__,
                'MIDIFile': None,  # Will be imported
                'math': None,
                'os': None,
                'print': print
            }
            
            # Import required modules in safe environment
            import math
            from midiutil import MIDIFile
            safe_globals['MIDIFile'] = MIDIFile
            safe_globals['math'] = math
            
            # Change to MIDI directory before execution
            original_dir = os.getcwd()
            os.chdir(self._default_midi_folder)
            
            try:
                # Execute the generated code
                print(f"[Absynth-VST] Executing generated code...")
                exec(code, safe_globals)
                print(f"[Absynth-VST] ✓ Code executed successfully")
                
                # Check if file was created
                if os.path.exists(filename):
                    print(f"[Absynth-VST] ✓ MIDI file created: {filename}")
                    return True
                else:
                    print(f"[Absynth-VST] ✗ MIDI file not found after execution")
                    return False
                    
            finally:
                # Always restore original directory
                os.chdir(original_dir)
            
        except Exception as e:
            print(f"[Absynth-VST] ✗ Code execution error: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _create_fallback_midi(self, prompt, filename, bpm, duration):
        """Create a musically sophisticated fallback MIDI with proper phrasing"""
        print("[Absynth-VST] Using fallback MIDI generation")
        
        output_path = os.path.join(self._default_midi_folder, filename)
        
        try:
            # Try midiutil first (preferred)
            try:
                from midiutil import MIDIFile
                use_midiutil = True
                print("[Absynth-VST] Using midiutil for fallback")
            except ImportError:
                print("[Absynth-VST] midiutil not found, using mido for fallback")
                use_midiutil = False
            
            import random
            # Extract seed from filename to ensure reproducibility
            seed_match = filename.split('_')
            if len(seed_match) >= 2:
                try:
                    seed = int(seed_match[-2])
                    random.seed(seed)
                except:
                    pass
            
            # Parse prompt for musical characteristics
            prompt_lower = prompt.lower()
            
            # Determine musical type
            is_chords = 'chord' in prompt_lower or 'progression' in prompt_lower
            is_riff = 'riff' in prompt_lower or 'pattern' in prompt_lower or 'groove' in prompt_lower
            is_pad = 'pad' in prompt_lower or 'ambient' in prompt_lower or 'atmosphere' in prompt_lower
            is_bass = 'bass' in prompt_lower and not is_chords
            
            # Determine key and scale based on prompt
            if 'minor' in prompt_lower or 'dark' in prompt_lower or 'sad' in prompt_lower:
                # Minor scales
                if 'd minor' in prompt_lower or 'd min' in prompt_lower:
                    root = 50  # D
                    scale = [0, 2, 3, 5, 7, 8, 10]  # Natural minor
                    scale_name = "D Minor"
                elif 'a minor' in prompt_lower or 'a min' in prompt_lower:
                    root = 57  # A
                    scale = [0, 2, 3, 5, 7, 8, 10]
                    scale_name = "A Minor"
                elif 'e minor' in prompt_lower or 'e min' in prompt_lower:
                    root = 52  # E
                    scale = [0, 2, 3, 5, 7, 8, 10]
                    scale_name = "E Minor"
                elif 'c minor' in prompt_lower or 'c min' in prompt_lower:
                    root = 48  # C
                    scale = [0, 2, 3, 5, 7, 8, 10]
                    scale_name = "C Minor"
                elif 'g minor' in prompt_lower or 'g min' in prompt_lower:
                    root = 55  # G
                    scale = [0, 2, 3, 5, 7, 8, 10]
                    scale_name = "G Minor"
                elif 'b minor' in prompt_lower or 'b min' in prompt_lower:
                    root = 59  # B
                    scale = [0, 2, 3, 5, 7, 8, 10]
                    scale_name = "B Minor"
                elif 'f minor' in prompt_lower or 'f min' in prompt_lower:
                    root = 53  # F
                    scale = [0, 2, 3, 5, 7, 8, 10]
                    scale_name = "F Minor"
                else:
                    root = 60  # C
                    scale = [0, 2, 3, 5, 7, 8, 10]
                    scale_name = "C Minor"
            else:
                # Major scales
                if 'd major' in prompt_lower or 'd maj' in prompt_lower:
                    root = 50  # D
                    scale = [0, 2, 4, 5, 7, 9, 11]  # Major
                    scale_name = "D Major"
                elif 'a major' in prompt_lower or 'a maj' in prompt_lower:
                    root = 57  # A
                    scale = [0, 2, 4, 5, 7, 9, 11]
                    scale_name = "A Major"
                elif 'c major' in prompt_lower or 'c maj' in prompt_lower:
                    root = 48  # C
                    scale = [0, 2, 4, 5, 7, 9, 11]
                    scale_name = "C Major"
                elif 'g major' in prompt_lower or 'g maj' in prompt_lower:
                    root = 55  # G
                    scale = [0, 2, 4, 5, 7, 9, 11]
                    scale_name = "G Major"
                elif 'b major' in prompt_lower or 'b maj' in prompt_lower:
                    root = 59  # B
                    scale = [0, 2, 4, 5, 7, 9, 11]
                    scale_name = "B Major"
                elif 'f major' in prompt_lower or 'f maj' in prompt_lower:
                    root = 53  # F
                    scale = [0, 2, 4, 5, 7, 9, 11]
                    scale_name = "F Major"
                else:
                    root = 60  # C
                    scale = [0, 2, 4, 5, 7, 9, 11]
                    scale_name = "C Major"
            
            print(f"[Absynth-VST] Key: {scale_name}")
            
            # Determine octave range and characteristics
            if is_bass:
                root = 36  # Low bass range
                octave_range = 2
                velocity_base = 100
                velocity_variation = 20
            elif is_pad:
                root = 48
                octave_range = 3
                velocity_base = 65
                velocity_variation = 10
            elif is_riff:
                root = 55
                octave_range = 2
                velocity_base = 95
                velocity_variation = 15
            else:  # Melody/lead
                root = 60
                octave_range = 2
                velocity_base = 90
                velocity_variation = 20
            
            phrases = []
            current_time = 0.0
            beats_total = (bpm / 60.0) * duration
            
            print(f"[Absynth-VST] Target duration: {duration}s = {beats_total:.2f} beats at {bpm} BPM")
            print(f"[Absynth-VST] Type: {'Chords' if is_chords else 'Riff' if is_riff else 'Pad' if is_pad else 'Bass' if is_bass else 'Melody'}")
            
            # Generate appropriate musical content
            while current_time < beats_total:
                if is_chords:
                    phrase = self._generate_chord_progression(
                        root, scale, 4.0, velocity_base, velocity_variation
                    )
                elif is_riff:
                    phrase = self._generate_riff(
                        root, scale, octave_range, velocity_base, velocity_variation
                    )
                elif is_pad:
                    phrase = self._generate_pad(
                        root, scale, 8.0, velocity_base, velocity_variation
                    )
                else:
                    phrase = self._generate_musical_phrase(
                        root, scale, octave_range, 8, prompt_lower, 
                        velocity_base, velocity_variation
                    )
                
                if not phrase:
                    print("[Absynth-VST] WARNING: Empty phrase generated")
                    break
                
                # Adjust phrase times
                for note_data in phrase:
                    note_data['time'] += current_time
                
                phrases.extend(phrase)
                
                # Calculate phrase duration
                if phrase:
                    phrase_end = max(n['time'] + n['duration'] for n in phrase)
                    phrase_duration = phrase_end - current_time
                    current_time += phrase_duration
                else:
                    current_time += 4.0
            
            if not phrases:
                print("[Absynth-VST] WARNING: No phrases generated, creating default")
                for i in range(8):
                    phrases.append({
                        'note': root + scale[i % len(scale)],
                        'time': float(i * 0.5),
                        'duration': 0.5,
                        'velocity': velocity_base
                    })
            
            actual_duration = max(n['time'] + n['duration'] for n in phrases) if phrases else 0
            print(f"[Absynth-VST] Generated {len(phrases)} notes, actual duration: {actual_duration:.2f} beats ({actual_duration / (bpm / 60.0):.2f}s)")
            
            if use_midiutil:
                from midiutil import MIDIFile
                
                midi = MIDIFile(1)
                track = 0
                channel = 0
                
                midi.addTempo(track, 0, bpm)
                
                # Set program based on type
                if is_pad:
                    midi.addProgramChange(track, channel, 0, 89)  # Pad 2 (warm)
                elif is_bass:
                    midi.addProgramChange(track, channel, 0, 38)  # Synth Bass 1
                else:
                    midi.addProgramChange(track, channel, 0, 81)  # Lead 2 (sawtooth)
                
                notes_added = 0
                last_note_end = {}
                
                phrases_sorted = sorted(phrases, key=lambda x: x['time'])
                
                for note_data in phrases_sorted:
                    note = note_data['note']
                    start_time = note_data['time']
                    duration_beats = note_data['duration']
                    velocity = note_data['velocity']
                    
                    # Validate
                    note = max(0, min(127, int(note)))
                    velocity = max(1, min(127, int(velocity)))
                    start_time = max(0.0, float(start_time))
                    duration_beats = max(0.1, float(duration_beats))
                    
                    # Prevent overlaps
                    if note in last_note_end:
                        if start_time < last_note_end[note]:
                            gap = 0.05
                            start_time = last_note_end[note] + gap
                    
                    end_time = start_time + duration_beats
                    last_note_end[note] = end_time
                    
                    try:
                        midi.addNote(track, channel, note, start_time, duration_beats, velocity)
                        notes_added += 1
                    except Exception as note_error:
                        print(f"[Absynth-VST] Warning: Skipped note {note} at {start_time}: {note_error}")
                        continue
                
                if notes_added == 0:
                    print("[Absynth-VST] ERROR: No notes added, creating default")
                    midi.addNote(track, channel, 60, 0.0, 1.0, 100)
                    notes_added = 1
                
                print(f"[Absynth-VST] Added {notes_added} notes to MIDI file")
                
                os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
                
                with open(output_path, "wb") as f:
                    midi.writeFile(f)
                
                if os.path.exists(output_path):
                    file_size = os.path.getsize(output_path)
                    print(f"[Absynth-VST] MIDI file size: {file_size} bytes")
            
            else:
                # Fallback to mido
                mid = mido.MidiFile()
                track = mido.MidiTrack()
                mid.tracks.append(track)
                
                tempo = mido.bpm2tempo(bpm)
                track.append(mido.MetaMessage('set_tempo', tempo=tempo, time=0))
                
                for note_data in sorted(phrases, key=lambda x: x['time']):
                    note = note_data['note']
                    duration_beats = note_data['duration']
                    velocity = note_data['velocity']
                    duration_ticks = int(duration_beats * 480)
                    
                    track.append(mido.Message('note_on', note=note, velocity=velocity, time=0))
                    track.append(mido.Message('note_off', note=note, velocity=0, time=duration_ticks))
                
                os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
                mid.save(output_path)
            
            print(f"[Absynth-VST] ✓ Fallback MIDI created: {output_path}")
            return output_path
            
        except Exception as e:
            print(f"[Absynth-VST] ✗ Fallback MIDI creation failed: {e}")
            import traceback
            traceback.print_exc()
            return output_path
    
    def _generate_chord_progression(self, root, scale, chord_duration, velocity_base, velocity_variation):
        """Generate a chord progression"""
        import random
        
        chords = []
        
        # Common chord progressions (scale degrees)
        progressions = [
            [0, 3, 4, 0],      # I-IV-V-I
            [0, 4, 3, 0],      # I-V-IV-I
            [0, 5, 3, 4],      # I-vi-IV-V
            [0, 4, 5, 3],      # I-V-vi-IV
            [5, 3, 0, 4],      # vi-IV-I-V
            [0, 2, 3, 4],      # I-iii-IV-V
        ]
        
        progression = random.choice(progressions)
        
        current_time = 0.0
        
        for degree in progression:
            # Build chord (root, third, fifth)
            chord_root = root + scale[degree % len(scale)]
            
            # Third (2 steps up in scale)
            third_degree = (degree + 2) % len(scale)
            third_note = chord_root + scale[third_degree] - scale[degree]
            if third_note <= chord_root:
                third_note += 12
            
            # Fifth (4 steps up in scale)
            fifth_degree = (degree + 4) % len(scale)
            fifth_note = chord_root + scale[fifth_degree] - scale[degree]
            if fifth_note <= third_note:
                fifth_note += 12
            
            # Optional: Add octave above root for richness
            octave_note = chord_root + 12
            
            # Add all chord notes with same start time
            velocity = velocity_base + random.randint(-velocity_variation, velocity_variation)
            velocity = max(40, min(127, velocity))
            
            for note in [chord_root, third_note, fifth_note, octave_note]:
                chords.append({
                    'note': max(12, min(120, note)),
                    'time': current_time,
                    'duration': chord_duration,
                    'velocity': velocity
                })
            
            current_time += chord_duration
        
        return chords
    
    def _generate_riff(self, root, scale, octave_range, velocity_base, velocity_variation):
        """Generate a repeating riff pattern"""
        import random
        
        riff = []
        
        # Riff patterns - short, rhythmic, repeating
        rhythm_patterns = [
            [0.25, 0.25, 0.5, 0.5, 0.25, 0.25, 1.0],
            [0.5, 0.25, 0.25, 0.5, 0.5, 1.0],
            [0.25, 0.5, 0.25, 0.5, 0.5, 0.5, 0.5],
            [0.5, 0.5, 0.25, 0.25, 0.25, 0.25, 1.0],
        ]
        
        rhythm = random.choice(rhythm_patterns)
        
        # Generate note pattern (limited range for riff)
        note_pattern = []
        current_degree = 0
        
        for _ in rhythm:
            note = root + scale[current_degree % len(scale)]
            note_pattern.append(max(12, min(120, note)))
            
            # Small movements for riffs
            move = random.choice([-2, -1, 0, 1, 2, 2])  # Bias towards staying close
            current_degree = (current_degree + move) % len(scale)
        
        # Build riff
        current_time = 0.0
        for note, duration in zip(note_pattern, rhythm):
            # Add accent to certain beats
            is_accent = (current_time % 1.0 < 0.01)  # Accent on beat
            velocity = velocity_base + (15 if is_accent else 0)
            velocity += random.randint(-velocity_variation//2, velocity_variation//2)
            velocity = max(40, min(127, velocity))
            
            riff.append({
                'note': note,
                'time': current_time,
                'duration': duration * 0.95,  # Slight staccato
                'velocity': velocity
            })
            
            current_time += duration
        
        # Repeat the riff once
        riff_duration = current_time
        for note_data in list(riff):
            riff.append({
                'note': note_data['note'],
                'time': note_data['time'] + riff_duration,
                'duration': note_data['duration'],
                'velocity': note_data['velocity']
            })
        
        return riff
    
    def _generate_pad(self, root, scale, pad_duration, velocity_base, velocity_variation):
        """Generate ambient pad chords"""
        import random
        
        pad = []
        
        # Pads = long sustained chords with smooth voice leading
        chord_changes = 2  # Number of chord changes
        duration_per_chord = pad_duration / chord_changes
        
        current_time = 0.0
        
        # Start with tonic chord
        degrees = [0, 3, 4, 0]  # Simple progression
        
        for degree in degrees:
            # Build rich chord (add 7th and 9th for color)
            notes_in_chord = []
            
            # Root
            chord_root = root + scale[degree % len(scale)]
            notes_in_chord.append(chord_root)
            
            # Third
            third_degree = (degree + 2) % len(scale)
            third_note = chord_root + scale[third_degree] - scale[degree]
            if third_note <= chord_root:
                third_note += 12
            notes_in_chord.append(third_note)
            
            # Fifth
            fifth_degree = (degree + 4) % len(scale)
            fifth_note = chord_root + scale[fifth_degree] - scale[degree]
            if fifth_note <= third_note:
                fifth_note += 12
            notes_in_chord.append(fifth_note)
            
            # Octave
            notes_in_chord.append(chord_root + 12)
            
            # 7th for color
            seventh_degree = (degree + 6) % len(scale)
            seventh_note = chord_root + scale[seventh_degree] - scale[degree]
            while seventh_note <= fifth_note:
                seventh_note += 12
            notes_in_chord.append(seventh_note)
            
            # Very soft velocity with little variation
            velocity = velocity_base + random.randint(-velocity_variation//2, velocity_variation//2)
            velocity = max(40, min(90, velocity))
            
            # Add all notes as long sustained pad
            for note in notes_in_chord:
                pad.append({
                    'note': max(12, min(120, note)),
                    'time': current_time,
                    'duration': duration_per_chord,
                    'velocity': velocity
                })
            
            current_time += duration_per_chord
        
        return pad
    
    def _generate_musical_phrase(self, root, scale, octave_range, phrase_beats, prompt_lower, velocity_base, velocity_variation):
        """Generate a musically coherent melodic phrase"""
        import random
        
        phrase = []
        current_time = 0.0
        
        # Melody rhythm patterns
        if 'fast' in prompt_lower or 'energetic' in prompt_lower:
            rhythm_patterns = [
                [0.25, 0.25, 0.25, 0.25, 0.5, 0.5, 0.25, 0.25, 0.5],
                [0.25, 0.25, 0.5, 0.25, 0.25, 0.25, 0.25, 1.0],
            ]
        elif 'slow' in prompt_lower or 'ballad' in prompt_lower:
            rhythm_patterns = [
                [1.0, 1.0, 2.0, 1.0, 1.0, 2.0],
                [1.5, 0.5, 1.0, 2.0, 1.0, 2.0],
            ]
        else:
            rhythm_patterns = [
                [0.5, 0.5, 1.0, 0.5, 0.5, 1.0, 1.0],
                [1.0, 0.5, 0.5, 0.75, 0.25, 1.0, 1.0],
                [0.75, 0.25, 1.0, 0.5, 0.5, 1.0, 1.0],
                [0.5, 0.5, 0.5, 0.5, 1.0, 0.5, 0.5, 1.0]
            ]
        
        rhythm_pattern = random.choice(rhythm_patterns)
        
        # Generate melodic contour
        melody_notes = self._generate_melodic_contour(root, scale, octave_range, len(rhythm_pattern), prompt_lower)
        
        # Create phrase with dynamics
        for i, (note, duration) in enumerate(zip(melody_notes, rhythm_pattern)):
            phrase_position = i / len(rhythm_pattern)
            
            # Dynamic curve
            if phrase_position < 0.3:
                dynamic_factor = 0.7 + (phrase_position * 1.0)
            elif phrase_position < 0.7:
                dynamic_factor = 1.0
            else:
                dynamic_factor = 1.0 - ((phrase_position - 0.7) * 0.5)
            
            velocity = int(velocity_base * dynamic_factor + random.randint(-velocity_variation, velocity_variation))
            velocity = max(40, min(127, velocity))
            
            timing_variation = random.uniform(-0.02, 0.02)
            
            phrase.append({
                'note': note,
                'time': current_time + timing_variation,
                'duration': duration,
                'velocity': velocity
            })
            
            current_time += duration
        
        return phrase
    
    def _generate_melodic_contour(self, root, scale, octave_range, num_notes, prompt_lower):
        """Generate melodically interesting note sequence"""
        import random
        
        notes = []
        
        if not scale or len(scale) == 0:
            scale = [0, 2, 4, 5, 7, 9, 11]
        
        if num_notes <= 0:
            num_notes = 8
        
        current_degree = random.choice([0, 2, 4])  # Start on stable tones
        current_octave = 0
        
        # Melodic movement tendency
        if 'uplifting' in prompt_lower or 'rising' in prompt_lower:
            movement_bias = 1
        elif 'descending' in prompt_lower or 'falling' in prompt_lower:
            movement_bias = -1
        else:
            movement_bias = 0
        
        for i in range(num_notes):
            degree_index = current_degree % len(scale)
            note = root + scale[degree_index] + (current_octave * 12)
            note = max(12, min(120, int(note)))
            notes.append(note)
            
            position_in_phrase = i / max(1, num_notes - 1)
            
            # Vary movement based on position
            if position_in_phrase < 0.25:
                movements = [-2, -1, 0, 1, 2, 3]
            elif position_in_phrase < 0.75:
                movements = [-3, -2, -1, 1, 2, 3, 4]
            else:
                # Move toward resolution
                if current_degree != 0:
                    movements = [-2, -1, 0, 1]
                else:
                    movements = [0, 1, 2]
            
            if movement_bias > 0:
                movements = [m for m in movements if m >= -1]
            elif movement_bias < 0:
                movements = [m for m in movements if m <= 1]
            
            if not movements:
                movements = [0]
            
            move = random.choice(movements)
            new_degree = current_degree + move
            
            # Handle octave changes
            while new_degree >= len(scale):
                new_degree -= len(scale)
                current_octave += 1
            while new_degree < 0:
                new_degree += len(scale)
                current_octave -= 1
            
            # Keep in range
            if current_octave > octave_range:
                current_octave = octave_range
                new_degree = min(new_degree, len(scale) - 1)
            if current_octave < -1:
                current_octave = -1
                new_degree = max(new_degree, 0)
            
            current_degree = new_degree
        
        # Resolve to tonic at end (70% chance)
        if len(notes) > 0 and random.random() < 0.7:
            resolution_note = root + scale[0] + (current_octave * 12)
            resolution_note = max(12, min(120, int(resolution_note)))
            notes[-1] = resolution_note
        
        return notes


NODE_CLASS_MAPPINGS = {
    "AbsynthVST": AbsynthVSTNode,
    "AbsynthVSTParameterLister": AbsynthVSTParameterListerNode,
    "AbsynthMIDICreator": AbsynthMIDICreatorNode,
    "AbsynthVSTInfoDisplay": AbsynthVSTInfoDisplayNode,
    "AbsynthLLMMIDIGenerator": AbsynthLLMMIDIGeneratorNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AbsynthVST": "Absynth-VST Player",
    "AbsynthVSTParameterLister": "Absynth-VST Parameter Lister",
    "AbsynthMIDICreator": "Absynth-VST MIDI Creator",
    "AbsynthVSTInfoDisplay": "Absynth-VST Info Display",
    "AbsynthLLMMIDIGenerator": "Absynth-VST LLM MIDI Generator"
}