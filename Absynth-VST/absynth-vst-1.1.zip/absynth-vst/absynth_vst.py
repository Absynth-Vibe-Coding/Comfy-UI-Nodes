import os
import numpy as np
import soundfile as sf
import dawdreamer as daw
import mido
import torch

class AbsynthVSTNode:
    """
    Absynth-VST v1.1: Load VST instruments and process MIDI input using DawDreamer
    
    VERSION 1.1 Changes:
    - Added output_gain parameter for precise volume control (0.0 = silence, 1.0 = full)
    - Improved MIDI generation with better randomization
    - Enhanced parameter documentation
    """
    
    VERSION = "1.1"
    
    # Preset folder is now in custom_nodes/absynth-vst/presets
    # This makes it portable and works for all users
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _default_preset_folder = os.path.join(_script_dir, "presets")
    _default_midi_folder = os.path.join(_script_dir, "midi")
    
    # Create presets folder if it doesn't exist
    if not os.path.exists(_default_preset_folder):
        os.makedirs(_default_preset_folder)
        print(f"[Absynth-VST] Created preset folder: {_default_preset_folder}")
    
    # Create MIDI folder if it doesn't exist
    if not os.path.exists(_default_midi_folder):
        os.makedirs(_default_midi_folder)
        print(f"[Absynth-VST] Created MIDI folder: {_default_midi_folder}")
    
    _preset_cache = {}
    _midi_cache = {}
    
    @classmethod
    def INPUT_TYPES(cls):
        # Scan presets on startup
        presets = cls.scan_presets(cls._default_preset_folder)
        preset_list = ["load preset"] + presets
        
        # Scan MIDI files on startup
        midi_files = cls.scan_midi_files(cls._default_midi_folder)
        midi_list = ["select MIDI file"] + midi_files
        
        return {
            "required": {
                "vst_path": ("STRING", {
                    "default": "C:\\Program Files\\Common Files\\VST3\\Serum2.vst3",
                    "multiline": False
                }),
                "preset": (preset_list, {
                    "default": preset_list[0]
                }),
                "midi_file": (midi_list, {
                    "default": midi_list[0]
                }),
                "sample_rate": ("INT", {
                    "default": 44100,
                    "min": 22050,
                    "max": 192000,
                    "step": 1
                }),
                "buffer_size": ("INT", {
                    "default": 512,
                    "min": 128,
                    "max": 2048,
                    "step": 128
                }),
                "reverb_tail": ("FLOAT", {
                    "default": 2.0,
                    "min": 0.0,
                    "max": 10.0,
                    "step": 0.1,
                    "display": "slider"
                }),
                "output_gain": ("FLOAT", {
                    "default": 1.0,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                # VST Parameters (1-6)
                # IMPORTANT: 
                # - Set value to -1.0 to DISABLE the parameter (won't be changed)
                # - Set value 0.0-1.0 to control the VST parameter
                # - 0.0 = minimum value (but NOT always silence!)
                # - 1.0 = maximum value
                # - Use Parameter Lister to find correct parameter indices
                # - For volume control, use 'output_gain' above for precise control
                # Parameter 1
                "parameter_1": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_1_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_1_name": ("STRING", {
                    "default": "cutoff",
                    "multiline": False
                }),
                # Parameter 2
                "parameter_2": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_2_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_2_name": ("STRING", {
                    "default": "reverb",
                    "multiline": False
                }),
                # Parameter 3
                "parameter_3": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_3_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_3_name": ("STRING", {
                    "default": "resonance",
                    "multiline": False
                }),
                # Parameter 4
                "parameter_4": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_4_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_4_name": ("STRING", {
                    "default": "attack",
                    "multiline": False
                }),
                # Parameter 5
                "parameter_5": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_5_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_5_name": ("STRING", {
                    "default": "release",
                    "multiline": False
                }),
                # Parameter 6
                "parameter_6": ("FLOAT", {
                    "default": -1.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "parameter_6_index": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 10000,
                    "step": 1
                }),
                "parameter_6_name": ("STRING", {
                    "default": "decay",
                    "multiline": False
                }),
                "output_path": ("STRING", {
                    "default": "./output/vst_audio.wav",
                    "multiline": False
                })
            },
            "optional": {
                "midi_path_input": ("STRING", {
                    "default": "",
                    "forceInput": True
                })
            }
        }
    
    RETURN_TYPES = ("STRING", "AUDIO", "VST_INFO")
    RETURN_NAMES = ("file_path", "audio", "plugin_info")
    FUNCTION = "process_vst"
    CATEGORY = "absynth-vst"
    
    # Known incompatible VSTs (crash DawDreamer at C++ level)
    BLACKLISTED_VSTS = [
        'spire',
        'omnisphere', 
        'kontakt',
        'battery',
        'massive x'
    ]
    
    @classmethod
    def scan_presets(cls, folder):
        """Scan folder for presets and cache paths"""
        preset_list = []
        cls._preset_cache = {}
        
        if not os.path.exists(folder):
            print(f"[Absynth-VST] Preset folder not found: {folder}")
            return preset_list
        
        # Only scan for standard VST3 presets that DawDreamer can load
        extensions = ['.vstpreset']
        
        try:
            print(f"[Absynth-VST] Scanning: {folder}")
            for root, dirs, files in os.walk(folder):
                for file in files:
                    if any(file.lower().endswith(ext) for ext in extensions):
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, folder)
                        cls._preset_cache[rel_path] = full_path
                        preset_list.append(rel_path)
            
            preset_list.sort()
            print(f"[Absynth-VST] Found {len(preset_list)} presets")
        except Exception as e:
            print(f"[Absynth-VST] Scan error: {e}")
        
        return preset_list
    
    @classmethod
    def scan_midi_files(cls, folder):
        """Scan folder for MIDI files and cache paths"""
        midi_list = []
        cls._midi_cache = {}
        
        if not os.path.exists(folder):
            print(f"[Absynth-VST] MIDI folder not found: {folder}")
            return midi_list
        
        # Scan for MIDI files
        extensions = ['.mid', '.midi']
        
        try:
            print(f"[Absynth-VST] Scanning MIDI: {folder}")
            for root, dirs, files in os.walk(folder):
                for file in files:
                    if any(file.lower().endswith(ext) for ext in extensions):
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, folder)
                        cls._midi_cache[rel_path] = full_path
                        midi_list.append(rel_path)
            
            midi_list.sort()
            print(f"[Absynth-VST] Found {len(midi_list)} MIDI files")
        except Exception as e:
            print(f"[Absynth-VST] MIDI scan error: {e}")
        
        return midi_list
    
    def load_midi_events(self, midi_file):
        """Load MIDI and convert to events with proper timing"""
        midi = mido.MidiFile(midi_file)
        events = []
        active_notes = {}
        current_time_ticks = 0
        
        # Get MIDI timing info
        ticks_per_beat = midi.ticks_per_beat
        tempo = 500000  # Default: 120 BPM = 500000 microseconds per beat
        
        print(f"[Absynth-VST] MIDI file info:")
        print(f"[Absynth-VST] - Ticks per beat: {ticks_per_beat}")
        
        # First pass: find tempo
        for track in midi.tracks:
            for msg in track:
                if msg.type == 'set_tempo':
                    tempo = msg.tempo
                    bpm = mido.tempo2bpm(tempo)
                    print(f"[Absynth-VST] - Tempo found: {tempo} microseconds/beat ({bpm:.1f} BPM)")
                    break
        
        # Second pass: convert notes to seconds
        for track in midi.tracks:
            current_time_ticks = 0
            
            for msg in track:
                # Add delta time (msg.time is in ticks, relative to previous event)
                current_time_ticks += msg.time
                
                # Convert ticks to seconds
                # Formula: seconds = (ticks / ticks_per_beat) * (tempo / 1000000)
                beats = current_time_ticks / ticks_per_beat
                current_time_seconds = beats * (tempo / 1000000.0)
                
                if msg.type == 'note_on' and msg.velocity > 0:
                    active_notes[msg.note] = {
                        'start_time': current_time_seconds,
                        'velocity': msg.velocity
                    }
                elif msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0):
                    if msg.note in active_notes:
                        note_info = active_notes[msg.note]
                        duration = current_time_seconds - note_info['start_time']
                        events.append({
                            'time': note_info['start_time'],
                            'note': msg.note,
                            'velocity': note_info['velocity'],
                            'duration': max(0.1, duration)  # Minimum 0.1s duration
                        })
                        del active_notes[msg.note]
        
        # Close any remaining notes
        final_time = (current_time_ticks / ticks_per_beat) * (tempo / 1000000.0)
        for note, info in active_notes.items():
            events.append({
                'time': info['start_time'],
                'note': note,
                'velocity': info['velocity'],
                'duration': max(0.5, final_time - info['start_time'])
            })
        
        events.sort(key=lambda x: x['time'])
        
        total_duration = max([e['time'] + e['duration'] for e in events]) if events else 0.0
        
        print(f"[Absynth-VST] - Loaded {len(events)} notes")
        print(f"[Absynth-VST] - Total duration: {total_duration:.2f}s")
        
        if len(events) > 0:
            print(f"[Absynth-VST] - First note: {events[0]['note']} at {events[0]['time']:.3f}s")
            print(f"[Absynth-VST] - Last note: {events[-1]['note']} at {events[-1]['time']:.3f}s")
        else:
            print(f"[Absynth-VST] ⚠ WARNING: No notes found in MIDI file!")
        
        return events, total_duration
    
    def process_vst(self, vst_path, preset, midi_file, sample_rate, buffer_size, reverb_tail=2.0, output_gain=1.0,
                   parameter_1=-1.0, parameter_1_index=-1, parameter_1_name="cutoff",
                   parameter_2=-1.0, parameter_2_index=-1, parameter_2_name="reverb",
                   parameter_3=-1.0, parameter_3_index=-1, parameter_3_name="resonance",
                   parameter_4=-1.0, parameter_4_index=-1, parameter_4_name="attack",
                   parameter_5=-1.0, parameter_5_index=-1, parameter_5_name="release",
                   parameter_6=-1.0, parameter_6_index=-1, parameter_6_name="decay",
                   output_path="./output/vst_audio.wav",
                   midi_path_input=""):
        """Main processing function with comprehensive error handling"""
        
        # Pre-flight checks
        if not os.path.exists(vst_path):
            print(f"[Absynth-VST] ✗ VST file not found: {vst_path}")
            empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
            return (f"Error: VST not found", empty_audio, None)
        
        # PRIORITY 1: Use midi_path_input if provided (from LLM node)
        # PRIORITY 2: Use midi_file dropdown selection
        
        midi_path = None
        
        if midi_path_input and midi_path_input.strip():
            # Direct path provided from another node (e.g., LLM Generator)
            midi_path = midi_path_input.strip()
            print(f"[Absynth-VST] Using connected MIDI input: {os.path.basename(midi_path)}")
            
            if not os.path.exists(midi_path):
                print(f"[Absynth-VST] ✗ Connected MIDI file not found: {midi_path}")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Connected MIDI file not found", empty_audio, None)
        else:
            # Use dropdown selection
            if midi_file == "select MIDI file":
                print(f"[Absynth-VST] ✗ No MIDI file selected")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Please select a MIDI file or connect a MIDI input", empty_audio, None)
            
            # Resolve MIDI file path from cache
            midi_path = self._midi_cache.get(midi_file, "")
            
            if not midi_path:
                # If not in cache, try as absolute path
                midi_path = midi_file if os.path.isabs(midi_file) else os.path.join(self._default_midi_folder, midi_file)
            
            if not os.path.exists(midi_path):
                print(f"[Absynth-VST] ✗ MIDI file not found: {midi_path}")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: MIDI file not found", empty_audio, None)
        
        # Check blacklist
        vst_name = os.path.basename(vst_path).lower()
        for blacklisted in self.BLACKLISTED_VSTS:
            if blacklisted in vst_name:
                error_msg = f"VST '{os.path.basename(vst_path)}' is BLACKLISTED (crashes DawDreamer)"
                print(f"[Absynth-VST] ✗✗✗ {error_msg}")
                print(f"[Absynth-VST] This VST is known to crash at C++ level")
                print(f"[Absynth-VST] Cannot be used with DawDreamer")
                print(f"[Absynth-VST] Recommended alternatives:")
                print(f"[Absynth-VST] - Vital (free, similar to Serum)")
                print(f"[Absynth-VST] - Surge XT (free, powerful)")
                print(f"[Absynth-VST] - Serum (confirmed working)")
                print(f"[Absynth-VST] - Dexed (free FM synth)")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return (error_msg, empty_audio, None)
        
        try:
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] Absynth-VST v{self.VERSION}")
            print(f"[Absynth-VST] Starting VST processing...")
            print(f"[Absynth-VST] VST: {os.path.basename(vst_path)}")
            print(f"[Absynth-VST] ==================")
            
            # Wrap everything in try-except to prevent crashes
            try:
                print(f"[Absynth-VST] Initializing DawDreamer engine...")
                engine = daw.RenderEngine(sample_rate, buffer_size)
                print(f"[Absynth-VST] ✓ Engine initialized")
            except Exception as engine_error:
                print(f"[Absynth-VST] ✗ Engine init failed: {engine_error}")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return (f"Error: DawDreamer engine failed", empty_audio, None)
            
            print(f"[Absynth-VST] Attempting to load VST...")
            print(f"[Absynth-VST] Path: {vst_path}")
            
            if not (vst_path.endswith('.vst3') or vst_path.endswith('.vst') or vst_path.endswith('.dll')):
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Unsupported format. Use .vst, .vst3, or .dll", empty_audio, None)
            
            # Try to load VST with maximum error handling
            try:
                print(f"[Absynth-VST] Creating plugin processor...")
                synth = engine.make_plugin_processor("synth", vst_path)
                print(f"[Absynth-VST] ✓ Plugin loaded: {synth.get_name()}")
            except RuntimeError as runtime_err:
                print(f"[Absynth-VST] ✗ RuntimeError loading VST: {runtime_err}")
                print(f"[Absynth-VST] This VST is not compatible with DawDreamer")
                print(f"[Absynth-VST] Try: Serum, Vital, Surge XT, Dexed (known working VSTs)")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return (f"VST incompatible: {str(runtime_err)}", empty_audio, None)
            except Exception as vst_error:
                print(f"[Absynth-VST] ✗ Failed to load VST: {vst_error}")
                print(f"[Absynth-VST] Possible issues:")
                print(f"[Absynth-VST] - VST requires GUI/display to function")
                print(f"[Absynth-VST] - VST uses unsupported copy protection")
                print(f"[Absynth-VST] - VST architecture mismatch (32-bit vs 64-bit)")
                print(f"[Absynth-VST] Recommended working VSTs: Serum, Vital, Surge XT, Dexed")
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return (f"Error loading VST: {str(vst_error)}", empty_audio, None)
            
            # Load preset
            preset_loaded = False
            if preset != "load preset":
                preset_path = self._preset_cache.get(preset, "")
                
                if not preset_path:
                    preset_path = os.path.join(self._default_preset_folder, preset)
                
                if os.path.exists(preset_path):
                    print(f"[Absynth-VST] ==================")
                    print(f"[Absynth-VST] Loading: {preset}")
                    print(f"[Absynth-VST] Path: {preset_path}")
                    
                    try:
                        # For VST3, use load_vst3_preset with file path
                        synth.load_vst3_preset(preset_path)
                        print(f"[Absynth-VST] ✓✓✓ PRESET LOADED SUCCESSFULLY ✓✓✓")
                        preset_loaded = True
                        
                    except Exception as e:
                        print(f"[Absynth-VST] ✗ Failed with load_vst3_preset: {e}")
                        
                        # Fallback: try load_state
                        try:
                            with open(preset_path, 'rb') as f:
                                preset_data = f.read()
                            synth.load_state(preset_data)
                            print(f"[Absynth-VST] ✓✓✓ PRESET LOADED WITH load_state ✓✓✓")
                            preset_loaded = True
                        except Exception as fallback_err:
                            print(f"[Absynth-VST] ✗ All methods failed")
                            print(f"[Absynth-VST] Using init sound...")
                            import traceback
                            traceback.print_exc()
                    
                    print(f"[Absynth-VST] ==================")
                else:
                    print(f"[Absynth-VST] Preset not found: {preset_path}")
            else:
                print(f"[Absynth-VST] Using init sound")
            
            # Apply custom parameters
            # Priority: Manual index > Auto search by name
            params_to_set = []
            
            # Build parameter list
            param_configs = [
                (1, parameter_1, parameter_1_index, parameter_1_name),
                (2, parameter_2, parameter_2_index, parameter_2_name),
                (3, parameter_3, parameter_3_index, parameter_3_name),
                (4, parameter_4, parameter_4_index, parameter_4_name),
                (5, parameter_5, parameter_5_index, parameter_5_name),
                (6, parameter_6, parameter_6_index, parameter_6_name),
            ]
            
            for param_num, value, manual_index, search_name in param_configs:
                if value >= 0.0:
                    # Generate search terms based on the name
                    search_terms = [search_name.lower()]
                    params_to_set.append((f'Parameter {param_num} ({search_name})', value, manual_index, search_terms))
            
            if params_to_set:
                print(f"[Absynth-VST] ==================")
                print(f"[Absynth-VST] PARAMETER CONTROL")
                print(f"[Absynth-VST] ==================")
                
                param_count = synth.get_plugin_parameter_size()
                print(f"[Absynth-VST] VST has {param_count} total parameters")
                
                applied_count = 0
                
                for param_name, value, manual_index, search_terms in params_to_set:
                    print(f"\n[Absynth-VST] ╔═══════════════════════════════")
                    print(f"[Absynth-VST] Setting: '{param_name}' = {value:.3f}")
                    
                    param_index = None
                    
                    # Method 1: Use manual index if specified
                    if manual_index >= 0:
                        print(f"[Absynth-VST] Using MANUAL index: {manual_index}")
                        param_index = manual_index
                        
                        try:
                            param_name_actual = synth.get_parameter_name(manual_index)
                            print(f"[Absynth-VST] Parameter name: '{param_name_actual}'")
                        except:
                            print(f"[Absynth-VST] ⚠ Warning: Index {manual_index} might be invalid")
                    
                    # Method 2: Auto-search by name
                    else:
                        print(f"[Absynth-VST] AUTO-SEARCHING with terms: {search_terms}")
                        matches = []
                        
                        for search_term in search_terms:
                            search_lower = search_term.lower()
                            
                            for i in range(param_count):
                                try:
                                    vst_param_name = synth.get_parameter_name(i)
                                    vst_param_lower = vst_param_name.lower()
                                    
                                    if search_lower in vst_param_lower:
                                        current_val = synth.get_parameter(i)
                                        matches.append({
                                            'index': i,
                                            'name': vst_param_name,
                                            'value': current_val
                                        })
                                except:
                                    continue
                        
                        if matches:
                            print(f"[Absynth-VST] Found {len(matches)} matching parameters:")
                            for match in matches[:5]:  # Show first 5
                                print(f"[Absynth-VST]   [{match['index']:3d}] {match['name']:40s} = {match['value']:.3f}")
                            
                            if len(matches) > 5:
                                print(f"[Absynth-VST]   ... and {len(matches)-5} more")
                            
                            # Use first match
                            param_index = matches[0]['index']
                            print(f"[Absynth-VST] Using: [{param_index}] {matches[0]['name']}")
                        else:
                            print(f"[Absynth-VST] ✗ NO MATCHES FOUND")
                            print(f"[Absynth-VST] TIP: Use Parameter Lister to find the exact parameter")
                            print(f"[Absynth-VST] Then set the parameter index manually")
                            continue
                    
                    # Apply the parameter
                    if param_index is not None:
                        try:
                            print(f"[Absynth-VST] ─────────────────────────────")
                            
                            # Get before
                            old_value = synth.get_parameter(param_index)
                            print(f"[Absynth-VST] Before: {old_value:.3f}")
                            
                            # Set parameter
                            synth.set_parameter(param_index, value)
                            
                            # Get after
                            new_value = synth.get_parameter(param_index)
                            print(f"[Absynth-VST] After:  {new_value:.3f}")
                            
                            # Verify
                            if abs(new_value - value) < 0.001:
                                print(f"[Absynth-VST] ✓✓✓ SUCCESS!")
                                applied_count += 1
                            else:
                                print(f"[Absynth-VST] ⚠⚠⚠ WARNING!")
                                print(f"[Absynth-VST] Expected {value:.3f} but got {new_value:.3f}")
                                print(f"[Absynth-VST] This parameter might be controlled by the preset")
                                print(f"[Absynth-VST] Try loading preset='load preset' (init sound) instead")
                        
                        except Exception as e:
                            print(f"[Absynth-VST] ✗ Error setting parameter: {e}")
                
                print(f"\n[Absynth-VST] ╚═══════════════════════════════")
                print(f"[Absynth-VST] Applied {applied_count}/{len(params_to_set)} parameters")
                print(f"[Absynth-VST] ==================")
            else:
                print(f"[Absynth-VST] No parameters to apply (all are -1.0)")
            
            plugin_info = {
                'name': synth.get_name(),
                'preset': preset,
                'preset_loaded': preset_loaded
            }
            
            print(f"[Absynth-VST] Loading MIDI: {midi_path}")
            midi_events, midi_duration = self.load_midi_events(midi_path)
            print(f"[Absynth-VST] Loaded {len(midi_events)} notes")
            print(f"[Absynth-VST] MIDI file duration: {midi_duration:.2f}s (already in seconds)")
            
            # Render duration = MIDI length + reverb tail
            render_duration = midi_duration + reverb_tail
            print(f"[Absynth-VST] Total render duration: {render_duration:.2f}s (MIDI: {midi_duration:.2f}s + tail: {reverb_tail:.1f}s)")
            
            # Add MIDI notes to DawDreamer
            # CRITICAL: DawDreamer expects time in SECONDS, not beats!
            # The load_midi_events function already converts to seconds
            print(f"[Absynth-VST] Adding MIDI events to VST (times already in seconds)...")
            
            for idx, event in enumerate(midi_events):
                if idx < 5:  # Debug first 5 notes
                    print(f"[Absynth-VST]   Note {idx}: pitch={event['note']}, time={event['time']:.3f}s, dur={event['duration']:.3f}s, vel={event['velocity']}")
                
                synth.add_midi_note(
                    event['note'],
                    event['velocity'],
                    event['time'],      # Already in seconds
                    event['duration']   # Already in seconds
                )
            
            if len(midi_events) > 5:
                print(f"[Absynth-VST]   ... and {len(midi_events) - 5} more notes")
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] RENDERING AUDIO:")
            print(f"[Absynth-VST] Sample rate: {sample_rate} Hz")
            print(f"[Absynth-VST] Buffer size: {buffer_size}")
            print(f"[Absynth-VST] Duration: {render_duration:.2f}s")
            print(f"[Absynth-VST] Expected samples: {int(render_duration * sample_rate)}")
            print(f"[Absynth-VST] ==================")
            
            engine.load_graph([(synth, [])])
            engine.render(render_duration)
            
            audio_data = engine.get_audio()
            actual_duration = audio_data.shape[1] / sample_rate
            print(f"[Absynth-VST] Audio rendered: {audio_data.shape}")
            print(f"[Absynth-VST] Actual duration: {actual_duration:.2f}s")
            print(f"[Absynth-VST] Channels: {audio_data.shape[0]}")
            
            # Verify timing is correct
            if abs(actual_duration - render_duration) > 0.1:
                print(f"[Absynth-VST] ⚠ WARNING: Duration mismatch!")
                print(f"[Absynth-VST] Expected: {render_duration:.2f}s, Got: {actual_duration:.2f}s")
            else:
                print(f"[Absynth-VST] ✓ Duration matches expected value")
            
            # Apply output gain (post-VST volume control)
            if output_gain != 1.0:
                print(f"[Absynth-VST] Applying output gain: {output_gain:.2f}x ({20 * np.log10(output_gain) if output_gain > 0 else -np.inf:.1f} dB)")
                audio_data = audio_data * output_gain
            
            # Save WAV
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            sf.write(output_path, audio_data.T, sample_rate)
            print(f"[Absynth-VST] ✓ Saved WAV: {output_path}")
            print(f"[Absynth-VST] WAV file sample rate: {sample_rate} Hz")
            
            # Convert to torch for ComfyUI
            # CRITICAL: Ensure audio tensor has correct shape and sample rate
            # Expected format: (batch, channels, samples)
            audio_tensor = torch.from_numpy(audio_data).float().unsqueeze(0)
            print(f"[Absynth-VST] Audio tensor shape: {audio_tensor.shape}")
            print(f"[Absynth-VST] Audio tensor dtype: {audio_tensor.dtype}")
            
            audio_output = {
                "waveform": audio_tensor, 
                "sample_rate": sample_rate
            }
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] AUDIO OUTPUT:")
            print(f"[Absynth-VST] Waveform shape: {audio_tensor.shape} (batch, channels, samples)")
            print(f"[Absynth-VST] Sample rate: {sample_rate} Hz")
            print(f"[Absynth-VST] Duration: {audio_tensor.shape[2] / sample_rate:.2f}s")
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] ✓ Processing complete!")
            
            return (output_path, audio_output, plugin_info)
            
        except Exception as e:
            error_msg = f"[Absynth-VST] Error: {str(e)}"
            print(error_msg)
            import traceback
            traceback.print_exc()
            
            empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
            return (error_msg, empty_audio, None)


class AbsynthVSTParameterListerNode:
    """
    Absynth-VST Parameter Lister v1.1
    List all available parameters from a VST plugin
    """
    
    VERSION = "1.1"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "vst_path": ("STRING", {
                    "default": "C:\\Program Files\\Common Files\\VST3\\Serum2.vst3",
                    "multiline": False
                }),
                "search_filter": ("STRING", {
                    "default": "",
                    "multiline": False
                }),
                "sample_rate": ("INT", {
                    "default": 44100,
                    "min": 22050,
                    "max": 192000
                })
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("parameter_list",)
    FUNCTION = "list_parameters"
    CATEGORY = "absynth-vst"
    OUTPUT_NODE = True
    
    def list_parameters(self, vst_path, search_filter, sample_rate):
        """List all parameters with their indices, names, and current values"""
        try:
            if not os.path.exists(vst_path):
                return ("Error: VST not found",)
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] Loading VST to list parameters...")
            engine = daw.RenderEngine(sample_rate, 512)
            synth = engine.make_plugin_processor("synth", vst_path)
            
            param_count = synth.get_plugin_parameter_size()
            print(f"[Absynth-VST] Found {param_count} parameters")
            
            param_lines = [f"=== {synth.get_name()} Parameters ==="]
            param_lines.append(f"Total: {param_count} parameters\n")
            
            # Apply search filter
            search_lower = search_filter.lower().strip()
            matched_count = 0
            
            for i in range(param_count):
                try:
                    name = synth.get_parameter_name(i)
                    
                    # Skip if doesn't match filter
                    if search_lower and search_lower not in name.lower():
                        continue
                    
                    matched_count += 1
                    value = synth.get_parameter(i)
                    text = synth.get_parameter_text(i)
                    
                    param_lines.append(f"[{i:4d}] {name:50s} = {value:.3f} ({text})")
                except Exception as e:
                    param_lines.append(f"[{i:4d}] Error reading parameter: {e}")
            
            if search_lower:
                param_lines.append(f"\nMatched {matched_count} parameters with filter '{search_filter}'")
            
            result = "\n".join(param_lines)
            print(result)
            print(f"[Absynth-VST] ==================")
            
            return (result,)
            
        except Exception as e:
            error = f"Error listing parameters: {str(e)}"
            print(f"[Absynth-VST] {error}")
            import traceback
            traceback.print_exc()
            return (error,)


class AbsynthMIDICreatorNode:
    """
    Absynth-VST MIDI Creator v1.1
    Create simple MIDI files
    """
    
    VERSION = "1.1"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "notes": ("STRING", {"default": "60,64,67"}),
                "velocities": ("STRING", {"default": "100,100,100"}),
                "durations": ("STRING", {"default": "1.0,1.0,1.0"}),
                "output_path": ("STRING", {"default": "./output/test_midi.mid"})
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("midi_path",)
    FUNCTION = "create_midi"
    CATEGORY = "absynth-vst"
    
    def create_midi(self, notes, velocities, durations, output_path):
        try:
            note_list = [int(n.strip()) for n in notes.split(',')]
            velocity_list = [int(v.strip()) for v in velocities.split(',')]
            duration_list = [float(d.strip()) for d in durations.split(',')]
            
            mid = mido.MidiFile()
            track = mido.MidiTrack()
            mid.tracks.append(track)
            
            for note, velocity, duration in zip(note_list, velocity_list, duration_list):
                track.append(mido.Message('note_on', note=note, velocity=velocity, time=0))
                track.append(mido.Message('note_off', note=note, velocity=0, time=int(duration * 480)))
            
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            mid.save(output_path)
            print(f"[Absynth-VST] ✓ MIDI: {output_path}")
            return (output_path,)
        except Exception as e:
            error = f"Error: {str(e)}"
            print(f"[Absynth-VST] {error}")
            return (error,)


class AbsynthVSTInfoDisplayNode:
    """
    Absynth-VST Info Display v1.1
    Display VST plugin information
    """
    
    VERSION = "1.1"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "vst_info": ("VST_INFO",)
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("info_text",)
    FUNCTION = "display_info"
    CATEGORY = "absynth-vst"
    OUTPUT_NODE = True
    
    def display_info(self, vst_info):
        """Format and display VST info"""
        if not vst_info:
            return ("No VST info available",)
        
        info_lines = ["=== VST INFO ==="]
        
        if 'name' in vst_info:
            info_lines.append(f"Plugin: {vst_info['name']}")
        
        if 'preset' in vst_info:
            info_lines.append(f"Preset: {vst_info['preset']}")
        
        if 'preset_loaded' in vst_info:
            status = "✓ Loaded" if vst_info['preset_loaded'] else "✗ Not loaded (using init)"
            info_lines.append(f"Status: {status}")
        
        info_text = "\n".join(info_lines)
        print(f"[Absynth-VST] {info_text}")
        
        return (info_text,)


class AbsynthLLMMIDIGeneratorNode:
    """
    Absynth-VST LLM MIDI Generator v1.1
    Generate MIDI using an LLM from text prompts
    
    VERSION 1.1: 
    - Circle of Fifths based harmony for musically correct progressions
    - Diatonic chord progressions with proper voice leading
    - Genre-specific rhythms (trance, house, techno, electro, edm, hiphop, pop)
    - Complex arpeggio and sequence patterns
    - Polyrhythmic layer generation
    """
    
    VERSION = "1.1"
    
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _default_midi_folder = os.path.join(_script_dir, "midi")
    
    # CIRCLE OF FIFTHS - Quintenzirkel (COMPLETE - All 24 keys)
    # Based on: https://en.wikipedia.org/wiki/Circle_of_fifths
    CIRCLE_OF_FIFTHS = {
        # === MAJOR KEYS (Dur) - Clockwise around circle ===
        'C': {
            'type': 'major',
            'root': 60,  # C4
            'scale': [0, 2, 4, 5, 7, 9, 11],
            'related_keys': ['F', 'G', 'Am'],  # IV, V, vi (relative minor)
            'chords': {
                'I': [0, 4, 7], 'ii': [2, 5, 9], 'iii': [4, 7, 11],
                'IV': [5, 9, 0+12], 'V': [7, 11, 2+12], 'vi': [9, 0+12, 4+12],
                'vii°': [11, 2+12, 5+12]
            }
        },
        'G': {
            'type': 'major',
            'root': 55,  # G3
            'scale': [0, 2, 4, 5, 7, 9, 11],
            'related_keys': ['C', 'D', 'Em'],
            'chords': {
                'I': [0, 4, 7], 'ii': [2, 5, 9], 'iii': [4, 7, 11],
                'IV': [5, 9, 0+12], 'V': [7, 11, 2+12], 'vi': [9, 0+12, 4+12],
                'vii°': [11, 2+12, 5+12]
            }
        },
        'D': {
            'type': 'major',
            'root': 50,  # D3
            'scale': [0, 2, 4, 5, 7, 9, 11],
            'related_keys': ['G', 'A', 'Bm'],
            'chords': {
                'I': [0, 4, 7], 'ii': [2, 5, 9], 'iii': [4, 7, 11],
                'IV': [5, 9, 0+12], 'V': [7, 11, 2+12], 'vi': [9, 0+12, 4+12],
                'vii°': [11, 2+12, 5+12]
            }
        },
        'A': {
            'type': 'major',
            'root': 57,  # A3
            'scale': [0, 2, 4, 5, 7, 9, 11],
            'related_keys': ['D', 'E', 'F#m'],
            'chords': {
                'I': [0, 4, 7], 'ii': [2, 5, 9], 'iii': [4, 7, 11],
                'IV': [5, 9, 0+12], 'V': [7, 11, 2+12], 'vi': [9, 0+12, 4+12],
                'vii°': [11, 2+12, 5+12]
            }
        },
        'E': {
            'type': 'major',
            'root': 52,  # E3
            'scale': [0, 2, 4, 5, 7, 9, 11],
            'related_keys': ['A', 'B', 'C#m'],
            'chords': {
                'I': [0, 4, 7], 'ii': [2, 5, 9], 'iii': [4, 7, 11],
                'IV': [5, 9, 0+12], 'V': [7, 11, 2+12], 'vi': [9, 0+12, 4+12],
                'vii°': [11, 2+12, 5+12]
            }
        },
        'B': {
            'type': 'major',
            'root': 59,  # B3
            'scale': [0, 2, 4, 5, 7, 9, 11],
            'related_keys': ['E', 'F#', 'G#m'],
            'chords': {
                'I': [0, 4, 7], 'ii': [2, 5, 9], 'iii': [4, 7, 11],
                'IV': [5, 9, 0+12], 'V': [7, 11, 2+12], 'vi': [9, 0+12, 4+12],
                'vii°': [11, 2+12, 5+12]
            }
        },
        'F#': {  # F# / Gb
            'type': 'major',
            'root': 54,  # F#3
            'scale': [0, 2, 4, 5, 7, 9, 11],
            'related_keys': ['B', 'C#', 'D#m'],
            'chords': {
                'I': [0, 4, 7], 'ii': [2, 5, 9], 'iii': [4, 7, 11],
                'IV': [5, 9, 0+12], 'V': [7, 11, 2+12], 'vi': [9, 0+12, 4+12],
                'vii°': [11, 2+12, 5+12]
            }
        },
        'Db': {  # C# / Db
            'type': 'major',
            'root': 49,  # Db3 / C#3
            'scale': [0, 2, 4, 5, 7, 9, 11],
            'related_keys': ['Gb', 'Ab', 'Bbm'],
            'chords': {
                'I': [0, 4, 7], 'ii': [2, 5, 9], 'iii': [4, 7, 11],
                'IV': [5, 9, 0+12], 'V': [7, 11, 2+12], 'vi': [9, 0+12, 4+12],
                'vii°': [11, 2+12, 5+12]
            }
        },
        'Ab': {
            'type': 'major',
            'root': 56,  # Ab3 / G#3
            'scale': [0, 2, 4, 5, 7, 9, 11],
            'related_keys': ['Db', 'Eb', 'Fm'],
            'chords': {
                'I': [0, 4, 7], 'ii': [2, 5, 9], 'iii': [4, 7, 11],
                'IV': [5, 9, 0+12], 'V': [7, 11, 2+12], 'vi': [9, 0+12, 4+12],
                'vii°': [11, 2+12, 5+12]
            }
        },
        'Eb': {
            'type': 'major',
            'root': 51,  # Eb3
            'scale': [0, 2, 4, 5, 7, 9, 11],
            'related_keys': ['Ab', 'Bb', 'Cm'],
            'chords': {
                'I': [0, 4, 7], 'ii': [2, 5, 9], 'iii': [4, 7, 11],
                'IV': [5, 9, 0+12], 'V': [7, 11, 2+12], 'vi': [9, 0+12, 4+12],
                'vii°': [11, 2+12, 5+12]
            }
        },
        'Bb': {
            'type': 'major',
            'root': 58,  # Bb3
            'scale': [0, 2, 4, 5, 7, 9, 11],
            'related_keys': ['Eb', 'F', 'Gm'],
            'chords': {
                'I': [0, 4, 7], 'ii': [2, 5, 9], 'iii': [4, 7, 11],
                'IV': [5, 9, 0+12], 'V': [7, 11, 2+12], 'vi': [9, 0+12, 4+12],
                'vii°': [11, 2+12, 5+12]
            }
        },
        'F': {
            'type': 'major',
            'root': 53,  # F3
            'scale': [0, 2, 4, 5, 7, 9, 11],
            'related_keys': ['Bb', 'C', 'Dm'],
            'chords': {
                'I': [0, 4, 7], 'ii': [2, 5, 9], 'iii': [4, 7, 11],
                'IV': [5, 9, 0+12], 'V': [7, 11, 2+12], 'vi': [9, 0+12, 4+12],
                'vii°': [11, 2+12, 5+12]
            }
        },
        
        # === MINOR KEYS (Moll) - Inner circle, relative to majors ===
        'Am': {
            'type': 'minor',
            'root': 57,  # A3
            'scale': [0, 2, 3, 5, 7, 8, 10],  # Natural minor
            'related_keys': ['C', 'Dm', 'Em'],
            'chords': {
                'i': [0, 3, 7], 'ii°': [2, 5, 8], 'III': [3, 7, 10],
                'iv': [5, 8, 0+12], 'v': [7, 10, 2+12], 'VI': [8, 0+12, 3+12],
                'VII': [10, 2+12, 5+12]
            }
        },
        'Em': {
            'type': 'minor',
            'root': 52,  # E3
            'scale': [0, 2, 3, 5, 7, 8, 10],
            'related_keys': ['G', 'Am', 'Bm'],
            'chords': {
                'i': [0, 3, 7], 'ii°': [2, 5, 8], 'III': [3, 7, 10],
                'iv': [5, 8, 0+12], 'v': [7, 10, 2+12], 'VI': [8, 0+12, 3+12],
                'VII': [10, 2+12, 5+12]
            }
        },
        'Bm': {
            'type': 'minor',
            'root': 59,  # B3
            'scale': [0, 2, 3, 5, 7, 8, 10],
            'related_keys': ['D', 'Em', 'F#m'],
            'chords': {
                'i': [0, 3, 7], 'ii°': [2, 5, 8], 'III': [3, 7, 10],
                'iv': [5, 8, 0+12], 'v': [7, 10, 2+12], 'VI': [8, 0+12, 3+12],
                'VII': [10, 2+12, 5+12]
            }
        },
        'F#m': {
            'type': 'minor',
            'root': 54,  # F#3
            'scale': [0, 2, 3, 5, 7, 8, 10],
            'related_keys': ['A', 'Bm', 'C#m'],
            'chords': {
                'i': [0, 3, 7], 'ii°': [2, 5, 8], 'III': [3, 7, 10],
                'iv': [5, 8, 0+12], 'v': [7, 10, 2+12], 'VI': [8, 0+12, 3+12],
                'VII': [10, 2+12, 5+12]
            }
        },
        'C#m': {
            'type': 'minor',
            'root': 49,  # C#3
            'scale': [0, 2, 3, 5, 7, 8, 10],
            'related_keys': ['E', 'F#m', 'G#m'],
            'chords': {
                'i': [0, 3, 7], 'ii°': [2, 5, 8], 'III': [3, 7, 10],
                'iv': [5, 8, 0+12], 'v': [7, 10, 2+12], 'VI': [8, 0+12, 3+12],
                'VII': [10, 2+12, 5+12]
            }
        },
        'G#m': {
            'type': 'minor',
            'root': 56,  # G#3
            'scale': [0, 2, 3, 5, 7, 8, 10],
            'related_keys': ['B', 'C#m', 'D#m'],
            'chords': {
                'i': [0, 3, 7], 'ii°': [2, 5, 8], 'III': [3, 7, 10],
                'iv': [5, 8, 0+12], 'v': [7, 10, 2+12], 'VI': [8, 0+12, 3+12],
                'VII': [10, 2+12, 5+12]
            }
        },
        'D#m': {  # Eb minor
            'type': 'minor',
            'root': 51,  # Eb3 / D#3
            'scale': [0, 2, 3, 5, 7, 8, 10],
            'related_keys': ['F#', 'G#m', 'A#m'],
            'chords': {
                'i': [0, 3, 7], 'ii°': [2, 5, 8], 'III': [3, 7, 10],
                'iv': [5, 8, 0+12], 'v': [7, 10, 2+12], 'VI': [8, 0+12, 3+12],
                'VII': [10, 2+12, 5+12]
            }
        },
        'Bbm': {
            'type': 'minor',
            'root': 58,  # Bb3 / A#3
            'scale': [0, 2, 3, 5, 7, 8, 10],
            'related_keys': ['Db', 'Ebm', 'Fm'],
            'chords': {
                'i': [0, 3, 7], 'ii°': [2, 5, 8], 'III': [3, 7, 10],
                'iv': [5, 8, 0+12], 'v': [7, 10, 2+12], 'VI': [8, 0+12, 3+12],
                'VII': [10, 2+12, 5+12]
            }
        },
        'Fm': {
            'type': 'minor',
            'root': 53,  # F3
            'scale': [0, 2, 3, 5, 7, 8, 10],
            'related_keys': ['Ab', 'Bbm', 'Cm'],
            'chords': {
                'i': [0, 3, 7], 'ii°': [2, 5, 8], 'III': [3, 7, 10],
                'iv': [5, 8, 0+12], 'v': [7, 10, 2+12], 'VI': [8, 0+12, 3+12],
                'VII': [10, 2+12, 5+12]
            }
        },
        'Cm': {
            'type': 'minor',
            'root': 60,  # C4
            'scale': [0, 2, 3, 5, 7, 8, 10],
            'related_keys': ['Eb', 'Fm', 'Gm'],
            'chords': {
                'i': [0, 3, 7], 'ii°': [2, 5, 8], 'III': [3, 7, 10],
                'iv': [5, 8, 0+12], 'v': [7, 10, 2+12], 'VI': [8, 0+12, 3+12],
                'VII': [10, 2+12, 5+12]
            }
        },
        'Gm': {
            'type': 'minor',
            'root': 55,  # G3
            'scale': [0, 2, 3, 5, 7, 8, 10],
            'related_keys': ['Bb', 'Cm', 'Dm'],
            'chords': {
                'i': [0, 3, 7], 'ii°': [2, 5, 8], 'III': [3, 7, 10],
                'iv': [5, 8, 0+12], 'v': [7, 10, 2+12], 'VI': [8, 0+12, 3+12],
                'VII': [10, 2+12, 5+12]
            }
        },
        'Dm': {
            'type': 'minor',
            'root': 50,  # D3
            'scale': [0, 2, 3, 5, 7, 8, 10],
            'related_keys': ['F', 'Gm', 'Am'],
            'chords': {
                'i': [0, 3, 7], 'ii°': [2, 5, 8], 'III': [3, 7, 10],
                'iv': [5, 8, 0+12], 'v': [7, 10, 2+12], 'VI': [8, 0+12, 3+12],
                'VII': [10, 2+12, 5+12]
            }
        }
    }
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": ("STRING", {
                    "default": "Create a dark techno bassline in D minor",
                    "multiline": True
                }),
                "api_key": ("STRING", {
                    "default": "your-api-key-here",
                    "multiline": False
                }),
                "llm_provider": (["local", "ollama", "openai", "anthropic"], {
                    "default": "local"
                }),
                "model": ("STRING", {
                    "default": "llama2",
                    "multiline": False
                }),
                "temperature": ("FLOAT", {
                    "default": 0.8,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.1
                }),
                "seed": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 999999,
                    "step": 1
                }),
                "bpm": ("INT", {
                    "default": 128,
                    "min": 60,
                    "max": 200,
                    "step": 1
                }),
                "duration": ("INT", {
                    "default": 10,
                    "min": 4,
                    "max": 60,
                    "step": 1
                }),
                "output_filename": ("STRING", {
                    "default": "llm_generated",
                    "multiline": False
                })
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("midi_path",)
    FUNCTION = "generate_midi"
    CATEGORY = "absynth-vst"
    
    def generate_midi(self, prompt, api_key, llm_provider, model, temperature, seed, bpm, duration, output_filename):
        """Generate MIDI using LLM or fallback to Circle of Fifths"""
        try:
            # Handle random seed
            import random
            if seed == -1:
                actual_seed = random.randint(0, 999999)
            else:
                actual_seed = seed
            
            # Set random seed for reproducibility
            random.seed(actual_seed)
            
            # Create unique filename
            import time
            timestamp = int(time.time())
            filename = f"{output_filename}_{actual_seed}_{timestamp}.mid"
            output_path = os.path.join(self._default_midi_folder, filename)
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] LLM MIDI Generator v{self.VERSION}")
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] Prompt: {prompt}")
            print(f"[Absynth-VST] Provider: {llm_provider}, Model: {model}")
            print(f"[Absynth-VST] BPM: {bpm}, Duration: {duration}s")
            print(f"[Absynth-VST] Temperature: {temperature}, Seed: {actual_seed}")
            
            # System prompt for code generation
            system_prompt = f"""You are a Python MIDI code generator. Generate Python code using the midiutil library.

REQUIREMENTS:
- Use 'from midiutil import MIDIFile'
- Set BPM to {bpm}
- Create music lasting approximately {duration} seconds
- Save file as '{filename}'
- Use the user's musical description to create appropriate melodies/basslines/patterns
- Output ONLY the Python code, no explanations

EXAMPLE CODE STRUCTURE:
```python
from midiutil import MIDIFile
import math

bpm = {bpm}
duration_seconds = {duration}
beats_total = math.ceil((bpm / 60.0) * duration_seconds)
beat_unit = 1.0  # quarter note = 1 beat

midi = MIDIFile(1)
track = 0
channel = 0

midi.addTempo(track, 0, bpm)
midi.addProgramChange(track, channel, 0, 81)  # Synth Lead

# Your melody/pattern here
melody = [60, 62, 64, 65, 67]  # C major scale example
note_length = 0.5  # eighth notes
velocity = 100
time = 0.0

for note in melody:
    midi.addNote(track, channel, note, time, note_length, velocity)
    time += note_length

with open("{filename}", "wb") as f:
    midi.writeFile(f)
```

Generate creative, musical code based on: {prompt}"""
            
            # Call LLM based on provider
            if llm_provider == "ollama":
                llm_response = self._call_ollama(model, system_prompt, prompt, temperature)
            elif llm_provider == "openai":
                llm_response = self._call_openai(api_key, model, system_prompt, prompt, temperature)
            elif llm_provider == "anthropic":
                llm_response = self._call_anthropic(api_key, model, system_prompt, prompt, temperature)
            elif llm_provider == "local":
                return (self._create_fallback_midi(prompt, filename, bpm, duration),)
            else:
                return ("Error: Unknown LLM provider",)
            
            # Parse and execute Python code
            if llm_response:
                success = self._execute_generated_code(llm_response, filename, bpm, duration)
                
                if success and os.path.exists(output_path):
                    print(f"[Absynth-VST] ✓ MIDI generated: {output_path}")
                    print(f"[Absynth-VST] ==================")
                    return (output_path,)
                else:
                    print("[Absynth-VST] Code execution failed, using fallback")
                    return (self._create_fallback_midi(prompt, filename, bpm, duration),)
            else:
                print("[Absynth-VST] No LLM response, using fallback")
                return (self._create_fallback_midi(prompt, filename, bpm, duration),)
            
        except Exception as e:
            error_msg = f"[Absynth-VST] Error: {str(e)}"
            print(error_msg)
            import traceback
            traceback.print_exc()
            # Return fallback MIDI on error
            return (self._create_fallback_midi(prompt, "fallback_error.mid", bpm, duration),)
    
    def _call_ollama(self, model, system_prompt, user_prompt, temperature):
        try:
            import requests
            url = "http://localhost:11434/api/generate"
            full_prompt = f"{system_prompt}\n\nUser request: {user_prompt}"
            
            payload = {
                "model": model,
                "prompt": full_prompt,
                "stream": False,
                "options": {"temperature": temperature}
            }
            
            print(f"[Absynth-VST] Calling Ollama with model: {model}, temp: {temperature}")
            response = requests.post(url, json=payload, timeout=60)
            
            if response.status_code == 200:
                result = response.json()
                return result.get("response", "")
            else:
                print(f"[Absynth-VST] Ollama error: {response.status_code}")
                return None
                
        except requests.exceptions.ConnectionError:
            print("[Absynth-VST] Ollama not running! Start Ollama first: https://ollama.com")
            print("[Absynth-VST] Using fallback generator...")
            return None
        except ImportError:
            print("[Absynth-VST] Requests library not installed. Run: pip install requests")
            return None
        except Exception as e:
            print(f"[Absynth-VST] Ollama error: {e}")
            return None
    
    def _call_openai(self, api_key, model, system_prompt, user_prompt, temperature):
        try:
            import openai
            client = openai.OpenAI(api_key=api_key)
            
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=temperature
            )
            
            return response.choices[0].message.content
        except ImportError:
            print("[Absynth-VST] OpenAI library not installed. Run: pip install openai")
            return None
        except Exception as e:
            print(f"[Absynth-VST] OpenAI API error: {e}")
            return None
    
    def _call_anthropic(self, api_key, model, system_prompt, user_prompt, temperature):
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=api_key)
            
            message = client.messages.create(
                model=model,
                max_tokens=1024,
                temperature=temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}]
            )
            
            return message.content[0].text
        except ImportError:
            print("[Absynth-VST] Anthropic library not installed. Run: pip install anthropic")
            return None
        except Exception as e:
            print(f"[Absynth-VST] Anthropic API error: {e}")
            return None
    
    def _execute_generated_code(self, llm_response, filename, bpm, duration):
        """Execute the Python code generated by LLM"""
        try:
            # Extract code from markdown code blocks if present
            code = llm_response.strip()
            
            # Remove markdown code blocks
            if "```python" in code:
                code = code.split("```python")[1].split("```")[0].strip()
            elif "```" in code:
                code = code.split("```")[1].split("```")[0].strip()
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] GENERATED CODE:")
            print(f"[Absynth-VST] ==================")
            print(code)
            print(f"[Absynth-VST] ==================")
            
            # Ensure the code saves to the correct directory
            output_path = os.path.join(self._default_midi_folder, filename)
            
            # Prepare safe execution environment
            safe_globals = {
                '__builtins__': __builtins__,
                'MIDIFile': None,
                'math': None,
                'os': None,
                'print': print
            }
            
            # Import required modules in safe environment
            import math
            from midiutil import MIDIFile
            safe_globals['MIDIFile'] = MIDIFile
            safe_globals['math'] = math
            
            # Change to MIDI directory before execution
            original_dir = os.getcwd()
            os.chdir(self._default_midi_folder)
            
            try:
                # Execute the generated code
                print(f"[Absynth-VST] Executing generated code...")
                exec(code, safe_globals)
                print(f"[Absynth-VST] ✓ Code executed successfully")
                
                # Check if file was created
                if os.path.exists(filename):
                    print(f"[Absynth-VST] ✓ MIDI file created: {filename}")
                    return True
                else:
                    print(f"[Absynth-VST] ✗ MIDI file not found after execution")
                    return False
                    
            finally:
                # Always restore original directory
                os.chdir(original_dir)
            
        except Exception as e:
            print(f"[Absynth-VST] ✗ Code execution error: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _create_fallback_midi(self, prompt, filename, bpm, duration):
        """Create a musically sophisticated fallback MIDI with Circle of Fifths harmony"""
        print("[Absynth-VST] Using fallback MIDI generation with Circle of Fifths")
        
        output_path = os.path.join(self._default_midi_folder, filename)
        
        try:
            # Try midiutil first (preferred)
            try:
                from midiutil import MIDIFile
                use_midiutil = True
                print("[Absynth-VST] Using midiutil for fallback")
            except ImportError:
                print("[Absynth-VST] midiutil not found, using mido for fallback")
                use_midiutil = False
            
            import random
            
            # Parse prompt for key detection
            prompt_lower = prompt.lower()
            
            # Tonart-Erkennung aus dem Prompt mit Circle of Fifths
            detected_key = None
            
            # Prüfe auf spezifische Tonarten (ERWEITERT - alle 24 Tonarten)
            # WICHTIG: Längere Patterns zuerst prüfen (z.B. "f# minor" vor "f minor")
            key_patterns = [
                # F# und D# patterns ZUERST (längere zuerst!)
                ('f# minor', 'F#m'), ('f sharp minor', 'F#m'), ('fis moll', 'F#m'), ('f# min', 'F#m'),
                ('d# minor', 'D#m'), ('d sharp minor', 'D#m'), ('dis moll', 'D#m'), ('d# min', 'D#m'),
                ('c# minor', 'C#m'), ('c sharp minor', 'C#m'), ('cis moll', 'C#m'), ('c# min', 'C#m'),
                ('g# minor', 'G#m'), ('g sharp minor', 'G#m'), ('gis moll', 'G#m'), ('g# min', 'G#m'),
                ('a# minor', 'Bbm'), ('a sharp minor', 'Bbm'), ('ais moll', 'Bbm'),
                ('f# major', 'F#'), ('f sharp major', 'F#'), ('fis dur', 'F#'), ('f# maj', 'F#'),
                ('c# major', 'Db'), ('c sharp major', 'Db'), ('cis dur', 'Db'),
                
                # Dann kürzere Patterns
                ('c major', 'C'), ('c dur', 'C'), ('c-dur', 'C'), ('c maj', 'C'),
                ('g major', 'G'), ('g dur', 'G'), ('g-dur', 'G'), ('g maj', 'G'),
                ('d major', 'D'), ('d dur', 'D'), ('d-dur', 'D'), ('d maj', 'D'),
                ('a major', 'A'), ('a dur', 'A'), ('a-dur', 'A'), ('a maj', 'A'),
                ('e major', 'E'), ('e dur', 'E'), ('e-dur', 'E'), ('e maj', 'E'),
                ('b major', 'B'), ('b dur', 'B'), ('b-dur', 'B'), ('b maj', 'B'), ('h dur', 'B'),
                ('gb major', 'F#'), ('ges dur', 'F#'),
                ('db major', 'Db'), ('d flat major', 'Db'), ('des dur', 'Db'), ('db maj', 'Db'),
                ('ab major', 'Ab'), ('a flat major', 'Ab'), ('as dur', 'Ab'), ('ab maj', 'Ab'),
                ('eb major', 'Eb'), ('e flat major', 'Eb'), ('es dur', 'Eb'), ('eb maj', 'Eb'),
                ('bb major', 'Bb'), ('b flat major', 'Bb'), ('bes dur', 'Bb'), ('bb maj', 'Bb'),
                ('f major', 'F'), ('f dur', 'F'), ('f-dur', 'F'), ('f maj', 'F'),
                
                ('a minor', 'Am'), ('a moll', 'Am'), ('a-moll', 'Am'), ('a min', 'Am'),
                ('e minor', 'Em'), ('e moll', 'Em'), ('e-moll', 'Em'), ('e min', 'Em'),
                ('b minor', 'Bm'), ('b moll', 'Bm'), ('b-moll', 'Bm'), ('h moll', 'Bm'), ('b min', 'Bm'),
                ('eb minor', 'D#m'), ('e flat minor', 'D#m'), ('es moll', 'D#m'),
                ('bb minor', 'Bbm'), ('b flat minor', 'Bbm'), ('bes moll', 'Bbm'), ('bb min', 'Bbm'),
                ('f minor', 'Fm'), ('f moll', 'Fm'), ('f-moll', 'Fm'), ('f min', 'Fm'),
                ('c minor', 'Cm'), ('c moll', 'Cm'), ('c-moll', 'Cm'), ('c min', 'Cm'),
                ('g minor', 'Gm'), ('g moll', 'Gm'), ('g-moll', 'Gm'), ('g min', 'Gm'),
                ('d minor', 'Dm'), ('d moll', 'Dm'), ('d-moll', 'Dm'), ('d min', 'Dm'),
            ]
            
            # Durchsuche Prompt mit längsten Patterns zuerst
            for pattern, key_name in key_patterns:
                if pattern in prompt_lower:
                    detected_key = key_name
                    print(f"[Absynth-VST] ✓ Detected key from prompt: {detected_key} (pattern: '{pattern}')")
                    break
            
            # Wenn keine spezifische Tonart gefunden, wähle basierend auf Stimmung
            if not detected_key:
                if 'dark' in prompt_lower or 'sad' in prompt_lower or 'minor' in prompt_lower:
                    detected_key = random.choice(['Am', 'Em', 'Dm'])
                else:
                    detected_key = random.choice(['C', 'G', 'F', 'D'])
            
            # Hole Key-Info aus Circle of Fifths
            key_info = self.CIRCLE_OF_FIFTHS.get(detected_key)
            
            if not key_info:
                print(f"[Absynth-VST] ⚠ Warning: Key {detected_key} not in Circle of Fifths, using C major")
                detected_key = 'C'
                key_info = self.CIRCLE_OF_FIFTHS['C']
            
            root = key_info['root']
            scale = key_info['scale']
            scale_name = f"{detected_key} {key_info['type']}"
            
            print(f"[Absynth-VST] ==================")
            print(f"[Absynth-VST] KEY INFORMATION:")
            print(f"[Absynth-VST] Key: {scale_name}")
            print(f"[Absynth-VST] Root note: {root} (MIDI note number)")
            print(f"[Absynth-VST] Scale intervals: {scale}")
            print(f"[Absynth-VST] ==================")
            
            print(f"[Absynth-VST] Root note: {root} (MIDI)")
            print(f"[Absynth-VST] Scale: {scale}")
            
            # Determine musical type
            is_chords = 'chord' in prompt_lower or 'progression' in prompt_lower
            is_riff = 'riff' in prompt_lower or 'pattern' in prompt_lower or 'groove' in prompt_lower
            is_pad = 'pad' in prompt_lower or 'ambient' in prompt_lower or 'atmosphere' in prompt_lower
            is_bass = 'bass' in prompt_lower and not is_chords
            is_arpeggio = 'arp' in prompt_lower or 'arpeggio' in prompt_lower or 'arpeggiated' in prompt_lower
            is_sequence = 'sequence' in prompt_lower or 'sequencer' in prompt_lower or 'seq' in prompt_lower
            is_complex = 'complex' in prompt_lower or 'intricate' in prompt_lower or 'detailed' in prompt_lower
            
            # GENRE DETECTION for rhythm patterns
            detected_genre = 'default'
            if 'trance' in prompt_lower:
                detected_genre = 'trance'
            elif 'house' in prompt_lower or 'deep house' in prompt_lower or 'tech house' in prompt_lower:
                detected_genre = 'house'
            elif 'techno' in prompt_lower:
                detected_genre = 'techno'
            elif 'electro' in prompt_lower:
                detected_genre = 'electro'
            elif 'edm' in prompt_lower or 'big room' in prompt_lower or 'bigroom' in prompt_lower or 'festival' in prompt_lower:
                detected_genre = 'edm'
            elif 'hip hop' in prompt_lower or 'hiphop' in prompt_lower or 'hip-hop' in prompt_lower or 'trap' in prompt_lower:
                detected_genre = 'hiphop'
            elif 'pop' in prompt_lower:
                detected_genre = 'pop'
            
            # Store genre for use in chord generation
            self._current_genre = detected_genre
            
            print(f"[Absynth-VST] Detected genre: {detected_genre}")
            
            # Determine pattern type with priority
            if is_arpeggio:
                pattern_type = 'arpeggio'
            elif is_sequence:
                pattern_type = 'sequence'
            elif is_chords:
                pattern_type = 'chords'
            elif is_riff:
                pattern_type = 'riff'
            elif is_pad:
                pattern_type = 'pad'
            elif is_bass:
                pattern_type = 'bass'
            else:
                pattern_type = 'melody'
            
            print(f"[Absynth-VST] Type: {pattern_type}")
            
            # Determine octave range and characteristics
            if pattern_type == 'bass':
                root = 36  # Low bass range
                octave_range = 2
                velocity_base = 100
                velocity_variation = 20
            elif pattern_type == 'pad':
                root = 48
                octave_range = 3
                velocity_base = 65
                velocity_variation = 10
            elif pattern_type == 'riff':
                root = 55
                octave_range = 2
                velocity_base = 95
                velocity_variation = 15
            else:  # Melody/lead/arpeggio/sequence
                root = 60
                octave_range = 2
                velocity_base = 90
                velocity_variation = 20
            
            phrases = []
            current_time = 0.0
            beats_total = (bpm / 60.0) * duration
            
            print(f"[Absynth-VST] Target duration: {duration}s = {beats_total:.2f} beats at {bpm} BPM")
            
            # Generate appropriate musical content using Circle of Fifths
            while current_time < beats_total:
                if pattern_type == 'chords':
                    phrase = self._generate_chord_progression(
                        root, scale, 4.0, velocity_base, velocity_variation, key_info
                    )
                elif pattern_type == 'arpeggio':
                    phrase = self._generate_arpeggio(
                        root, scale, velocity_base, velocity_variation, key_info, detected_genre
                    )
                elif pattern_type == 'sequence':
                    phrase = self._generate_sequence(
                        root, scale, velocity_base, velocity_variation, key_info, detected_genre
                    )
                elif pattern_type == 'riff':
                    phrase = self._generate_riff(
                        root, scale, octave_range, velocity_base, velocity_variation
                    )
                elif pattern_type == 'pad':
                    phrase = self._generate_pad(
                        root, scale, 8.0, velocity_base, velocity_variation, key_info
                    )
                else:
                    phrase = self._generate_musical_phrase(
                        root, scale, octave_range, 8, prompt_lower, 
                        velocity_base, velocity_variation
                    )
                
                if not phrase:
                    print("[Absynth-VST] WARNING: Empty phrase generated")
                    break
                
                # Adjust phrase times
                for note_data in phrase:
                    note_data['time'] += current_time
                
                phrases.extend(phrase)
                
                # Calculate phrase duration
                if phrase:
                    phrase_end = max(n['time'] + n['duration'] for n in phrase)
                    phrase_duration = phrase_end - current_time
                    current_time += phrase_duration
                else:
                    current_time += 4.0
            
            if not phrases:
                print("[Absynth-VST] WARNING: No phrases generated, creating default")
                for i in range(8):
                    phrases.append({
                        'note': root + scale[i % len(scale)],
                        'time': float(i * 0.5),
                        'duration': 0.5,
                        'velocity': velocity_base
                    })
            
            actual_duration = max(n['time'] + n['duration'] for n in phrases) if phrases else 0
            print(f"[Absynth-VST] Generated {len(phrases)} notes, actual duration: {actual_duration:.2f} beats ({actual_duration / (bpm / 60.0):.2f}s)")
            
            if use_midiutil:
                from midiutil import MIDIFile
                
                # CRITICAL FIX: Force single track MIDI file
                # numTracks=1 means only ONE track will exist
                midi = MIDIFile(
                    numTracks=1,
                    removeDuplicates=True,
                    deinterleave=False,
                    adjust_origin=False
                )
                
                track = 0  # EVERYTHING goes to track 0
                channel = 0  # EVERYTHING on channel 0
                time = 0  # Start at beat 0
                
                # Set tempo FIRST (at time 0 on track 0)
                midi.addTempo(track, time, bpm)
                print(f"[Absynth-VST] ✓ Tempo: {bpm} BPM")
                
                # Set program based on type
                program = 81  # Default: Lead 2 (sawtooth)
                if pattern_type == 'pad':
                    program = 89  # Pad 2 (warm)
                elif pattern_type == 'bass':
                    program = 38  # Synth Bass 1
                elif pattern_type == 'arpeggio' or pattern_type == 'sequence':
                    program = 81  # Lead 2 (sawtooth)
                
                midi.addProgramChange(track, channel, time, program)
                print(f"[Absynth-VST] ✓ Single track mode (track 0, channel 0, program {program})")
                
                notes_added = 0
                last_note_end = {}
                
                phrases_sorted = sorted(phrases, key=lambda x: x['time'])
                
                # Debug: Check timing
                if phrases_sorted:
                    first_note_time = phrases_sorted[0]['time']
                    last_note_time = max(n['time'] + n['duration'] for n in phrases_sorted)
                    print(f"[Absynth-VST] Note timing: first={first_note_time:.3f}, last={last_note_time:.3f} beats")
                    print(f"[Absynth-VST] At {bpm} BPM: {first_note_time * 60/bpm:.3f}s to {last_note_time * 60/bpm:.3f}s")
                
                # Add ALL notes to track 0, channel 0
                for note_data in phrases_sorted:
                    note = note_data['note']
                    start_time = note_data['time']
                    duration_beats = note_data['duration']
                    velocity = note_data['velocity']
                    
                    # Validate
                    note = max(0, min(127, int(note)))
                    velocity = max(1, min(127, int(velocity)))
                    start_time = max(0.0, float(start_time))
                    duration_beats = max(0.1, float(duration_beats))
                    
                    # Prevent overlaps on same note
                    note_key = note
                    if note_key in last_note_end:
                        if start_time < last_note_end[note_key]:
                            gap = 0.05
                            start_time = last_note_end[note_key] + gap
                    
                    end_time = start_time + duration_beats
                    last_note_end[note_key] = end_time
                    
                    try:
                        # ALL notes: track=0, channel=0
                        midi.addNote(
                            track=track,      # Always 0
                            channel=channel,  # Always 0
                            pitch=note,
                            time=start_time,
                            duration=duration_beats,
                            volume=velocity
                        )
                        notes_added += 1
                    except Exception as note_error:
                        print(f"[Absynth-VST] Warning: Skipped note {note} at {start_time}: {note_error}")
                        continue
                
                if notes_added == 0:
                    print("[Absynth-VST] ERROR: No notes added, creating default")
                    midi.addNote(track, channel, 60, 0.0, 1.0, 100)
                    notes_added = 1
                
                print(f"[Absynth-VST] Added {notes_added} notes to MIDI file")
                
                # Verify tempo is set correctly
                print(f"[Absynth-VST] ==================")
                print(f"[Absynth-VST] TEMPO VERIFICATION:")
                print(f"[Absynth-VST] Set BPM: {bpm}")
                print(f"[Absynth-VST] Pattern type: {pattern_type}")
                print(f"[Absynth-VST] Expected duration at {bpm} BPM: {duration}s")
                print(f"[Absynth-VST] Total beats generated: {beats_total:.2f}")
                print(f"[Absynth-VST] Calculated playback time: {(beats_total * 60.0 / bpm):.2f}s")
                print(f"[Absynth-VST] ==================")
                
                os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
                
                with open(output_path, "wb") as f:
                    midi.writeFile(f)
                
                if os.path.exists(output_path):
                    file_size = os.path.getsize(output_path)
                    print(f"[Absynth-VST] ==================")
                    print(f"[Absynth-VST] MIDI FILE CREATED:")
                    print(f"[Absynth-VST] File: {os.path.basename(output_path)}")
                    print(f"[Absynth-VST] Size: {file_size} bytes")
                    print(f"[Absynth-VST] Notes: {notes_added}")
                    print(f"[Absynth-VST] Tracks: 1 (single track)")
                    print(f"[Absynth-VST] Key: {scale_name}")
                    print(f"[Absynth-VST] BPM: {bpm}")
                    print(f"[Absynth-VST] ==================")
            
            else:
                # Fallback to mido
                print("[Absynth-VST] Using mido for MIDI generation")
                
                # CRITICAL FIX FOR CUBASE: Type 0 MIDI with EVERYTHING on Channel 0
                mid = mido.MidiFile(type=0, ticks_per_beat=480)
                
                track = mido.MidiTrack()
                mid.tracks.append(track)
                
                # Track metadata
                track.append(mido.MetaMessage('track_name', name='Absynth VST', time=0))
                
                # Set tempo
                tempo = mido.bpm2tempo(bpm)
                track.append(mido.MetaMessage('set_tempo', tempo=tempo, time=0))
                print(f"[Absynth-VST] ✓ Tempo: {bpm} BPM")
                
                # CRITICAL FOR CUBASE: Set program on CHANNEL 0 ONLY
                program = 81
                if pattern_type == 'pad':
                    program = 89
                elif pattern_type == 'bass':
                    program = 38
                
                track.append(mido.Message('program_change', program=program, channel=0, time=0))
                print(f"[Absynth-VST] ✓ Type 0 MIDI (single track, channel 0, program {program})")
                
                ticks_per_beat = 480
                channel = 0  # EVERYTHING on channel 0
                events = []
                
                # Create note on/off events
                for note_data in phrases:
                    note = note_data['note']
                    time_beats = note_data['time']
                    duration_beats = note_data['duration']
                    velocity = note_data['velocity']
                    
                    note = max(0, min(127, int(note)))
                    velocity = max(1, min(127, int(velocity)))
                    
                    events.append({
                        'time': time_beats,
                        'type': 'note_on',
                        'note': note,
                        'velocity': velocity,
                        'channel': 0  # ← CRITICAL: Always channel 0
                    })
                    
                    events.append({
                        'time': time_beats + duration_beats,
                        'type': 'note_off',
                        'note': note,
                        'velocity': 0,
                        'channel': 0  # ← CRITICAL: Always channel 0
                    })
                
                # Sort events
                events.sort(key=lambda x: (x['time'], x['type'] == 'note_off'))
                
                # Add events with delta times
                last_time = 0.0
                for event in events:
                    delta_time_beats = event['time'] - last_time
                    delta_time_ticks = max(0, int(delta_time_beats * ticks_per_beat))
                    
                    if event['type'] == 'note_on':
                        track.append(mido.Message('note_on', 
                                                 note=event['note'], 
                                                 velocity=event['velocity'],
                                                 channel=0,  # ← CRITICAL
                                                 time=delta_time_ticks))
                    else:
                        track.append(mido.Message('note_off', 
                                                 note=event['note'], 
                                                 velocity=0,
                                                 channel=0,  # ← CRITICAL
                                                 time=delta_time_ticks))
                    
                    last_time = event['time']
                
                # End of track
                track.append(mido.MetaMessage('end_of_track', time=0))
                
                print(f"[Absynth-VST] ✓ Added {len(events)} events (all on channel 0)")
                
                os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
                mid.save(output_path)
                
                # VERIFY for Cubase
                try:
                    verify = mido.MidiFile(output_path)
                    print(f"[Absynth-VST] ==================")
                    print(f"[Absynth-VST] CUBASE-COMPATIBLE MIDI:")
                    print(f"[Absynth-VST] Type: {verify.type} (Type 0 = single track)")
                    print(f"[Absynth-VST] Tracks: {len(verify.tracks)}")
                    print(f"[Absynth-VST] All events on Channel 0: ✓")
                    print(f"[Absynth-VST] ==================")
                    
                    # Check if any events use other channels
                    other_channels = False
                    for track in verify.tracks:
                        for msg in track:
                            if hasattr(msg, 'channel') and msg.channel != 0:
                                other_channels = True
                                print(f"[Absynth-VST] ⚠ Found event on channel {msg.channel}!")
                    
                    if not other_channels:
                        print(f"[Absynth-VST] ✓ Verified: All events on channel 0")
                    
                except Exception as e:
                    print(f"[Absynth-VST] Could not verify: {e}")
                
                print(f"[Absynth-VST] ✓ MIDI saved for Cubase")
            
            print(f"[Absynth-VST] ✓ Fallback MIDI created: {output_path}")
            return output_path
            
        except Exception as e:
            print(f"[Absynth-VST] ✗ Fallback MIDI creation failed: {e}")
            import traceback
            traceback.print_exc()
            return output_path
    
    def _generate_chord_progression(self, root, scale, chord_duration, velocity_base, velocity_variation, key_info=None):
        """Generate a chord progression using Circle of Fifths harmony"""
        import random
        
        chords = []
        
        # If we have key info from Circle of Fifths, use it
        if key_info and 'chords' in key_info:
            print(f"[Absynth-VST] Using Circle of Fifths harmony")
            
            # FUNKTIONSHARMONIK-basierte Progressionen
            if key_info['type'] == 'major':
                # DUR: Funktionsharmonische Progressionen
                functional_progressions = [
                    ['I', 'IV', 'V', 'I'],       # Authentische Kadenz
                    ['I', 'V', 'vi', 'IV'],      # Pop-Progression (Axis)
                    ['vi', 'IV', 'I', 'V'],      # Empfindsame Progression
                    ['I', 'vi', 'IV', 'V'],      # 50s Progression
                    ['I', 'V', 'IV', 'I'],       # Double Plagal
                    ['I', 'iii', 'vi', 'IV'],    # Kreisquintfall-ähnlich
                    ['I', 'vi', 'ii', 'V'],      # Jazz-influenced
                    ['I', 'IV', 'vi', 'V'],      # Alternative Pop
                    ['vi', 'V', 'IV', 'I'],      # Deceptive resolution
                    ['I', 'V', 'vi', 'iii', 'IV', 'I'],  # Extended
                    ['I', 'iii', 'IV', 'V'],
                    ['vi', 'IV', 'V', 'V'],      # Repeated dominant
                    ['I', 'IV', 'I', 'V'],       # Pendulum
                ]
            else:
                # MOLL: Funktionsharmonische Progressionen
                functional_progressions = [
                    ['i', 'iv', 'v', 'i'],       # Natürliche Moll-Kadenz
                    ['i', 'VI', 'III', 'VII'],   # Andalusische Kadenz
                    ['i', 'VII', 'VI', 'v'],     # Moll-Variante
                    ['i', 'iv', 'VII', 'i'],     # Mixolydisch beeinflusst
                    ['i', 'VI', 'III', 'VII'],   # Episch/cinematisch
                    ['i', 'VII', 'VI', 'VII'],   # Dorian feel
                    ['i', 'III', 'VII', 'iv'],   # Dark progression
                    ['i', 'v', 'VI', 'III'],     # Ascending
                    ['i', 'iv', 'VI', 'VII'],    # Phrygian touch
                    ['i', 'VII', 'VI', 'VII', 'i'],
                    ['i', 'III', 'VII', 'iv', 'i'],
                ]
            
            progression = random.choice(functional_progressions)
            print(f"[Absynth-VST] Chord progression: {' - '.join(progression)}")
            
            # Voice leading und Inversionen
            use_voice_leading = random.choice([True, True, False])
            add_sevenths = random.choice([True, False, False])
            
            current_time = 0.0
            last_chord_notes = None
            
            for chord_idx, degree in enumerate(progression):
                # Hole die Akkord-Intervalle aus dem Circle of Fifths
                chord_intervals = key_info['chords'].get(degree, [0, 4, 7])
                
                # Baue den Akkord
                chord_notes = [root + interval for interval in chord_intervals]
                
                # Füge Oktaven hinzu
                chord_notes.append(chord_notes[0] + 12)
                
                # Optional: Septime hinzufügen
                if add_sevenths:
                    if key_info['type'] == 'major':
                        if degree in ['I', 'IV']:
                            seventh = chord_notes[-1] + 11 - chord_intervals[0]
                        elif degree in ['V']:
                            seventh = chord_notes[-1] + 10 - chord_intervals[0]
                        else:
                            seventh = chord_notes[-1] + 10 - chord_intervals[0]
                    else:
                        if degree in ['i', 'iv', 'v']:
                            seventh = chord_notes[-1] + 10 - chord_intervals[0]
                        else:
                            seventh = chord_notes[-1] + 11 - chord_intervals[0]
                    
                    chord_notes.append(seventh)
                
                # Voice Leading
                if use_voice_leading and last_chord_notes:
                    best_inversion = chord_notes[:]
                    min_movement = float('inf')
                    
                    for inversion in range(len(chord_intervals)):
                        test_notes = chord_notes[:]
                        for _ in range(inversion):
                            moved_note = test_notes.pop(0)
                            test_notes.append(moved_note + 12)
                        
                        total_movement = sum(
                            min(abs(new - old) for old in last_chord_notes)
                            for new in test_notes[:len(last_chord_notes)]
                        )
                        
                        if total_movement < min_movement:
                            min_movement = total_movement
                            best_inversion = test_notes
                    
                    chord_notes = best_inversion
                
                last_chord_notes = chord_notes[:]
                
                # Dynamik
                velocity = velocity_base + random.randint(-velocity_variation//2, velocity_variation//2)
                velocity = max(50, min(120, velocity))
                
                # Humanisierung
                for note_idx, note in enumerate(chord_notes):
                    timing_offset = random.uniform(-0.01, 0.01) * note_idx
                    note_velocity = velocity + random.randint(-5, 5)
                    
                    chords.append({
                        'note': max(24, min(120, note)),
                        'time': current_time + timing_offset,
                        'duration': chord_duration * random.uniform(0.96, 1.0),
                        'velocity': max(40, min(127, note_velocity))
                    })
                
                current_time += chord_duration
            
            return chords
        
        # Fallback zu einfacher Methode
        return self._generate_simple_chord_progression(root, scale, chord_duration, velocity_base, velocity_variation)
    
    def _generate_simple_chord_progression(self, root, scale, chord_duration, velocity_base, velocity_variation):
        """Simple chord progression as fallback"""
        import random
        
        chords = []
        progressions = [
            [0, 3, 4, 0],
            [0, 4, 3, 0],
            [0, 5, 3, 4],
            [0, 4, 5, 3],
            [5, 3, 0, 4],
        ]
        
        progression = random.choice(progressions)
        use_inversions = random.choice([True, False])
        add_bass = random.choice([True, False])
        
        current_time = 0.0
        
        for chord_idx, degree in enumerate(progression):
            chord_root = root + scale[degree % len(scale)]
            third_degree = (degree + 2) % len(scale)
            third_note = chord_root + scale[third_degree] - scale[degree]
            if third_note <= chord_root:
                third_note += 12
            
            fifth_degree = (degree + 4) % len(scale)
            fifth_note = chord_root + scale[fifth_degree] - scale[degree]
            if fifth_note <= third_note:
                fifth_note += 12
            
            chord_notes = []
            
            if use_inversions:
                inversion = chord_idx % 3
                if inversion == 1:
                    chord_notes = [third_note, fifth_note, chord_root + 12]
                elif inversion == 2:
                    chord_notes = [fifth_note, chord_root + 12, third_note + 12]
                else:
                    chord_notes = [chord_root, third_note, fifth_note]
            else:
                chord_notes = [chord_root, third_note, fifth_note]
            
            if add_bass:
                bass_note = chord_root - 12
                if bass_note >= 24:
                    chord_notes.insert(0, bass_note)
            
            chord_notes.append(chord_root + 12)
            
            velocity = velocity_base + random.randint(-velocity_variation, velocity_variation)
            velocity = max(40, min(127, velocity))
            
            timing_offset = random.uniform(-0.02, 0.02)
            
            for note in chord_notes:
                chords.append({
                    'note': max(12, min(120, note)),
                    'time': current_time + timing_offset,
                    'duration': chord_duration * random.uniform(0.95, 1.0),
                    'velocity': velocity + random.randint(-5, 5)
                })
            
            current_time += chord_duration
        
        return chords
    
    def _generate_riff(self, root, scale, octave_range, velocity_base, velocity_variation):
        """Generate a repeating riff pattern with variations"""
        import random
        
        riff = []
        
        rhythm_patterns = [
            [0.25, 0.25, 0.5, 0.5, 0.25, 0.25, 1.0],
            [0.5, 0.25, 0.25, 0.5, 0.5, 1.0],
            [0.25, 0.5, 0.25, 0.5, 0.5, 0.5, 0.5],
            [0.5, 0.5, 0.25, 0.25, 0.25, 0.25, 1.0],
            [0.25, 0.25, 0.25, 0.75, 0.5, 1.0],
            [0.75, 0.25, 0.5, 0.5, 1.0],
            [0.25, 0.75, 0.5, 0.25, 0.25, 1.0],
            [0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 1.0],
            [0.125, 0.125, 0.25, 0.5, 0.125, 0.125, 0.25, 0.5],
            [0.33, 0.33, 0.34, 0.5, 0.5, 1.0],
            [0.5, 0.33, 0.33, 0.34, 0.5, 1.0],
            [0.25, 0.25, 0.25, 0.25, 0.5, 0.5, 1.0],
            [0.5, 0.5, 0.5, 0.5, 1.0],
            [0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 1.0],
        ]
        
        rhythm = random.choice(rhythm_patterns)
        
        movement_styles = ['stepwise', 'stepwise', 'jumpy', 'pedal_tone', 'ascending', 'descending']
        style = random.choice(movement_styles)
        
        note_pattern = []
        current_degree = random.choice([0, 0, 2, 4])
        
        for i in range(len(rhythm)):
            note = root + scale[current_degree % len(scale)]
            note_pattern.append(max(12, min(120, note)))
            
            if style == 'stepwise':
                move = random.choice([-1, -1, 0, 1, 1, 2])
            elif style == 'jumpy':
                move = random.choice([-4, -3, -2, 2, 3, 4, 5])
            elif style == 'pedal_tone':
                if i % 2 == 0:
                    move = random.choice([2, 3, 4, 5])
                else:
                    current_degree = 0
                    move = 0
            elif style == 'ascending':
                move = random.choice([1, 1, 2, 2, 3])
            elif style == 'descending':
                move = random.choice([-3, -2, -2, -1, -1])
            else:
                move = random.choice([-2, -1, 0, 1, 2])
            
            current_degree = (current_degree + move) % len(scale)
        
        current_time = 0.0
        for i, (note, duration) in enumerate(zip(note_pattern, rhythm)):
            is_downbeat = (current_time % 1.0 < 0.01)
            is_offbeat = (abs(current_time % 1.0 - 0.5) < 0.01)
            
            if is_downbeat:
                velocity = velocity_base + 20
            elif is_offbeat and random.random() < 0.5:
                velocity = velocity_base + 10
            else:
                velocity = velocity_base
            
            velocity += random.randint(-velocity_variation//2, velocity_variation//2)
            velocity = max(40, min(127, velocity))
            
            note_duration = duration * random.uniform(0.85, 0.95)
            
            riff.append({
                'note': note,
                'time': current_time,
                'duration': note_duration,
                'velocity': velocity
            })
            
            current_time += duration
        
        repeat_with_variation = random.choice([True, False])
        riff_duration = current_time
        
        if repeat_with_variation:
            for note_data in list(riff):
                new_note = note_data['note']
                if random.random() < 0.3:
                    variation = random.choice([-2, -1, 1, 2])
                    degree_shift = (scale.index(new_note - root) + variation) % len(scale) if (new_note - root) in scale else 0
                    new_note = root + scale[degree_shift]
                
                riff.append({
                    'note': max(12, min(120, new_note)),
                    'time': note_data['time'] + riff_duration,
                    'duration': note_data['duration'],
                    'velocity': note_data['velocity'] + random.randint(-5, 5)
                })
        else:
            for note_data in list(riff):
                riff.append({
                    'note': note_data['note'],
                    'time': note_data['time'] + riff_duration,
                    'duration': note_data['duration'],
                    'velocity': note_data['velocity']
                })
        
        return riff
    
    def _generate_pad(self, root, scale, pad_duration, velocity_base, velocity_variation, key_info=None):
        """Generate ambient pad chords"""
        import random
        
        pad = []
        
        if key_info and 'chords' in key_info:
            # Use Circle of Fifths chords for pads too
            if key_info['type'] == 'major':
                pad_progressions = [
                    ['I', 'IV', 'V', 'I'],
                    ['I', 'vi', 'IV', 'V'],
                    ['vi', 'IV', 'V', 'I'],
                    ['I', 'V', 'vi', 'IV'],
                    ['I', 'iii', 'vi', 'IV'],
                    ['vi', 'IV', 'I', 'V'],
                    ['I', 'IV', 'vi', 'V'],
                ]
            else:
                pad_progressions = [
                    ['i', 'iv', 'v', 'i'],
                    ['i', 'VI', 'III', 'VII'],
                    ['i', 'VII', 'VI', 'v'],
                    ['i', 'iv', 'VII', 'i'],
                    ['i', 'VI', 'III', 'VII'],
                    ['i', 'VII', 'VI', 'VII'],
                ]
            
            degrees = random.choice(pad_progressions)
        else:
            # Fallback to simple degrees
            degrees = random.choice([
                [0, 3, 4, 0],
                [0, 5, 3, 4],
                [5, 3, 4, 0],
                [0, 4, 5, 3],
                [0, 2, 5, 3],
                [5, 3, 0, 4],
                [0, 3, 5, 4],
            ])
        
        chord_changes = len(degrees)
        duration_per_chord = pad_duration / chord_changes
        
        use_wide_voicing = random.choice([True, False])
        add_ninths = random.choice([True, False, False])
        use_suspended = random.random() < 0.2
        
        current_time = 0.0
        
        for chord_idx, degree in enumerate(degrees):
            notes_in_chord = []
            
            if key_info and 'chords' in key_info and isinstance(degree, str):
                # Use Circle of Fifths chords
                chord_intervals = key_info['chords'].get(degree, [0, 4, 7])
                chord_root = root + chord_intervals[0]
                notes_in_chord = [root + interval for interval in chord_intervals]
            else:
                # Fallback method
                chord_root = root + scale[degree % len(scale)]
                
                is_sus_chord = use_suspended and (chord_idx % 2 == 1)
                
                if is_sus_chord:
                    notes_in_chord.append(chord_root)
                    fourth_degree = (degree + 3) % len(scale)
                    fourth_note = chord_root + scale[fourth_degree] - scale[degree]
                    if fourth_note <= chord_root:
                        fourth_note += 12
                    notes_in_chord.append(fourth_note)
                    
                    fifth_degree = (degree + 4) % len(scale)
                    fifth_note = chord_root + scale[fifth_degree] - scale[degree]
                    if fifth_note <= fourth_note:
                        fifth_note += 12
                    notes_in_chord.append(fifth_note)
                else:
                    notes_in_chord.append(chord_root)
                    third_degree = (degree + 2) % len(scale)
                    third_note = chord_root + scale[third_degree] - scale[degree]
                    if third_note <= chord_root:
                        third_note += 12
                    notes_in_chord.append(third_note)
                    
                    fifth_degree = (degree + 4) % len(scale)
                    fifth_note = chord_root + scale[fifth_degree] - scale[degree]
                    if fifth_note <= third_note:
                        fifth_note += 12
                    notes_in_chord.append(fifth_note)
            
            if use_wide_voicing:
                notes_in_chord.append(notes_in_chord[0] + 12)
                notes_in_chord.append(notes_in_chord[0] + 24)
            else:
                notes_in_chord.append(notes_in_chord[0] + 12)
            
            # Add 7th
            if key_info and 'scale' in key_info:
                seventh_degree = (degree + 6) % len(scale) if isinstance(degree, int) else 6
                if isinstance(degree, int):
                    seventh_note = notes_in_chord[0] + scale[seventh_degree]
                else:
                    seventh_note = notes_in_chord[0] + 10  # Minor 7th
                while seventh_note <= notes_in_chord[-1]:
                    seventh_note += 12
                notes_in_chord.append(seventh_note)
            
            if add_ninths:
                ninth_note = notes_in_chord[0] + 14
                while ninth_note <= notes_in_chord[-1]:
                    ninth_note += 12
                notes_in_chord.append(ninth_note)
            
            chord_position = chord_idx / max(1, len(degrees) - 1)
            curve_choice = random.choice(['crescendo', 'decrescendo', 'stable'])
            if curve_choice == 'crescendo':
                dynamic_factor = 0.7 + (chord_position * 0.3)
            elif curve_choice == 'decrescendo':
                dynamic_factor = 1.0 - (chord_position * 0.3)
            else:
                dynamic_factor = 1.0
            
            velocity = int(velocity_base * dynamic_factor) + random.randint(-velocity_variation//2, velocity_variation//2)
            velocity = max(35, min(85, velocity))
            
            for note_idx, note in enumerate(notes_in_chord):
                note_velocity = velocity + random.randint(-3, 3)
                timing_offset = random.uniform(-0.01, 0.01) * note_idx
                
                pad.append({
                    'note': max(12, min(120, note)),
                    'time': current_time + timing_offset,
                    'duration': duration_per_chord * random.uniform(0.98, 1.02),
                    'velocity': max(30, min(90, note_velocity))
                })
            
            current_time += duration_per_chord
        
        return pad
    
    def _generate_arpeggio(self, root, scale, velocity_base, velocity_variation, key_info=None, genre='default'):
        """Generate complex arpeggio patterns like in the screenshots"""
        import random
        
        arpeggio = []
        
        print(f"[Absynth-VST] Generating {genre} arpeggio pattern")
        
        # Get chord progression from Circle of Fifths
        if key_info and 'chords' in key_info:
            if key_info['type'] == 'major':
                progressions = [
                    ['I', 'V', 'vi', 'IV'],
                    ['I', 'vi', 'IV', 'V'],
                    ['vi', 'IV', 'I', 'V'],
                ]
            else:
                progressions = [
                    ['i', 'VI', 'III', 'VII'],
                    ['i', 'VII', 'VI', 'v'],
                    ['i', 'iv', 'VII', 'i'],
                ]
            
            progression = random.choice(progressions)
        else:
            # Fallback to scale degrees
            progression = [0, 4, 5, 3]
        
        # ARPEGGIO PATTERNS (genre-specific)
        if genre == 'trance':
            # Trance: Fast 16th note arpeggios, often in 16-step patterns
            arp_patterns = [
                # Classic trance arpeggio (up, up octave, down)
                [0, 2, 4, 2, 0+12, 2+12, 4+12, 2+12, 4+12, 2+12, 0+12, 2+12, 4, 2, 0, 2],
                # Rolling pattern
                [0, 2, 4, 0+12, 2+12, 4+12, 0+12, 4+12, 2+12, 4, 2, 0, 4, 2, 0, 4],
                # Octave jumps
                [0, 0+12, 2, 2+12, 4, 4+12, 2, 2+12, 0, 0+12, 4, 4+12, 2, 2+12, 0, 0+12],
            ]
            note_duration = 0.125  # 16th notes
            
        elif genre == 'techno':
            # Techno: Minimal, repetitive, hypnotic
            arp_patterns = [
                # Minimal pattern
                [0, 4, 2, 4, 0, 4, 2, 4],
                # Two-note oscillation
                [0, 4, 0, 4, 0, 4, 0, 4, 2, 4, 2, 4, 2, 4, 2, 4],
                # Stepwise climb
                [0, 2, 4, 6, 0, 2, 4, 6],
            ]
            note_duration = 0.25  # Slower, quarter notes
            
        elif genre == 'house':
            # House: Groovy, syncopated arpeggios
            arp_patterns = [
                # Funky pattern
                [0, 4, 0, 2, 4, 2, 0, 4],
                # Skipping pattern
                [0, 0, 4, 4, 2, 2, 4, 4],
                # House progression
                [0, 2, 4, 2, 0+12, 4, 2, 0],
            ]
            note_duration = 0.125
            
        else:
            # Default: Versatile patterns
            arp_patterns = [
                [0, 2, 4, 2],  # Up and down
                [0, 2, 4, 0+12],  # Up to octave
                [0, 4, 2, 4, 0, 4, 2, 0],  # Alternating
                [0, 2, 4, 6, 4, 2, 0, 2],  # Scale run
            ]
            note_duration = 0.25
        
        arp_pattern = random.choice(arp_patterns)
        
        # Generate arpeggio for each chord
        current_time = 0.0
        chord_duration = 4.0  # Each chord lasts 4 beats
        
        for chord_degree in progression:
            # Get chord notes
            if key_info and 'chords' in key_info and isinstance(chord_degree, str):
                chord_intervals = key_info['chords'].get(chord_degree, [0, 4, 7])
                chord_root = root
            else:
                chord_root = root + scale[chord_degree % len(scale)]
                chord_intervals = [0, 4, 7]  # Major/minor triad
            
            # Build chord notes for arpeggio
            chord_notes = [chord_root + interval for interval in chord_intervals]
            
            # Apply arpeggio pattern
            notes_in_bar = int(chord_duration / note_duration)
            
            for i in range(notes_in_bar):
                # Select note from pattern
                pattern_step = i % len(arp_pattern)
                scale_degree = arp_pattern[pattern_step]
                
                # Map to chord note
                chord_note_idx = (scale_degree // 2) % len(chord_notes)
                octave_shift = (scale_degree // len(chord_notes)) * 12
                
                note = chord_notes[chord_note_idx] + octave_shift
                note = max(24, min(108, note))
                
                # Dynamic velocity variation
                beat_position = (i * note_duration) % 1.0
                if beat_position < 0.01:  # Downbeat
                    velocity = velocity_base + 20
                elif abs(beat_position - 0.5) < 0.01:  # Offbeat
                    velocity = velocity_base + 10
                else:
                    velocity = velocity_base
                
                velocity += random.randint(-velocity_variation//3, velocity_variation//3)
                velocity = max(60, min(127, velocity))
                
                arpeggio.append({
                    'note': note,
                    'time': current_time + (i * note_duration),
                    'duration': note_duration * 0.8,  # Slightly staccato
                    'velocity': velocity
                })
            
            current_time += chord_duration
        
        return arpeggio
    
    def _generate_sequence(self, root, scale, velocity_base, velocity_variation, key_info=None, genre='default'):
        """Generate complex sequencer-style patterns like in the screenshots"""
        import random
        
        sequence = []
        
        print(f"[Absynth-VST] Generating {genre} sequence pattern")
        
        # SEQUENCER PATTERNS - Complex polyrhythmic patterns
        if genre in ['techno', 'electro']:
            # Generate a 16-step sequencer pattern
            steps = 16
            step_duration = 0.25  # 16th notes
            
            # Create multiple layers
            layers = []
            
            # Layer 1: Bass notes (lower octave)
            bass_pattern = []
            bass_root = root - 24
            for i in range(steps):
                if random.random() < 0.4:  # 40% probability
                    degree = random.choice([0, 0, 0, 4, 3])  # Favor root and fifth
                    note = bass_root + scale[degree % len(scale)]
                    bass_pattern.append({
                        'note': max(24, min(60, note)),
                        'time': i * step_duration,
                        'duration': step_duration * 0.6,
                        'velocity': velocity_base + random.randint(-10, 10)
                    })
            
            # Layer 2: Mid-range notes
            mid_pattern = []
            mid_root = root - 12
            for i in range(steps):
                if random.random() < 0.5:  # 50% probability
                    degree = random.choice([0, 2, 4, 5])
                    note = mid_root + scale[degree % len(scale)]
                    mid_pattern.append({
                        'note': max(36, min(84, note)),
                        'time': i * step_duration,
                        'duration': step_duration * 0.5,
                        'velocity': velocity_base - 10 + random.randint(-5, 5)
                    })
            
            # Layer 3: High notes (sparkle)
            high_pattern = []
            high_root = root + 12
            for i in range(steps):
                if random.random() < 0.3:  # 30% probability
                    degree = random.choice([0, 2, 4, 6])
                    note = high_root + scale[degree % len(scale)]
                    high_pattern.append({
                        'note': max(60, min(108, note)),
                        'time': i * step_duration,
                        'duration': step_duration * 0.3,
                        'velocity': velocity_base + 20 + random.randint(-5, 5)
                    })
            
            # Combine layers and repeat
            pattern_duration = steps * step_duration
            num_repeats = 4
            
            for repeat in range(num_repeats):
                offset = repeat * pattern_duration
                for note_data in bass_pattern + mid_pattern + high_pattern:
                    sequence.append({
                        'note': note_data['note'],
                        'time': note_data['time'] + offset,
                        'duration': note_data['duration'],
                        'velocity': note_data['velocity']
                    })
        
        elif genre == 'trance':
            # Trance: Melodic sequences with evolving patterns
            steps = 32
            step_duration = 0.125  # Fast 16th notes
            
            # Create evolving melodic sequence
            for i in range(steps):
                # Melodic contour: rises and falls
                position = i / steps
                if position < 0.25:
                    degree_range = [0, 2, 4]
                elif position < 0.5:
                    degree_range = [2, 4, 6]
                elif position < 0.75:
                    degree_range = [4, 6, 0+7]
                else:
                    degree_range = [6, 4, 2, 0]
                
                degree = random.choice(degree_range)
                note = root + scale[degree % len(scale)]
                
                # Add octave variations
                if random.random() < 0.3:
                    note += 12
                
                note = max(48, min(96, note))
                
                # Velocity evolution
                velocity = int(velocity_base * (0.7 + position * 0.3))
                velocity += random.randint(-10, 10)
                velocity = max(60, min(120, velocity))
                
                sequence.append({
                    'note': note,
                    'time': i * step_duration,
                    'duration': step_duration * 0.7,
                    'velocity': velocity
                })
        
        else:
            # Default: Random sequencer pattern
            steps = 16
            step_duration = 0.25
            
            for i in range(steps):
                if random.random() < 0.6:
                    degree = random.choice([0, 2, 4, 5, 7])
                    note = root + scale[degree % len(scale)]
                    note += random.choice([0, 12, -12])
                    note = max(36, min(96, note))
                    
                    sequence.append({
                        'note': note,
                        'time': i * step_duration,
                        'duration': step_duration * 0.6,
                        'velocity': velocity_base + random.randint(-15, 15)
                    })
        
        return sequence
    
    def _generate_musical_phrase(self, root, scale, octave_range, phrase_beats, prompt_lower, velocity_base, velocity_variation):
        """Generate a musically coherent melodic phrase"""
        import random
        
        phrase = []
        current_time = 0.0
        
        if 'fast' in prompt_lower or 'energetic' in prompt_lower:
            rhythm_patterns = [
                [0.25, 0.25, 0.25, 0.25, 0.5, 0.5, 0.25, 0.25, 0.5],
                [0.25, 0.25, 0.5, 0.25, 0.25, 0.25, 0.25, 1.0],
                [0.125, 0.125, 0.25, 0.25, 0.5, 0.125, 0.125, 0.25, 0.5],
                [0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 1.0],
                [0.5, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 1.0],
            ]
        elif 'slow' in prompt_lower or 'ballad' in prompt_lower:
            rhythm_patterns = [
                [1.0, 1.0, 2.0, 1.0, 1.0, 2.0],
                [1.5, 0.5, 1.0, 2.0, 1.0, 2.0],
                [2.0, 1.0, 1.0, 2.0, 2.0],
                [1.0, 2.0, 1.0, 1.0, 1.0, 2.0],
                [0.75, 0.25, 1.0, 1.0, 2.0, 2.0],
            ]
        else:
            rhythm_patterns = [
                [0.5, 0.5, 1.0, 0.5, 0.5, 1.0, 1.0],
                [1.0, 0.5, 0.5, 0.75, 0.25, 1.0, 1.0],
                [0.75, 0.25, 1.0, 0.5, 0.5, 1.0, 1.0],
                [0.5, 0.5, 0.5, 0.5, 1.0, 0.5, 0.5, 1.0],
                [0.25, 0.25, 0.5, 1.0, 0.5, 0.5, 1.0, 1.0],
                [1.0, 0.25, 0.25, 0.5, 0.5, 0.5, 1.0, 1.0],
                [0.5, 0.25, 0.25, 1.0, 0.5, 0.5, 1.0],
                [0.75, 0.25, 0.5, 0.5, 1.0, 1.0, 1.0],
            ]
        
        rhythm_pattern = random.choice(rhythm_patterns)
        melody_notes = self._generate_melodic_contour(root, scale, octave_range, len(rhythm_pattern), prompt_lower)
        
        articulation_styles = ['legato', 'staccato', 'normal', 'normal']
        articulation = random.choice(articulation_styles)
        
        for i, (note, duration) in enumerate(zip(melody_notes, rhythm_pattern)):
            phrase_position = i / len(rhythm_pattern)
            
            curve_type = random.choice(['crescendo', 'decrescendo', 'swell', 'flat'])
            
            if curve_type == 'crescendo':
                dynamic_factor = 0.6 + (phrase_position * 0.4)
            elif curve_type == 'decrescendo':
                dynamic_factor = 1.0 - (phrase_position * 0.3)
            elif curve_type == 'swell':
                if phrase_position < 0.5:
                    dynamic_factor = 0.7 + (phrase_position * 0.6)
                else:
                    dynamic_factor = 1.0 - ((phrase_position - 0.5) * 0.4)
            else:
                dynamic_factor = random.uniform(0.9, 1.0)
            
            velocity = int(velocity_base * dynamic_factor + random.randint(-velocity_variation, velocity_variation))
            velocity = max(40, min(127, velocity))
            
            if articulation == 'staccato':
                note_duration = duration * random.uniform(0.4, 0.6)
            elif articulation == 'legato':
                note_duration = duration * random.uniform(0.98, 1.02)
            else:
                note_duration = duration * random.uniform(0.85, 0.95)
            
            timing_variation = random.uniform(-0.03, 0.03)
            
            phrase.append({
                'note': note,
                'time': current_time + timing_variation,
                'duration': note_duration,
                'velocity': velocity
            })
            
            current_time += duration
        
        return phrase
    
    def _generate_melodic_contour(self, root, scale, octave_range, num_notes, prompt_lower):
        """Generate melodically interesting note sequence"""
        import random
        
        notes = []
        
        if not scale or len(scale) == 0:
            scale = [0, 2, 4, 5, 7, 9, 11]
        
        if num_notes <= 0:
            num_notes = 8
        
        start_positions = [0, 0, 0, 2, 2, 4, 4]
        current_degree = random.choice(start_positions)
        current_octave = random.choice([-1, 0, 0, 0, 1])
        
        contour_shapes = [
            'arch', 'inverted_arch', 'ascending', 'descending',
            'wave', 'plateau', 'valley', 'random_walk'
        ]
        
        contour = random.choice(contour_shapes)
        
        if 'uplifting' in prompt_lower or 'rising' in prompt_lower:
            movement_bias = 1
        elif 'descending' in prompt_lower or 'falling' in prompt_lower:
            movement_bias = -1
        else:
            movement_bias = 0
        
        for i in range(num_notes):
            degree_index = current_degree % len(scale)
            note = root + scale[degree_index] + (current_octave * 12)
            note = max(12, min(120, int(note)))
            notes.append(note)
            
            position_in_phrase = i / max(1, num_notes - 1)
            
            if contour == 'arch':
                if position_in_phrase < 0.5:
                    movements = [1, 2, 2, 3, 3]
                else:
                    movements = [-3, -3, -2, -2, -1]
            elif contour == 'inverted_arch':
                if position_in_phrase < 0.5:
                    movements = [-3, -2, -2, -1, -1]
                else:
                    movements = [1, 2, 2, 3]
            elif contour == 'ascending':
                movements = [1, 1, 2, 2, 3, 3, 4]
            elif contour == 'descending':
                movements = [-4, -3, -3, -2, -2, -1, -1]
            elif contour == 'wave':
                phase = (i % 4) / 4.0
                if phase < 0.5:
                    movements = [1, 2, 3]
                else:
                    movements = [-3, -2, -1]
            elif contour == 'plateau':
                if position_in_phrase < 0.3:
                    movements = [2, 3, 4]
                else:
                    movements = [-1, 0, 0, 1]
            elif contour == 'valley':
                if position_in_phrase < 0.3:
                    movements = [-2, -3]
                elif position_in_phrase < 0.7:
                    movements = [-1, 0, 1]
                else:
                    movements = [2, 3, 4]
            else:
                movements = [-4, -3, -2, -1, 0, 1, 2, 3, 4]
            
            if movement_bias > 0:
                movements = [m for m in movements if m >= -1]
                if not movements:
                    movements = [1, 2]
            elif movement_bias < 0:
                movements = [m for m in movements if m <= 1]
                if not movements:
                    movements = [-2, -1]
            
            if random.random() < 0.15:
                movements.extend([5, 6, 7, -7, -6, -5])
            
            move = random.choice(movements)
            new_degree = current_degree + move
            
            while new_degree >= len(scale):
                new_degree -= len(scale)
                current_octave += 1
            while new_degree < 0:
                new_degree += len(scale)
                current_octave -= 1
            
            if current_octave > octave_range:
                current_octave = octave_range
                new_degree = min(new_degree, len(scale) - 1)
            if current_octave < -1:
                current_octave = -1
                new_degree = max(new_degree, 0)
            
            current_degree = new_degree
        
        resolution_chance = random.uniform(0.5, 0.9)
        if len(notes) > 0 and random.random() < resolution_chance:
            resolution_degrees = [0, 0, 0, 2, 4]
            resolution_degree = random.choice(resolution_degrees)
            resolution_note = root + scale[resolution_degree] + (current_octave * 12)
            resolution_note = max(12, min(120, int(resolution_note)))
            notes[-1] = resolution_note
        
        return notes


NODE_CLASS_MAPPINGS = {
    "AbsynthVST": AbsynthVSTNode,
    "AbsynthVSTParameterLister": AbsynthVSTParameterListerNode,
    "AbsynthMIDICreator": AbsynthMIDICreatorNode,
    "AbsynthVSTInfoDisplay": AbsynthVSTInfoDisplayNode,
    "AbsynthLLMMIDIGenerator": AbsynthLLMMIDIGeneratorNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AbsynthVST": "Absynth-VST Player v1.1",
    "AbsynthVSTParameterLister": "Absynth-VST Parameter Lister v1.1",
    "AbsynthMIDICreator": "Absynth-VST MIDI Creator v1.1",
    "AbsynthVSTInfoDisplay": "Absynth-VST Info Display v1.1",
    "AbsynthLLMMIDIGenerator": "Absynth-VST LLM MIDI Generator v1.1"
}