"""
Setup script for Serum 2 JSON-based preset generation

Run this once to prepare the init patch template
"""
import os
import sys
import struct

script_dir = os.path.dirname(os.path.abspath(__file__))

print("="*80)
print("SETUP: Serum 2 JSON-based Preset Generation")
print("="*80)

# Check if serum-preset-packager exists
packager_dir = os.path.join(script_dir, 'serum-preset-packager')
if not os.path.exists(packager_dir):
    print(f"\nERROR: serum-preset-packager directory not found!")
    print(f"Expected at: {packager_dir}")
    sys.exit(1)

print(f"\n[OK] Found serum-preset-packager")

# Check if init patch exists
init_patch_paths = [
    os.path.join(script_dir, "presets", "preset_maker", "Serum 2", "Serum 2 Init Patch.vstpreset"),
    os.path.join(script_dir, "presets", "Serum 2", "Serum 2 Init Patch.vstpreset"),
]

init_patch = None
for path in init_patch_paths:
    if os.path.exists(path):
        init_patch = path
        break

if not init_patch:
    print(f"\nERROR: Serum 2 Init Patch.vstpreset not found!")
    print(f"Searched in:")
    for path in init_patch_paths:
        print(f"  - {path}")
    print(f"\nPlease copy the init patch to one of these locations.")
    sys.exit(1)

print(f"[OK] Found init patch: {os.path.basename(init_patch)}")

# Extract Serum data from VST3
print(f"\nExtracting Serum data from VST3...")

with open(init_patch, 'rb') as f:
    data = f.read()

# Find XferJson marker (Component chunk)
xferjson_idx = data.find(b'XferJson\x00')
xferjson2_idx = data.find(b'XferJson\x00', xferjson_idx + 1)

if xferjson_idx < 0:
    print("ERROR: No XferJson marker found!")
    sys.exit(1)

# Extract Component chunk
serum_data = data[xferjson_idx:xferjson2_idx]
print(f"[OK] Extracted {len(serum_data)} bytes of Serum data")

# Save to SerumPreset file
serumpreset_path = os.path.join(packager_dir, 'init_serum_data.SerumPreset')
with open(serumpreset_path, 'wb') as f:
    f.write(serum_data)

print(f"[OK] Saved to: {os.path.basename(serumpreset_path)}")

# Unpack using serum-preset-packager
print(f"\nUnpacking to JSON...")

sys.path.insert(0, packager_dir)
from cli import unpack
import pathlib

json_path = os.path.join(packager_dir, 'init_unpacked.json')
unpack(pathlib.Path(serumpreset_path), pathlib.Path(json_path))

print(f"[OK] Created: {os.path.basename(json_path)}")

# Verify
if os.path.exists(json_path):
    import json
    with open(json_path, 'r') as f:
        data = json.load(f)

    print(f"\n[OK] Verification:")
    print(f"  Components: {len(data.get('data', {}))} ")
    print(f"  Metadata: {data.get('metadata', {}).get('product')}")

    print(f"\n{'='*80}")
    print(f"SUCCESS! Serum 2 JSON preset generation is ready!")
    print(f"{'='*80}")
    print(f"\nYou can now use the LLM Preset Maker with Serum 2!")
    print(f"It will automatically create proper VST3 presets that work in Cubase.")

else:
    print(f"\nERROR: Failed to create init_unpacked.json")
    sys.exit(1)
