"""
Extract the XferJson/Serum data portion from a VST3 preset
so we can unpack it with serum-preset-packager
"""
import struct

vstpreset_file = r"C:\Users\drasko\Documents\VST3 Presets\Xfer Records\Serum 2\Absynth Trance in Motion Arp.vstpreset"
output_file = r"C:\ComfyUI_windows_portable\ComfyUI\custom_nodes\absynth-vst\serum-preset-packager\arp_serum_data.SerumPreset"

# Read VST3 file
with open(vstpreset_file, 'rb') as f:
    data = f.read()

print(f"VST3 file size: {len(data)} bytes")
print(f"Magic: {data[:4]}")

# Find XferJson marker (Component chunk)
xferjson_idx = data.find(b'XferJson\x00')
print(f"XferJson at offset: {xferjson_idx}")

if xferjson_idx < 0:
    print("ERROR: No XferJson marker found!")
    exit(1)

# The Serum data starts at XferJson marker
# We need to find where it ends (before the second XferJson for Controller)
xferjson2_idx = data.find(b'XferJson\x00', xferjson_idx + 1)
print(f"Second XferJson at offset: {xferjson2_idx}")

if xferjson2_idx > 0:
    # Extract Component chunk only
    serum_data = data[xferjson_idx:xferjson2_idx]
else:
    # No second XferJson, take to end
    serum_data = data[xferjson_idx:]

print(f"\nExtracted Serum data: {len(serum_data)} bytes")
print(f"Starts with: {serum_data[:20].hex()}")

# Write to file
with open(output_file, 'wb') as f:
    f.write(serum_data)

print(f"\nSaved to: {output_file}")
print("\nNow try:")
print(f"  python cli.py unpack init_serum_data.SerumPreset init_unpacked.json")
