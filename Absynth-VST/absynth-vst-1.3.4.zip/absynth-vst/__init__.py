print("[Absynth-VST] Loading __init__.py...")

from .absynth_vst import NODE_CLASS_MAPPINGS as ORIGINAL_NODE_CLASS_MAPPINGS, NODE_DISPLAY_NAME_MAPPINGS as ORIGINAL_NODE_DISPLAY_NAME_MAPPINGS, WEB_DIRECTORY
print(f"[Absynth-VST] Loaded original {len(ORIGINAL_NODE_CLASS_MAPPINGS)} nodes from absynth_vst.py")

# Import new nodes
print("[Absynth-VST] Importing new nodes...")
from .midi_analyzer_node import MIDIAnalyzerNode
print("[Absynth-VST] [OK] MIDIAnalyzerNode imported")
from .loop_generator_node import LoopMIDIGeneratorNode
print("[Absynth-VST] [OK] LoopMIDIGeneratorNode imported")
# Bassline generation now handled by Loop Generator - removed separate node
# from .bassline_generator_node import BassliceGeneratorNode
# print("[Absynth-VST] [OK] BassliceGeneratorNode imported")

# Merge node mappings
NODE_CLASS_MAPPINGS = {
    **ORIGINAL_NODE_CLASS_MAPPINGS,
    "AbsynthMIDIAnalyzer": MIDIAnalyzerNode,
    "AbsynthLoopMIDIGenerator": LoopMIDIGeneratorNode,
    # "AbsynthBassliceGenerator": BassliceGeneratorNode  # Removed - use Loop Generator with "bassline" prompt
}

NODE_DISPLAY_NAME_MAPPINGS = {
    **ORIGINAL_NODE_DISPLAY_NAME_MAPPINGS,
    "AbsynthMIDIAnalyzer": "absynth-vst MIDI Analyzer v1.0.0 🎵",
    "AbsynthLoopMIDIGenerator": "absynth-vst Loop MIDI Generator v1.3.4 🔄",
    # "AbsynthBassliceGenerator": "absynth-vst Bassline Generator v1.0.0 🎸"  # Removed
}

print(f"[Absynth-VST] [OK] Registered {len(NODE_CLASS_MAPPINGS)} total nodes:")
print(f"[Absynth-VST]   - Original: {list(ORIGINAL_NODE_CLASS_MAPPINGS.keys())}")
print(f"[Absynth-VST]   - New: ['AbsynthMIDIAnalyzer', 'AbsynthLoopMIDIGenerator']")

__all__ = ['NODE_CLASS_MAPPINGS', 'NODE_DISPLAY_NAME_MAPPINGS', 'WEB_DIRECTORY']

# Register MIDI file upload route
from aiohttp import web
import os
import glob

# Create upload directory for MIDI files
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "midi", "uploaded")
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)

async def upload_midi_file(request):
    """Handle MIDI file uploads from the file picker widget"""
    try:
        reader = await request.multipart()
        field = await reader.next()

        if field.name == 'file':
            filename = field.filename

            # Sanitize filename
            safe_filename = "".join(c for c in filename if c.isalnum() or c in (' ', '.', '_', '-'))
            if not safe_filename.lower().endswith(('.mid', '.midi')):
                safe_filename += '.mid'

            # Save file
            filepath = os.path.join(UPLOAD_DIR, safe_filename)

            with open(filepath, 'wb') as f:
                while True:
                    chunk = await field.read_chunk()
                    if not chunk:
                        break
                    f.write(chunk)

            print(f"[MIDI Upload] File uploaded: {filepath}")

            return web.json_response({
                'status': 'success',
                'path': filepath,
                'filename': safe_filename
            })
        else:
            return web.json_response({
                'status': 'error',
                'message': 'No file field found'
            }, status=400)

    except Exception as e:
        print(f"[MIDI Upload] Error: {str(e)}")
        return web.json_response({
            'status': 'error',
            'message': str(e)
        }, status=500)

async def list_midi_files(request):
    """List MIDI files in a specific folder"""
    try:
        folder = request.query.get('folder', 'midi/uploaded')

        # Build absolute path
        base_dir = os.path.dirname(__file__)
        folder_path = os.path.join(base_dir, folder.replace('/', os.sep))

        # Security check - ensure we stay within the plugin directory
        folder_path = os.path.abspath(folder_path)
        base_dir = os.path.abspath(base_dir)
        if not folder_path.startswith(base_dir):
            return web.json_response({
                'status': 'error',
                'message': 'Invalid folder path'
            }, status=400)

        # Get all MIDI files
        midi_files = []
        if os.path.exists(folder_path):
            for ext in ['*.mid', '*.midi', '*.MID', '*.MIDI']:
                midi_files.extend(glob.glob(os.path.join(folder_path, ext)))

        # Extract just filenames and sort
        filenames = sorted([os.path.basename(f) for f in midi_files])

        print(f"[MIDI List] Found {len(filenames)} files in {folder}")

        return web.json_response({
            'status': 'success',
            'files': filenames,
            'count': len(filenames)
        })

    except Exception as e:
        print(f"[MIDI List] Error: {str(e)}")
        return web.json_response({
            'status': 'error',
            'message': str(e)
        }, status=500)

# Register routes with ComfyUI (delayed to avoid import errors)
def register_routes():
    try:
        from server import PromptServer

        @PromptServer.instance.routes.post('/absynth-vst/upload-midi')
        async def upload_midi_route(request):
            return await upload_midi_file(request)

        @PromptServer.instance.routes.get('/absynth-vst/list-midi-files')
        async def list_midi_route(request):
            return await list_midi_files(request)

        print("[Absynth-VST] MIDI routes registered:")
        print("[Absynth-VST]   - POST /absynth-vst/upload-midi")
        print("[Absynth-VST]   - GET  /absynth-vst/list-midi-files")
    except Exception as e:
        print(f"[Absynth-VST] Could not register routes: {e}")

# Try to register routes, but don't fail if it doesn't work during import
try:
    register_routes()
except:
    pass  # Will retry later when server is available