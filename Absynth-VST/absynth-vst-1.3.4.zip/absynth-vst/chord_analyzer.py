"""
Chord Analyzer for MIDI Files
Detects chords, progressions, and provides music theory analysis
"""

import mido
from collections import defaultdict
from typing import List, Dict, Tuple, Optional
import math


class ChordAnalyzer:
    """Analyzes MIDI files to detect chords and progressions"""

    # Chord templates (intervals from root)
    CHORD_TEMPLATES = {
        'major': [0, 4, 7],
        'minor': [0, 3, 7],
        'diminished': [0, 3, 6],
        'augmented': [0, 4, 8],
        'sus2': [0, 2, 7],
        'sus4': [0, 5, 7],
        # 7th chords
        'major7': [0, 4, 7, 11],
        'minor7': [0, 3, 7, 10],
        'dominant7': [0, 4, 7, 10],
        'diminished7': [0, 3, 6, 9],
        'minor7b5': [0, 3, 6, 10],  # half-diminished
        # 6th chords
        'major6': [0, 4, 7, 9],
        'minor6': [0, 3, 7, 9],
        # 9th chords (extended)
        'major9': [0, 4, 7, 11, 2],  # maj7 + 9th
        'minor9': [0, 3, 7, 10, 2],  # min7 + 9th
        'dominant9': [0, 4, 7, 10, 2],  # dom7 + 9th
        'dominant7b9': [0, 4, 7, 10, 1],  # dom7 + b9th
        'dominant7sharp9': [0, 4, 7, 10, 3],  # dom7 + #9th
        # add9 chords (triad + 9th, no 7th)
        'add9': [0, 4, 7, 2],
        'minoradd9': [0, 3, 7, 2],
        # 11th chords
        'dominant11': [0, 4, 7, 10, 2, 5],  # dom9 + 11th
        'minor11': [0, 3, 7, 10, 2, 5],  # min9 + 11th
        # 13th chords
        'dominant13': [0, 4, 7, 10, 2, 5, 9],  # dom11 + 13th
    }

    # Note names
    NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']

    # Major and minor scale intervals
    MAJOR_SCALE = [0, 2, 4, 5, 7, 9, 11]
    MINOR_SCALE = [0, 2, 3, 5, 7, 8, 10]

    # Diatonic chord qualities in major and minor keys
    MAJOR_KEY_CHORDS = ['major', 'minor', 'minor', 'major', 'major', 'minor', 'diminished']
    MINOR_KEY_CHORDS = ['minor', 'diminished', 'major', 'minor', 'minor', 'major', 'major']

    ROMAN_NUMERALS = {
        'major': ['I', 'ii', 'iii', 'IV', 'V', 'vi', 'vii°'],
        'minor': ['i', 'ii°', 'III', 'iv', 'v', 'VI', 'VII']
    }

    def __init__(self, window_ms: int = 50):
        """
        Initialize chord analyzer

        Args:
            window_ms: Time window in milliseconds to group notes as simultaneous
        """
        self.window_ms = window_ms

    def analyze_midi_file(self, midi_path: str, override_bpm: Optional[float] = None) -> Dict:
        """
        Analyze a MIDI file and extract chord progression

        Args:
            midi_path: Path to MIDI file
            override_bpm: Optional BPM to override the MIDI file's tempo

        Returns:
            Dictionary with key, bpm, and progression information
        """
        # Parse MIDI file
        midi = mido.MidiFile(midi_path)

        # Get tempo information
        bpm = self._get_bpm(midi)
        if override_bpm:
            bpm = override_bpm

        # Extract note events with timing
        note_events = self._extract_note_events(midi, bpm)

        # Group notes into chords
        chords = self._group_into_chords(note_events)

        # Detect key first (needed for proper enharmonic spelling)
        key_info = self._detect_key(note_events)

        # Identify each chord with key context
        identified_chords = self._identify_chords(chords, key_info)

        # Add Roman numeral analysis
        progression = self._add_roman_numerals(identified_chords, key_info)

        # Calculate both content duration (where notes end) and last_note_start (where last note begins)
        if progression:
            # Where the last chord ends (including sustain)
            total_duration = max([c['time'] + c['duration'] for c in progression])
            # Where the last chord STARTS (for bar calculation)
            last_note_start = max([c['time'] for c in progression])
        else:
            total_duration = 0
            last_note_start = 0

        return {
            'key': key_info['key_name'],
            'is_minor': key_info['is_minor'],
            'bpm': bpm,
            'total_duration': total_duration,
            'last_note_start': last_note_start,  # NEW: Where last chord/note starts
            'progression': progression,
            'scale_notes': self._get_scale_notes(key_info['root'], key_info['is_minor'])
        }

    def _get_bpm(self, midi: mido.MidiFile) -> float:
        """Extract BPM from MIDI file"""
        for track in midi.tracks:
            for msg in track:
                if msg.type == 'set_tempo':
                    return mido.tempo2bpm(msg.tempo)
        return 120.0  # Default BPM

    def _extract_note_events(self, midi: mido.MidiFile, bpm: float) -> List[Dict]:
        """Extract note events with timing information"""
        events = []
        active_notes = {}
        current_time = 0.0

        ticks_per_beat = midi.ticks_per_beat
        seconds_per_tick = 60.0 / (bpm * ticks_per_beat)

        for track in midi.tracks:
            track_time = 0.0
            for msg in track:
                track_time += msg.time * seconds_per_tick

                if msg.type == 'note_on' and msg.velocity > 0:
                    note_key = (msg.note, msg.channel)
                    active_notes[note_key] = {
                        'note': msg.note,
                        'velocity': msg.velocity,
                        'start_time': track_time,
                        'channel': msg.channel
                    }
                elif msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0):
                    note_key = (msg.note, msg.channel)
                    if note_key in active_notes:
                        note_info = active_notes[note_key]
                        events.append({
                            'note': note_info['note'],
                            'velocity': note_info['velocity'],
                            'start_time': note_info['start_time'],
                            'end_time': track_time,
                            'duration': track_time - note_info['start_time'],
                            'channel': note_info['channel']
                        })
                        del active_notes[note_key]

        # Sort by start time
        events.sort(key=lambda x: x['start_time'])
        return events

    def _group_into_chords(self, note_events: List[Dict]) -> List[Dict]:
        """Group notes by analyzing what's sounding at each chord change point"""
        if not note_events:
            return []

        # Find all unique start times (chord change points)
        start_times = sorted(set([event['start_time'] for event in note_events]))

        chords = []

        # At each chord change point, collect ALL notes that are sounding
        for start_time in start_times:
            # Find all notes that are sounding at this time
            # A note is sounding if: start_time <= chord_time < end_time
            sounding_notes = []
            for event in note_events:
                # Note is sounding if it started before/at this time AND hasn't ended yet
                if event['start_time'] <= start_time < event['end_time']:
                    sounding_notes.append(event)

            if sounding_notes:
                chords.append(self._create_chord_dict(sounding_notes, start_time))

        return chords

    def _create_chord_dict(self, notes: List[Dict], start_time: float) -> Dict:
        """Create a chord dictionary from a list of note events"""
        # Get unique pitch classes (notes mod 12)
        unique_notes = sorted(set([n['note'] for n in notes]))

        # Calculate average duration
        avg_duration = sum([n['duration'] for n in notes]) / len(notes)

        return {
            'time': start_time,
            'duration': avg_duration,
            'notes': unique_notes,
            'pitch_classes': sorted(set([n % 12 for n in unique_notes])),
            'velocities': [n['velocity'] for n in notes]
        }

    def _identify_chords(self, chords: List[Dict], key_info: Dict) -> List[Dict]:
        """Identify chord types for each chord"""
        identified = []

        # Determine if this is a sharp key or flat key
        is_sharp_key = self._is_sharp_key(key_info['root'], key_info['is_minor'])

        for chord in chords:
            pitch_classes = chord['pitch_classes']

            # Try to identify the chord
            chord_info = self._identify_chord_type(pitch_classes)

            # Apply enharmonic respelling based on key signature
            root_name = self._respell_enharmonic(chord_info['root'], is_sharp_key)

            identified.append({
                'time': chord['time'],
                'duration': chord['duration'],
                'notes': chord['notes'],
                'pitch_classes': pitch_classes,
                'root': chord_info['root'],
                'root_name': root_name,
                'type': chord_info['type'],
                'chord_name': f"{root_name}{chord_info['type_suffix']}",
                'intervals': chord_info['intervals']
            })

        return identified

    def _is_sharp_key(self, root: int, is_minor: bool) -> bool:
        """
        Determine if a key uses sharps or flats based on music theory

        Sharp keys (major): G, D, A, E, B, F#, C#
        Sharp keys (minor): Em, Bm, F#m, C#m, G#m, D#m, A#m
        Flat keys (major): F, Bb, Eb, Ab, Db, Gb, Cb
        Flat keys (minor): Dm, Gm, Cm, Fm, Bbm, Ebm, Abm
        C major/A minor: use sharps by convention
        """
        if is_minor:
            # Minor keys: Em(4), Bm(11), F#m(6), C#m(1), G#m(8), D#m(3), A#m(10) = sharps
            # Dm(2), Gm(7), Cm(0), Fm(5), Bbm(10), Ebm(3), Abm(8) = flats
            sharp_minor_roots = {4, 11, 6, 1, 8, 3, 10}  # E, B, F#, C#, G#, D#, A#
            flat_minor_roots = {2, 7, 0, 5}  # D, G, C, F

            if root in sharp_minor_roots:
                return True
            elif root in flat_minor_roots:
                return False
            else:
                return True  # Default to sharps
        else:
            # Major keys: G(7), D(2), A(9), E(4), B(11), F#(6), C#(1) = sharps
            # F(5), Bb(10), Eb(3), Ab(8), Db(1), Gb(6) = flats
            sharp_major_roots = {7, 2, 9, 4, 11, 6, 1, 0}  # G, D, A, E, B, F#, C#, C
            flat_major_roots = {5, 10, 3, 8}  # F, Bb, Eb, Ab

            if root in sharp_major_roots:
                return True
            elif root in flat_major_roots:
                return False
            else:
                return True  # Default to sharps

    def _respell_enharmonic(self, pitch_class: int, is_sharp_key: bool) -> str:
        """
        Respell accidentals based on key signature

        Sharp keys: use sharps (C#, D#, F#, G#, A#)
        Flat keys: use flats (Db, Eb, Gb, Ab, Bb)
        """
        # Natural notes - always the same
        if pitch_class in [0, 2, 4, 5, 7, 9, 11]:  # C, D, E, F, G, A, B
            return self.NOTE_NAMES[pitch_class]

        # Accidentals - depend on key signature
        if is_sharp_key:
            # Use sharp names
            sharp_names = {
                1: 'C#',
                3: 'D#',
                6: 'F#',
                8: 'G#',
                10: 'A#'
            }
            return sharp_names.get(pitch_class, self.NOTE_NAMES[pitch_class])
        else:
            # Use flat names
            flat_names = {
                1: 'Db',
                3: 'Eb',
                6: 'Gb',
                8: 'Ab',
                10: 'Bb'
            }
            return flat_names.get(pitch_class, self.NOTE_NAMES[pitch_class])

    def _identify_chord_type(self, pitch_classes: List[int]) -> Dict:
        """Identify the type of a chord from its pitch classes"""
        if len(pitch_classes) < 2:
            # Single note or empty
            root = pitch_classes[0] if pitch_classes else 0
            return {
                'root': root,
                'type': 'single',
                'type_suffix': '',
                'intervals': [0]
            }

        best_match = None
        best_score = -1

        # Try each note as potential root
        for root in pitch_classes:
            # Calculate intervals from this root
            intervals = sorted([(pc - root) % 12 for pc in pitch_classes])

            # Try to match against templates
            for chord_type, template in self.CHORD_TEMPLATES.items():
                # Check if the intervals match (allowing extra notes)
                template_set = set(template)
                intervals_set = set(intervals)

                # How many template notes are present?
                matches = len(template_set & intervals_set)

                # Penalize extra notes
                extras = len(intervals_set - template_set)
                score = matches - (extras * 0.5)

                # Prefer exact matches
                if intervals_set == template_set:
                    score += 10

                if score > best_score:
                    best_score = score
                    best_match = {
                        'root': root,
                        'type': chord_type,
                        'intervals': intervals
                    }

        if best_match is None:
            # Fallback for unidentified chords
            best_match = {
                'root': pitch_classes[0],
                'type': 'unknown',
                'intervals': [(pc - pitch_classes[0]) % 12 for pc in pitch_classes]
            }

        # Post-process: Convert add9 to dominant9 (add9 is just dominant9 with omitted 7th)
        # In real-world voicings, 9th chords often omit the 7th
        if best_match['type'] == 'add9':
            intervals_set = set(best_match['intervals'])
            # Check if this is root, 3rd, 5th, 9th (major add9 pattern)
            if intervals_set == {0, 2, 4, 7}:
                # This is a dominant 9th voicing with omitted 7th
                best_match['type'] = 'dominant9'

        elif best_match['type'] == 'minoradd9':
            intervals_set = set(best_match['intervals'])
            # Check if this is root, m3rd, 5th, 9th (minor add9 pattern)
            if intervals_set == {0, 2, 3, 7}:
                # This is a minor 9th voicing with omitted 7th
                best_match['type'] = 'minor9'

        # Create suffix for chord name
        type_suffix = self._get_chord_suffix(best_match['type'])
        best_match['type_suffix'] = type_suffix

        return best_match

    def _get_chord_suffix(self, chord_type: str) -> str:
        """Get the suffix for a chord name"""
        suffixes = {
            'major': '',
            'minor': 'm',
            'diminished': 'dim',
            'augmented': 'aug',
            'sus2': 'sus2',
            'sus4': 'sus4',
            # 7th chords
            'major7': 'maj7',
            'minor7': 'm7',
            'dominant7': '7',
            'diminished7': 'dim7',
            'minor7b5': 'm7b5',
            # 6th chords
            'major6': '6',
            'minor6': 'm6',
            # 9th chords
            'major9': 'maj9',
            'minor9': 'm9',
            'dominant9': '9',
            'dominant7b9': '7b9',
            'dominant7sharp9': '7#9',
            'add9': 'add9',
            'minoradd9': 'madd9',
            # 11th chords
            'dominant11': '11',
            'minor11': 'm11',
            # 13th chords
            'dominant13': '13',
            # special
            'single': ' (single note)',
            'unknown': ' (?)'
        }
        return suffixes.get(chord_type, '')

    def _detect_key(self, note_events: List[Dict]) -> Dict:
        """Detect the key of the piece using Krumhansl-Schmuckler algorithm"""
        if not note_events:
            return {'root': 0, 'is_minor': False, 'key_name': 'C major'}

        # Count pitch class occurrences
        pitch_class_counts = [0] * 12
        for event in note_events:
            pc = event['note'] % 12
            # Weight by duration
            pitch_class_counts[pc] += event['duration']

        # Normalize
        total = sum(pitch_class_counts)
        if total > 0:
            pitch_class_dist = [c / total for c in pitch_class_counts]
        else:
            pitch_class_dist = pitch_class_counts

        # Krumhansl-Schmuckler key profiles
        major_profile = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88]
        minor_profile = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]

        best_correlation = -1
        best_key = {'root': 0, 'is_minor': False}

        # Try all 24 keys (12 major + 12 minor)
        for root in range(12):
            # Rotate the pitch class distribution
            rotated = pitch_class_dist[root:] + pitch_class_dist[:root]

            # Test major
            corr = self._correlation(rotated, major_profile)
            if corr > best_correlation:
                best_correlation = corr
                best_key = {'root': root, 'is_minor': False}

            # Test minor
            corr = self._correlation(rotated, minor_profile)
            if corr > best_correlation:
                best_correlation = corr
                best_key = {'root': root, 'is_minor': True}

        # Create key name with proper enharmonic spelling
        is_sharp_key = self._is_sharp_key(best_key['root'], best_key['is_minor'])
        root_name = self._respell_enharmonic(best_key['root'], is_sharp_key)
        key_name = f"{root_name} {'minor' if best_key['is_minor'] else 'major'}"
        best_key['key_name'] = key_name

        return best_key

    def _correlation(self, x: List[float], y: List[float]) -> float:
        """Calculate Pearson correlation coefficient"""
        n = len(x)
        mean_x = sum(x) / n
        mean_y = sum(y) / n

        numerator = sum([(x[i] - mean_x) * (y[i] - mean_y) for i in range(n)])

        sum_sq_x = sum([(x[i] - mean_x) ** 2 for i in range(n)])
        sum_sq_y = sum([(y[i] - mean_y) ** 2 for i in range(n)])

        denominator = math.sqrt(sum_sq_x * sum_sq_y)

        if denominator == 0:
            return 0

        return numerator / denominator

    def _add_roman_numerals(self, chords: List[Dict], key_info: Dict) -> List[Dict]:
        """Add Roman numeral analysis to chords"""
        key_root = key_info['root']
        is_minor = key_info['is_minor']
        scale = self.MINOR_SCALE if is_minor else self.MAJOR_SCALE

        for chord in chords:
            chord_root = chord['root']

            # Find scale degree
            degree = None
            for i, interval in enumerate(scale):
                if (key_root + interval) % 12 == chord_root:
                    degree = i
                    break

            if degree is not None:
                # Get Roman numeral
                roman = self.ROMAN_NUMERALS['minor' if is_minor else 'major'][degree]

                # Modify if chord quality doesn't match expected
                expected_quality = self.MINOR_KEY_CHORDS[degree] if is_minor else self.MAJOR_KEY_CHORDS[degree]
                if chord['type'] != expected_quality and chord['type'] in ['major', 'minor', 'diminished']:
                    # Add quality indicator if it differs
                    if chord['type'] == 'major' and expected_quality == 'minor':
                        roman = roman.upper()  # Borrowed chord
                    elif chord['type'] == 'minor' and expected_quality == 'major':
                        roman = roman.lower()

                chord['roman'] = roman
                chord['scale_degree'] = degree + 1
            else:
                # Non-diatonic chord
                chord['roman'] = '?'
                chord['scale_degree'] = None

        return chords

    def _get_scale_notes(self, root: int, is_minor: bool) -> List[int]:
        """Get the notes in a scale"""
        scale = self.MINOR_SCALE if is_minor else self.MAJOR_SCALE
        return [(root + interval) % 12 for interval in scale]

    def format_analysis(self, analysis: Dict) -> str:
        """Format analysis as a human-readable string"""
        lines = []
        lines.append(f"Key: {analysis['key']}")
        lines.append(f"BPM: {analysis['bpm']:.1f}")
        lines.append(f"Duration: {analysis['total_duration']:.2f}s")
        lines.append(f"\nScale notes: {', '.join([self.NOTE_NAMES[n] for n in analysis['scale_notes']])}")
        lines.append(f"\nChord Progression:")
        lines.append("-" * 80)

        for i, chord in enumerate(analysis['progression']):
            bar = int(chord['time'] / (240.0 / analysis['bpm'])) + 1  # Assuming 4/4 time
            beat = (chord['time'] / (60.0 / analysis['bpm'])) % 4 + 1

            lines.append(f"Bar {bar}, Beat {beat:.1f} ({chord['time']:.2f}s - {chord['time'] + chord['duration']:.2f}s):")
            lines.append(f"  Chord: {chord['chord_name']} ({chord['roman']})")
            lines.append(f"  Notes: {', '.join([self.NOTE_NAMES[n % 12] for n in chord['notes']])}")
            lines.append(f"  Intervals: {chord['intervals']}")
            lines.append("")

        return "\n".join(lines)


# Test function
if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        midi_path = sys.argv[1]
        analyzer = ChordAnalyzer(window_ms=50)
        analysis = analyzer.analyze_midi_file(midi_path)
        print(analyzer.format_analysis(analysis))
    else:
        print("Usage: python chord_analyzer.py <midi_file_path>")
