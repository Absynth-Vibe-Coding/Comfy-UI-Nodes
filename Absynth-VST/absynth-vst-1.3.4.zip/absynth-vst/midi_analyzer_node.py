"""
MIDI Analyzer Node
Analyzes MIDI files to extract: Scale, Chords, BPM, Bars, Duration
With integrated file browser
"""

import os
import mido
import json


class MIDIAnalyzerNode:
    """Analyze MIDI files to detect scale, chords, BPM, and bars"""

    VERSION = "1.0.0"
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _upload_folder = os.path.join(_script_dir, "midi", "uploaded")

    if not os.path.exists(_upload_folder):
        os.makedirs(_upload_folder)

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "midi_file_path": ("STRING", {
                    "default": "",
                    "multiline": False,
                    "dynamicPrompts": False
                })
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "INT", "INT", "FLOAT", "STRING")
    RETURN_NAMES = ("scale", "chords_json", "bpm", "bars", "duration", "analysis_text")
    FUNCTION = "analyze_midi"
    CATEGORY = "absynth-vst"

    def analyze_midi(self, midi_file_path):
        """Analyze MIDI file and extract all relevant info"""

        print(f"")
        print(f"╔═══════════════════════════════════════╗")
        print(f"║  MIDI ANALYZER v{self.VERSION}            ║")
        print(f"╚═══════════════════════════════════════╝")
        print(f"")
        print(f"[MIDI Analyzer] 🐛 DEBUG: Received path: {midi_file_path}")
        print(f"[MIDI Analyzer] 🐛 DEBUG: File exists: {os.path.exists(midi_file_path) if midi_file_path else False}")
        print(f"[MIDI Analyzer] 🐛 DEBUG: Basename: {os.path.basename(midi_file_path) if midi_file_path else 'EMPTY'}")

        # Validate input
        if not midi_file_path or not os.path.exists(midi_file_path):
            return ("", "{}", 0, 0, 0.0, "ERROR: MIDI file not found")

        try:
            from .chord_analyzer import ChordAnalyzer

            print(f"[MIDI Analyzer] Analyzing: {os.path.basename(midi_file_path)}")
            print(f"[MIDI Analyzer] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

            # Analyze with chord analyzer
            analyzer = ChordAnalyzer(window_ms=50)
            analysis = analyzer.analyze_midi_file(midi_file_path)

            # Extract basic info
            key = analysis.get('key', 'C major')
            bpm = int(analysis.get('bpm', 128))
            duration = analysis.get('total_duration', 0)
            progression = analysis.get('progression', [])
            scale_notes = analysis.get('scale_notes', [0, 2, 4, 5, 7, 9, 11])

            # Calculate ACTUAL bars from total duration
            midi = mido.MidiFile(midi_file_path)

            # Use the TOTAL file duration (not just last note)
            # This gives us the full loop length
            total_duration_seconds = duration

            # Calculate bars from total duration
            beats_per_second = bpm / 60.0
            total_beats = total_duration_seconds * beats_per_second
            bars_with_content = int(total_beats / 4)

            # Round up if we're very close to next bar
            if (total_beats % 4) > 3.5:
                bars_with_content += 1

            print(f"[MIDI Analyzer] DEBUG: Duration={total_duration_seconds:.2f}s, Beats={total_beats:.1f}, Bars={bars_with_content}")

            # Build scale string
            note_names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
            scale_str = ' '.join([note_names[n % 12] for n in scale_notes])

            # Build chords JSON
            chords_data = {
                'key': key,
                'scale_notes': scale_notes,
                'progression': progression
            }
            chords_json = json.dumps(chords_data, indent=2)

            # Build chord progression summary
            chord_names_summary = ""
            if progression:
                chord_names = [chord.get('chord_name', 'Unknown') for chord in progression]
                chord_names_summary = " → ".join(chord_names)

            # Build analysis text - SIMPLE AND CLEAN
            analysis_text = f"""
╔══════════════════════════════════════════════╗
║   MIDI ANALYSIS COMPLETE ✓                   ║
╚══════════════════════════════════════════════╝

📄 File: {os.path.basename(midi_file_path)}

🎵 Chord Progression:
  {chord_names_summary if chord_names_summary else 'No chords detected'}

⏱️  Timing:
  BPM: {bpm}
  Duration: {duration:.2f}s
  Bars: {bars_with_content}

🎹 Ready for Loop Generation!
"""

            print(f"[MIDI Analyzer] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print(f"[MIDI Analyzer] ✓ Key: {key}")
            print(f"[MIDI Analyzer] ✓ BPM: {bpm}")
            print(f"[MIDI Analyzer] ✓ Bars: {bars_with_content}")
            print(f"[MIDI Analyzer] ✓ Duration: {duration:.2f}s")
            print(f"[MIDI Analyzer] ✓ Chords: {len(progression)}")
            print(f"[MIDI Analyzer] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print(f"")

            return (
                scale_str,
                chords_json,
                bpm,
                bars_with_content,
                duration,
                analysis_text
            )

        except Exception as e:
            error_msg = f"ERROR: Failed to analyze MIDI\n{str(e)}"
            print(f"[MIDI Analyzer] {error_msg}")
            import traceback
            traceback.print_exc()
            return ("", "{}", 0, 0, 0.0, error_msg)

    @classmethod
    def IS_CHANGED(cls, midi_file_path):
        # Force re-execution when file path changes
        return midi_file_path
