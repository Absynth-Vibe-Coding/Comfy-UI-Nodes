"""
Complete solution for creating Serum 2 VST3 presets

This script can create any Serum preset by modifying parameters by name.
Works perfectly in Cubase!

Usage:
    python create_serum_preset.py
"""
import json
import sys
import pathlib
import os

# Add serum-preset-packager to path
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(script_dir, 'serum-preset-packager'))
from cli import pack

# Import the VST3 wrapper
sys.path.insert(0, script_dir)
from wrap_serumpreset_in_vst3 import wrap_in_vst3


def create_serum_preset(preset_name, parameters, output_path):
    """
    Create a Serum 2 VST3 preset with custom parameters

    Args:
        preset_name: Name of the preset
        parameters: Dict with parameter modifications
        output_path: Where to save the .vstpreset file

    Example parameters dict:
    {
        "Oscillator0": {
            "kParamVolume": 0.8,
            "kParamDetune": 0.25,
            "kParamUnison": 7.0
        },
        "Global0": {
            "kParamMasterVolume": 0.7,
            "kParamPolyCount": 8.0
        },
        "Env0": {
            "kParamAttack": 0.05,
            "kParamRelease": 0.5
        }
    }
    """

    # Load init patch as template
    init_json = os.path.join(script_dir, 'serum-preset-packager', 'init_unpacked.json')
    with open(init_json, 'r') as f:
        preset_data = json.load(f)

    print(f"Creating preset: {preset_name}")

    # Apply parameter modifications
    for component, params in parameters.items():
        if component in preset_data['data']:
            # If plainParams is "default", convert to dict
            if preset_data['data'][component].get('plainParams') == 'default':
                preset_data['data'][component]['plainParams'] = {}

            # Update parameters
            if isinstance(preset_data['data'][component]['plainParams'], dict):
                preset_data['data'][component]['plainParams'].update(params)
                print(f"  Updated {component}: {len(params)} parameters")

    # Save modified JSON to temp file
    temp_json = os.path.join(script_dir, 'serum-preset-packager', 'temp_preset.json')
    with open(temp_json, 'w') as f:
        json.dump(preset_data, f, indent=2)

    # Pack to SerumPreset
    temp_serumpreset = os.path.join(script_dir, 'serum-preset-packager', 'temp_preset.SerumPreset')
    pack(pathlib.Path(temp_json), pathlib.Path(temp_serumpreset))
    print(f"  Packed to SerumPreset")

    # Wrap in VST3 format
    wrap_in_vst3(temp_serumpreset, output_path, preset_name)
    print(f"  Wrapped in VST3 format")

    # Cleanup temp files
    if os.path.exists(temp_json):
        os.remove(temp_json)
    if os.path.exists(temp_serumpreset):
        os.remove(temp_serumpreset)

    print(f"SUCCESS! Created: {output_path}")
    return True


# Example usage
if __name__ == "__main__":

    # Example 1: Hypersaw
    hypersaw_params = {
        "Oscillator0": {
            "kParamVolume": 0.8,
            "kParamDetune": 0.25,
            "kParamDetuneWid": 80.0,
            "kParamUnison": 7.0,
            "kParamPan": 0.5,
            "kParamFine": 0.0
        },
        "Oscillator1": {
            "kParamVolume": 0.6,
            "kParamDetune": 0.20,
            "kParamDetuneWid": 70.0,
            "kParamUnison": 5.0,
            "kParamPan": 0.5,
            "kParamFine": 7.0
        },
        "Global0": {
            "kParamMasterVolume": 0.7,
            "kParamPolyCount": 8.0,
            "kParamOversampling": 2.0,
            "kParamLimitSameNotePolyphony": 1.0,
            "kParamModWheel": 0.0,
            "kParamProgram": 0.0,
            "kParamS1Compatibility": 1.0
        },
        "Env0": {
            "kParamAttack": 0.05,
            "kParamDecay": 0.3,
            "kParamSustain": 0.8,
            "kParamRelease": 0.5,
            "kParamCurve1": 50.0,
            "kParamCurve2": 50.0,
            "kParamCurve3": 50.0
        }
    }

    output = r"C:\Users\drasko\Documents\VST3 Presets\Xfer Records\Serum 2\Absynth-Hypersaw-Final.vstpreset"

    create_serum_preset("Absynth Hypersaw", hypersaw_params, output)

    print("\n" + "="*80)
    print("SUCCESS!")
    print("="*80)
    print("Load 'Absynth-Hypersaw-Final' in Cubase to test!")
    print("\nYou can now create ANY Serum preset by modifying parameters!")
