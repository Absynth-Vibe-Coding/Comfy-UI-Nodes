"""
Wrap a .SerumPreset file in VST3 format

Takes the Component data from .SerumPreset and wraps it in proper VST3 structure
"""
import struct
import os

def wrap_in_vst3(serumpreset_file, output_vstpreset, preset_name="Hypersaw", use_arp_controller=False):
    """
    Wrap SerumPreset data in VST3 format

    Args:
        serumpreset_file: Path to .SerumPreset file (component data)
        output_vstpreset: Path to output .vstpreset file
        preset_name: Name of the preset
        use_arp_controller: If True, use controller with arpeggiator enabled
    """

    # Read the SerumPreset file (this IS the Component chunk XferJson data)
    with open(serumpreset_file, 'rb') as f:
        component_xferjson = f.read()

    print(f"SerumPreset size: {len(component_xferjson)} bytes")

    # For Controller chunk, use either arp-enabled or default
    script_dir = os.path.dirname(os.path.abspath(__file__))

    if use_arp_controller:
        # Use the controller with arpeggiator enabled
        # Try the user's working controller first (from arp-enabled-absynth.vstpreset)
        arp_controller_path = os.path.join(script_dir, "serum-preset-packager", "your_arp_controller_FULL.bin")
        if not os.path.exists(arp_controller_path):
            # Fallback to template controller
            arp_controller_path = os.path.join(script_dir, "serum-preset-packager", "arp_controller_with_settings.bin")

        if os.path.exists(arp_controller_path):
            print(f"Using arpeggiator-enabled controller from: {arp_controller_path}")
            with open(arp_controller_path, 'rb') as f:
                controller_xferjson = f.read()
        else:
            print(f"WARNING: Arp controller not found at {arp_controller_path}, using default")
            use_arp_controller = False

    if not use_arp_controller:
        # Use default controller from init patch
        # Try multiple possible locations
        init_patch_paths = [
            os.path.join(script_dir, "presets", "preset_maker", "Serum 2", "Serum 2 Init Patch.vstpreset"),
            os.path.join(script_dir, "presets", "Serum 2", "Serum 2 Init Patch.vstpreset"),
            r"C:\ComfyUI_windows_portable\ComfyUI\custom_nodes\absynth-vst\presets\preset_maker\Serum 2\Serum 2 Init Patch.vstpreset",
        ]

        init_vst3 = None
        for path in init_patch_paths:
            if os.path.exists(path):
                init_vst3 = path
                break

        if not init_vst3:
            raise FileNotFoundError(f"Could not find Serum 2 Init Patch.vstpreset. Searched:\n" + "\n".join(f"  - {p}" for p in init_patch_paths))

        with open(init_vst3, 'rb') as f:
            init_data = f.read()

        # Find the second XferJson (controller)
        xfer1 = init_data.find(b'XferJson\x00')
        xfer2 = init_data.find(b'XferJson\x00', xfer1 + 1)

        # Find the XML chunk after controller
        xml_start = init_data.find(b'<?xml')

        # Extract controller chunk
        controller_xferjson = init_data[xfer2:xml_start]

    print(f"Controller chunk size: {len(controller_xferjson)} bytes")

    # Build VST3 file
    output = bytearray()

    # Header
    output.extend(b'VST3')  # Magic
    output.extend(struct.pack('<I', 1))  # Version

    # Class ID (ASCII hex string, 34 bytes with padding)
    classid = "56534558667350736572756D20320000"
    classid_section = bytearray(classid.encode('ascii'))
    while len(classid_section) < 32:
        classid_section.append(0)
    output.extend(classid_section)

    # We'll fill in the List offset later (bytes 40-48)
    list_offset_pos = len(output)
    output.extend(struct.pack('<Q', 0))  # Placeholder

    # Component chunk offset
    comp_offset = len(output)
    output.extend(component_xferjson)

    # Controller chunk offset
    ctrl_offset = len(output)
    output.extend(controller_xferjson)

    # Info chunk (XML metadata) - match exact format of valid presets
    info_offset = len(output)
    output.extend(b'Comp')  # Chunk ID
    # Use exact XML format from valid Serum presets (tabs, utf-8 lowercase, type/flags attributes)
    info_xml = b'''<?xml version="1.0" encoding="utf-8"?>
<MetaInfo>
\t<Attribute id="MediaType" value="VstPreset" type="string" flags="writeProtected"/>
\t<Attribute id="PlugInCategory" value="Instrument|Synth" type="string" flags="writeProtected"/>
\t<Attribute id="PlugInName" value="Serum 2" type="string" flags="writeProtected"/>
\t<Attribute id="PlugInVendor" value="Xfer Records" type="string" flags="writeProtected"/>
</MetaInfo>'''
    output.extend(struct.pack('<Q', len(info_xml)))
    output.extend(info_xml)

    # List chunk (directory)
    list_offset = len(output)
    output.extend(b'List')  # Chunk ID
    output.extend(struct.pack('<I', 3))  # Number of chunks

    # Comp entry
    output.extend(b'Comp')
    output.extend(struct.pack('<Q', comp_offset))
    output.extend(struct.pack('<Q', ctrl_offset - comp_offset))

    # Cont entry
    output.extend(b'Cont')
    output.extend(struct.pack('<Q', ctrl_offset))
    output.extend(struct.pack('<Q', info_offset - ctrl_offset))

    # Info entry
    output.extend(b'Info')
    output.extend(struct.pack('<Q', info_offset))
    output.extend(struct.pack('<Q', list_offset - info_offset))

    # Update List offset in header
    struct.pack_into('<Q', output, list_offset_pos, list_offset)

    # Write output
    with open(output_vstpreset, 'wb') as f:
        f.write(output)

    print(f"\nCreated VST3 preset: {output_vstpreset}")
    print(f"Total size: {len(output)} bytes")
    print(f"  Component offset: {comp_offset}, size: {ctrl_offset - comp_offset}")
    print(f"  Controller offset: {ctrl_offset}, size: {info_offset - ctrl_offset}")
    print(f"  Info offset: {info_offset}, size: {list_offset - info_offset}")
    print(f"  List offset: {list_offset}, size: {len(output) - list_offset}")


if __name__ == "__main__":
    serumpreset = r"C:\ComfyUI_windows_portable\ComfyUI\custom_nodes\absynth-vst\serum-preset-packager\Hypersaw.SerumPreset"
    output = r"C:\Users\drasko\Documents\VST3 Presets\Xfer Records\Serum 2\Absynth2.vstpreset"

    wrap_in_vst3(serumpreset, output, "Absynth Hypersaw")

    print("\n" + "="*80)
    print("TEST THIS IN CUBASE!")
    print("="*80)
    print("If this works, we've solved the problem!")
    print("We can now create VST3 presets with actual parameter values!")
