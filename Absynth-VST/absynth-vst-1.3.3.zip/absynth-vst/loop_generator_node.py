"""
Loop MIDI Generator Node
Generates perfect loop MIDIs based on analyzer output
"""

import os
import random
import time
import json
import mido


class LoopMIDIGeneratorNode:
    """Generate perfect loop MIDIs matching exact bars and BPM"""

    VERSION = "1.3.3"
    NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _output_folder = os.path.join(_script_dir, "midi", "loops")

    if not os.path.exists(_output_folder):
        os.makedirs(_output_folder)

    @classmethod
    def get_ollama_models(cls):
        try:
            import requests
            response = requests.get("http://localhost:11434/api/tags", timeout=2)
            if response.status_code == 200:
                data = response.json()
                models = [model['name'] for model in data.get('models', [])]
                return sorted(models) if models else ["[No models installed]"]
            return ["[Ollama error]"]
        except requests.exceptions.ConnectionError:
            return ["[Ollama not running]"]
        except ImportError:
            return ["[Install requests: pip install requests]"]
        except Exception:
            return ["[Error connecting to Ollama]"]

    @classmethod
    def INPUT_TYPES(cls):
        ollama_models = cls.get_ollama_models()
        default_model = ollama_models[0] if ollama_models else "[No models available]"

        return {
            "required": {
                "generation_mode": (["local", "llm"], {"default": "local"}),
                "note_density": (["Very Sparse (1-2)", "Sparse (2-4)", "Medium (4-6)", "Dense (6-8)", "Very Dense (8-12)"], {"default": "Dense (6-8)"}),
                "prompt": ("STRING", {"default": "Create a trance lead melody", "multiline": True}),
                "bpm": ("INT", {"default": 128, "min": 60, "max": 200, "step": 1, "forceInput": True}),
                "bars": ("INT", {"default": 8, "min": 1, "max": 32, "step": 1, "forceInput": True}),
                "duration": ("FLOAT", {"default": 15.0, "min": 1.0, "max": 120.0, "step": 0.1, "forceInput": True}),
                "llm_provider": (["ollama"], {"default": "ollama"}),
                "model": (ollama_models, {"default": default_model}),
                "temperature": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 2.0, "step": 0.1}),
                "seed": ("INT", {"default": -1, "min": -1, "max": 999999, "step": 1}),
                "output_filename": ("STRING", {"default": "loop", "multiline": False})
            },
            "optional": {
                "scale": ("STRING", {"default": "", "forceInput": True}),
                "chords_json": ("STRING", {"default": "", "forceInput": True})
            }
        }

    RETURN_TYPES = ("STRING", "STRING")
    RETURN_NAMES = ("midi_path", "status")
    FUNCTION = "generate_loop"
    CATEGORY = "absynth-vst"

    def _call_ollama(self, model, system_prompt, user_prompt, temperature):
        try:
            import requests
            url = "http://localhost:11434/api/generate"
            full_prompt = f"{system_prompt}\n\nUser request: {user_prompt}"

            payload = {
                "model": model,
                "prompt": full_prompt,
                "stream": False,
                "options": {"temperature": temperature}
            }

            print(f"[Loop Generator] Sending request to Ollama ({model})...")
            response = requests.post(url, json=payload, timeout=120)

            if response.status_code == 200:
                data = response.json()
                return data.get('response', '')
            else:
                return None

        except Exception as e:
            print(f"[Loop Generator] Ollama error: {e}")
            return None

    def _get_chord_tones(self, root_midi, scale_midi):
        """Get chord tones (root, 3rd, 5th) for a given root note"""
        if not scale_midi or len(scale_midi) < 3:
            return [60, 64, 67]  # Default C major triad

        # Find root in scale
        try:
            root_idx = scale_midi.index(root_midi % 12 + (root_midi // 12) * 12)
        except:
            root_idx = 0

        # Build triad (root, 3rd, 5th in the scale)
        chord_tones = [scale_midi[root_idx % len(scale_midi)]]

        # 3rd (skip 2 scale degrees)
        third_idx = (root_idx + 2) % len(scale_midi)
        chord_tones.append(scale_midi[third_idx])

        # 5th (skip 4 scale degrees)
        fifth_idx = (root_idx + 4) % len(scale_midi)
        chord_tones.append(scale_midi[fifth_idx])

        return chord_tones

    def _generate_lead_like_example(self, output_path, bpm, bars, scale_midi, seed, min_notes=6, max_notes=8, chord_progression=None):
        """Generate a harmonic trance lead using circle of fifths and chord awareness"""
        from midiutil import MIDIFile
        import random

        random.seed(seed)

        # Validate scale_midi
        if not scale_midi or len(scale_midi) == 0:
            print(f"[Loop Generator] Warning: Empty scale, using default C major")
            scale_midi = [60, 62, 64, 65, 67, 69, 71, 72]

        # Create MIDI file
        midi = MIDIFile(1)
        track = 0
        channel = 0

        midi.addTempo(track, 0, bpm)

        # Like the example: ~3 notes per bar, quantized positions
        total_bars = bars
        beats_per_bar = 4
        total_beats = total_bars * beats_per_bar

        print(f"[Loop Generator] Generating {total_bars} bars = {total_beats} beats total")
        print(f"[Loop Generator] Using scale: {scale_midi}")

        # Quantize grid (eighth notes)
        quantize_grid = [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]

        # Note durations (like example - mostly 0.5 to 1.5 beats)
        durations = [0.5, 0.5, 0.5, 1.0, 1.0, 1.5]  # Weighted toward shorter notes

        # Start on a chord tone (root or 5th)
        if chord_progression and len(chord_progression) > 0:
            first_chord_root = scale_midi[0]  # Use scale root
            chord_tones = self._get_chord_tones(first_chord_root, scale_midi)
            last_pitch = random.choice(chord_tones) if (chord_tones and len(chord_tones) > 0) else scale_midi[0]
        else:
            last_pitch = scale_midi[0]  # Start on root

        total_notes_added = 0

        for bar in range(total_bars):
            bar_start = bar * beats_per_bar

            # Use density parameter
            notes_this_bar = random.randint(min_notes, max_notes)

            # Pick positions in this bar (safely)
            num_positions = min(notes_this_bar, len(quantize_grid))
            if num_positions == 0:
                continue  # Skip this bar if no positions available

            positions = random.sample(quantize_grid, num_positions)
            positions.sort()

            notes_added_this_bar = 0

            for i, pos in enumerate(positions):
                beat = bar_start + pos

                # Don't add notes beyond total duration
                if beat >= total_beats:
                    continue

                # Duration
                dur = random.choice(durations)

                # Ensure note doesn't extend past total beats
                if beat + dur > total_beats:
                    dur = max(0.25, total_beats - beat)

                if dur < 0.25:
                    continue

                # HARMONIC MOVEMENT using intervals
                # On strong beats (0, 2), prefer chord tones
                is_strong_beat = pos in [0, 2]

                if is_strong_beat:
                    # Use chord tones on strong beats
                    if scale_midi and len(scale_midi) > 0:
                        chord_root = scale_midi[0]
                        chord_tones = self._get_chord_tones(chord_root, scale_midi)

                        # Prefer movement by 4th/5th (circle of fifths)
                        # Or stay on chord tones
                        if chord_tones and random.random() < 0.7:  # 70% use chord tones
                            pitch = random.choice(chord_tones)
                        else:
                            # Move by perfect intervals (4th or 5th)
                            interval = random.choice([5, 7])  # 4th or 5th in semitones
                            direction = random.choice([-1, 1])
                            new_midi = last_pitch + (interval * direction)

                            # Find closest note in scale
                            if scale_midi:
                                pitch = min(scale_midi, key=lambda x: abs(x - new_midi))
                            else:
                                pitch = last_pitch
                    else:
                        pitch = last_pitch
                else:
                    # Weak beats: passing tones, stepwise motion
                    # Prefer steps (2nds, 3rds)
                    move = random.choices(
                        [0, 1, 2, -1, -2],  # Scale steps
                        weights=[5, 40, 20, 40, 20]  # Heavily favor steps
                    )[0]

                    try:
                        if scale_midi and last_pitch is not None:
                            current_idx = scale_midi.index(last_pitch)
                            new_idx = max(0, min(len(scale_midi) - 1, current_idx + move))
                            pitch = scale_midi[new_idx]
                        else:
                            pitch = last_pitch if last_pitch is not None else 60
                    except (ValueError, IndexError):
                        pitch = random.choice(scale_midi) if (scale_midi and len(scale_midi) > 0) else 60

                # Keep within reasonable range
                if scale_midi and len(scale_midi) > 0:
                    if pitch < scale_midi[0]:
                        pitch = scale_midi[0]
                    if pitch > scale_midi[-1]:
                        pitch = scale_midi[-1]

                # Final safety check
                if pitch is None:
                    pitch = last_pitch if last_pitch is not None else 60

                last_pitch = pitch

                # Velocity (consistent like example)
                velocity = random.randint(95, 105)

                # Add note
                midi.addNote(track, channel, pitch, beat, dur, velocity)
                notes_added_this_bar += 1
                total_notes_added += 1

            print(f"[Loop Generator]   Bar {bar}: added {notes_added_this_bar} notes at beats {bar_start}-{bar_start + 4}")

        print(f"[Loop Generator] ✓ Total notes added: {total_notes_added} across {total_bars} bars")

        # Save
        with open(output_path, 'wb') as f:
            midi.writeFile(f)

        print(f"[Loop Generator] ✓ Saved MIDI file")

        # Verify using mido
        import mido
        verify_midi = mido.MidiFile(output_path)
        verify_length = verify_midi.length
        expected_length = (total_beats * 60.0) / bpm
        print(f"[Loop Generator] Verification: MIDI length = {verify_length:.2f}s (expected: {expected_length:.2f}s)")

    def generate_loop(self, generation_mode, note_density, prompt, bpm, bars, duration, llm_provider, model, temperature, seed, output_filename, scale="", chords_json=""):

        print(f"")
        print(f"╔═══════════════════════════════════════╗")
        print(f"║  LOOP GENERATOR v{self.VERSION}           ║")
        print(f"╚═══════════════════════════════════════╝")
        print(f"")

        # Parse note density
        density_map = {
            "Very Sparse (1-2)": (1, 2),
            "Sparse (2-4)": (2, 4),
            "Medium (4-6)": (4, 6),
            "Dense (6-8)": (6, 8),
            "Very Dense (8-12)": (8, 12)
        }
        min_notes, max_notes = density_map.get(note_density, (6, 8))
        print(f"[Loop Generator] Note Density: {note_density} ({min_notes}-{max_notes} notes/bar)")

        # Handle seed
        if seed == -1:
            actual_seed = random.randint(0, 999999)
        else:
            actual_seed = seed
        random.seed(actual_seed)

        # Parse chords if provided
        key_info = "Cmaj"
        chord_aware_context = ""
        scale_midi_str = "[60, 62, 64, 65, 67, 69, 71, 72]"  # Default C major

        if chords_json and chords_json.strip():
            try:
                chords_data = json.loads(chords_json)
                key = chords_data.get('key', 'C major')
                scale_notes = chords_data.get('scale_notes', [0, 2, 4, 5, 7, 9, 11])
                progression = chords_data.get('progression', [])

                # Extract key for filename
                parts = key.split()
                if len(parts) == 2:
                    note = parts[0].replace('#', 'sharp').replace('b', 'flat')
                    mode = 'min' if 'minor' in parts[1].lower() else 'maj'
                    key_info = f"{note}{mode}"

                # Build scale notes as MIDI numbers for code template
                note_names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
                root_note = 60  # C4
                try:
                    root_name = key.split()[0]
                    root_offset = note_names.index(root_name)
                    root_note = 60 + root_offset
                except:
                    root_note = 60

                # Generate MIDI scale staying within reasonable range
                scale_midi = []
                for offset in scale_notes:
                    midi_note = root_note + offset
                    # Keep within 1 octave range (60-72 for C major)
                    while midi_note > 72:
                        midi_note -= 12
                    while midi_note < 60:
                        midi_note += 12
                    scale_midi.append(midi_note)

                scale_midi_str = str(scale_midi)

                print(f"[Loop Generator] 🎼 Chord-aware mode!")
                print(f"[Loop Generator]   Key: {key}")
                print(f"[Loop Generator]   Scale: {scale}")
                print(f"[Loop Generator]   Scale MIDI: {scale_midi_str}")
                print(f"[Loop Generator]   Chords: {len(progression)}")

                if progression:
                    # Calculate beat positions for each chord
                    seconds_per_beat = 60.0 / bpm
                    chord_timeline = []

                    for chord in progression[:12]:  # Show first 12 chords
                        chord_name = chord.get('chord_name', 'Unknown')
                        chord_time = chord.get('time', 0)
                        chord_beat = chord_time / seconds_per_beat
                        chord_bar = int(chord_beat / 4)
                        beat_in_bar = chord_beat % 4
                        chord_timeline.append(f"    Bar {chord_bar}, Beat {beat_in_bar:.1f}: {chord_name}")

                    chord_timeline_str = '\n'.join(chord_timeline)
                    if len(progression) > 12:
                        chord_timeline_str += f"\n    ... and {len(progression) - 12} more chords"

                    chord_aware_context = f"""
# 🎼 CHORD-AWARE MODE ACTIVE!

KEY: {key}
SCALE: {scale}
SCALE MIDI NOTES: {scale_midi_str}

CHORD PROGRESSION (Bar, Beat: Chord):
{chord_timeline_str}

🚨 CRITICAL FOR MELODIC QUALITY:
1. Use notes from scale: {scale}
2. Use chord tones (root, 3rd, 5th of each chord) for strong beats
3. Create MELODIC phrases that flow with the chord changes
4. When a chord changes, use notes from that chord
5. This creates harmonic, professional-sounding melodies!

EXAMPLE: How to follow chord progression in your code:
- When generating a note at beat position X
- Find which chord is playing at that beat
- Prefer using notes from that chord (especially on beat 1, 3 of each bar)
- This makes the melody harmonically correct and professional
"""

            except Exception as e:
                print(f"[Loop Generator] Warning: Could not parse chords: {e}")

        # Detect type (BEFORE filename generation)
        prompt_lower = prompt.lower()
        is_rolling_bass = any(keyword in prompt_lower for keyword in ['rolling bass', 'rolling bassline', 'roll bass', 'rolling'])
        is_galloping_bass = any(keyword in prompt_lower for keyword in ['gallop', 'galloping', 'galloping bass'])
        is_bassline = any(keyword in prompt_lower for keyword in ['bass', 'bassline', 'sub bass', 'bass line'])
        is_chord_riff = any(keyword in prompt_lower for keyword in ['chord riff', 'chords', 'chord stabs', 'chord pattern', 'rhythmic chords', 'chord rhythm'])
        is_pad = any(keyword in prompt_lower for keyword in ['pad', 'pads', 'atmosphere', 'atmospheric', 'strings', 'sustained'])
        is_arp = any(keyword in prompt_lower for keyword in ['arp', 'arpeggio', 'arpeggiated'])
        is_lead = any(keyword in prompt_lower for keyword in ['lead', 'melody', 'melodic'])

        # Generate filename with readable date/time
        from datetime import datetime
        timestamp = int(time.time())
        datetime_str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

        # Use different prefix based on type
        if is_rolling_bass:
            file_prefix = "rollbass"
        elif is_galloping_bass or is_bassline:
            file_prefix = "bass"
        elif is_chord_riff:
            file_prefix = "chordriff"
        elif is_pad:
            file_prefix = "pad"
        elif is_arp:
            file_prefix = "arp"
        elif is_lead:
            file_prefix = "lead"
        else:
            file_prefix = output_filename

        filename = f"{file_prefix}_{key_info}_{bpm}bpm_{bars}bars_{datetime_str}_seed{actual_seed}.mid"
        output_path = os.path.join(self._output_folder, filename)

        print(f"")
        print(f"[Loop Generator] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"[Loop Generator] GENERATION TARGET:")
        print(f"[Loop Generator]   Bars: {bars}")
        print(f"[Loop Generator]   Duration: {duration:.2f}s")
        print(f"[Loop Generator]   BPM: {bpm}")
        print(f"[Loop Generator]   Key: {key_info}")
        print(f"[Loop Generator]   Seed: {actual_seed}")
        print(f"[Loop Generator] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"")

        if is_rolling_bass:
            print(f"[Loop Generator] 🎸 ROLLING BASS MODE DETECTED!")
            print(f"[Loop Generator]   Using rolling root-octave pattern (MIDI 48-60)")
        elif is_galloping_bass or is_bassline:
            print(f"[Loop Generator] 🎸 GALLOPING BASS MODE DETECTED!")
            print(f"[Loop Generator]   Using galloping trance pattern (MIDI 48-60)")
        elif is_chord_riff:
            print(f"[Loop Generator] 🎹 CHORD RIFF MODE DETECTED!")
            print(f"[Loop Generator]   Using rhythmic chord patterns from detected progression")
        elif is_pad:
            print(f"[Loop Generator] 🎹 PAD MODE DETECTED!")
            print(f"[Loop Generator]   Using sustained chord tones (MIDI 60-84)")

        # Build LLM prompt
        if is_rolling_bass:
            # ROLLING BASS MODE - Extract chord roots
            chord_roots_bass = []

            # Parse progression from chords_json
            progression = []
            if chords_json and chords_json.strip():
                try:
                    chords_data = json.loads(chords_json)
                    progression = chords_data.get('progression', [])
                except:
                    pass

            if progression:
                # Extract root notes from detected chords and convert to bass range
                note_map = {
                    'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3,
                    'E': 4, 'F': 5, 'F#': 6, 'Gb': 6, 'G': 7, 'G#': 8,
                    'Ab': 8, 'A': 9, 'A#': 10, 'Bb': 10, 'B': 11
                }

                for chord in progression[:8]:  # Limit to first 8 chords
                    chord_name = chord.get('chord_name', '')
                    root_semitone = None

                    # Parse root note
                    if len(chord_name) >= 2 and chord_name[:2] in note_map:
                        root_semitone = note_map[chord_name[:2]]
                    elif len(chord_name) >= 1 and chord_name[0] in note_map:
                        root_semitone = note_map[chord_name[0]]

                    if root_semitone is not None:
                        # Convert to bass octave (MIDI 48-60)
                        bass_note = 48 + root_semitone
                        while bass_note > 60:
                            bass_note -= 12
                        while bass_note < 48:
                            bass_note += 12
                        chord_roots_bass.append(bass_note)

            # Fallback to scale notes if no chords detected
            if not chord_roots_bass:
                for note in scale_midi_list[:4]:
                    bass_note = note
                    while bass_note < 48:
                        bass_note += 12
                    while bass_note > 60:
                        bass_note -= 12
                    chord_roots_bass.append(bass_note)

            print(f"[Loop Generator]   Chord roots for rolling bass: {chord_roots_bass}")

            # ROLLING BASS MODE - LLM Prompt
            system_prompt = f"""You are a Python MIDI bassline generator for trance music.

🎵 GENERATE ROLLING TRANCE BASSLINE 🎵

🚨 KICK DRUM ALIGNMENT (CRITICAL FOR TRANCE!) 🚨
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Per bar:
KICK:     |♪|  |♪|  |♪|  |♪|     ← Kick hits on downbeats
TIMING:   1.0  2.0  3.0  4.0

BASS:  ♪♪♪ [♪♪♪][♪♪♪][♪♪♪]     ← Bass plays BETWEEN kicks
TIMING: 0.25 0.50 0.75, 1.25 1.50 1.75, 2.25 2.50 2.75, 3.25 3.50 3.75

→ Bass INTERLOCKS with kick (plays in the gaps!)
→ Creates pumping, driving trance rhythm
→ NEVER hit 1.0, 2.0, 3.0, 4.0 - those are for kicks!

ROLLING BASS PATTERN (from Serum 2 02.mid analysis):
- Alternates between ROOT (low) and OCTAVE (high) of the chord root
- Pattern: LOW-HIGH-LOW, [rest], LOW-HIGH-LOW, [rest] (continuous rolling feel)
- Timing per bar: 0.25, 0.50, 0.75, [skip 1.0], 1.25, 1.50, 1.75, [skip 2.0], 2.25, 2.50, 2.75, [skip 3.0], 3.25, 3.50, 3.75, [skip 4.0]
- Rests on downbeats (1.0, 2.0, 3.0, 4.0) create the "rolling" rhythmic feel
- Example: If chord root is G3 (MIDI 55), pattern is: G3, G4, G3, [rest], G3, G4, G3, [rest]...

You must follow these STRICT CONSTRAINTS:

1. **CHORD ROOTS** (provided): {chord_roots_bass}
   - These are the detected chord roots in MIDI 48-60 range
   - For each chord root, create the rolling pattern: ROOT, ROOT+12, ROOT, [rest], ROOT, ROOT+12, ROOT, [rest]
   - Each chord lasts {bars // len(chord_roots_bass) if chord_roots_bass else 2} bars

2. **BASS REGISTER**:
   - Stay in MIDI 48-60 (C3-C4 range) for LOW notes
   - Octave (LOW+12) will be MIDI 60-72 range for HIGH notes

3. **ROLLING RHYTHM PATTERN**:
   - Per bar positions: 0.25, 0.50, 0.75, 1.25, 1.50, 1.75, 2.25, 2.50, 2.75, 3.25, 3.50, 3.75
   - Pattern: LOW, HIGH, LOW, [skip], LOW, HIGH, LOW, [skip], LOW, HIGH, LOW, [skip], LOW, HIGH, LOW, [skip]
   - Rests on downbeats (0.0, 1.0, 2.0, 3.0) create the rolling feel
   - Duration: 0.15-0.20 beats per note (short, punchy)
   - 🚨 CRITICAL: Notes at 0.75, 1.75, 2.75, 3.75 must have duration ≤ 0.20 to END BEFORE next downbeat!
   - Notes must NEVER end ON 1.0, 2.0, 3.0, 4.0 - they must end BEFORE the downbeat!

4. **CREATIVE VARIATIONS YOU CAN DO**:
   - Vary velocity slightly (95-110 range)
   - Slightly adjust timing (±0.05 beats from exact positions)
   - Vary note duration (0.15-0.20 beats ONLY!)
   - Occasionally add extra octave jumps (+24 instead of +12) for variation
   - Change pattern density in different sections (skip some HIGH notes)
   - 🚨 NEVER use duration > 0.20 for notes at positions x.75 (they will bleed into downbeat!)

5. **WHAT TO KEEP CONSISTENT**:
   - Follow the chord progression (change root note when chord changes)
   - Maintain the rolling LOW-HIGH-LOW rhythm throughout
   - Always skip downbeats (1.0, 2.0, 3.0, 4.0)
   - Stay simple - this is a BASSLINE, not a melody

CODE TEMPLATE (modify creatively within constraints):

```python
from midiutil import MIDIFile
import random

random.seed({actual_seed})  # For variation

# Create MIDI file
midi = MIDIFile(1)
track = 0
channel = 0
midi.addTempo(track, 0, {bpm})

# Chord roots from detected progression
chord_roots = {chord_roots_bass}

# Rolling pattern positions (per bar, avoiding downbeats)
rolling_pattern = [0.25, 0.50, 0.75, 1.25, 1.50, 1.75, 2.25, 2.50, 2.75, 3.25, 3.50, 3.75]

# Pattern type: LOW-HIGH-LOW alternation
# [0]=LOW, [1]=HIGH, [2]=LOW, [3]=LOW, [4]=HIGH, [5]=LOW, etc.
pattern_type = [0, 12, 0, 0, 12, 0, 0, 12, 0, 0, 12, 0]  # 0=root, 12=octave up

# Track used notes to prevent overlaps (CRITICAL!)
used_notes = set()

# Generate rolling bassline
bars_per_chord = 2
total_bars = {bars}
total_beats = total_bars * 4

for bar in range(total_bars):
    chord_index = (bar // bars_per_chord) % len(chord_roots)
    root_note = chord_roots[chord_index]
    bar_start_beat = bar * 4

    for i, beat_offset in enumerate(rolling_pattern):
        beat_position = bar_start_beat + beat_offset

        # Skip if past end
        if beat_position >= total_beats:
            continue

        # Get pattern type (0=root, 12=octave)
        octave_shift = pattern_type[i % len(pattern_type)]

        # VARIATION: Occasionally add extra octave jump
        if random.random() < 0.1:  # 10% chance
            octave_shift = random.choice([0, 12, 24])

        note = root_note + octave_shift

        # Keep in reasonable range
        if note > 72:
            note = root_note + 12  # Fallback to regular octave
        if note < 48:
            note = root_note

        # VARIATION: Vary velocity
        velocity = random.randint(98, 108)

        # VARIATION: Vary duration (MUST be ≤ 0.20 to avoid bleeding into downbeats!)
        # Notes at x.75 + 0.20 duration = x.95 (ends BEFORE next downbeat)
        # Notes at x.75 + 0.25 duration = x.00 (ENDS ON DOWNBEAT - CLASH WITH KICK!)
        duration = random.choice([0.15, 0.18, 0.20])

        # Ensure note doesn't extend past end
        if beat_position + duration > total_beats:
            duration = total_beats - beat_position

        # Skip if duration too short
        if duration < 0.1:
            continue

        # Create unique key for this note event
        note_key = (int(beat_position * 100), note)

        # Only add if not already used (prevents overlapping same pitch)
        if note_key not in used_notes:
            midi.addNote(track, 0, note, beat_position, duration, velocity)
            used_notes.add(note_key)

# Save file (use the provided filename variable)
if 'filename' not in dir():
    output_filename = '{filename}'
else:
    output_filename = filename

# Write MIDI file
with open(output_filename, 'wb') as output_file:
    midi.writeFile(output_file)

print(f"Generated rolling bassline: {{len(chord_roots)}} chords, {bars} bars, {{len(used_notes)}} notes")
print(f"Saved to: {{output_filename}}")
```

🎹 YOUR TASK:
Create a CREATIVE VARIATION of this rolling bassline while following all constraints above.
Make it sound different each time but keep the trance rolling feel!

🚨 CRITICAL - PREVENT MIDIUTIL ERRORS:
1. ALWAYS use `used_notes = set()` to track added notes
2. ALWAYS check `if beat_position >= total_beats: continue`
3. ALWAYS limit duration: `if beat_position + duration > total_beats: duration = total_beats - beat_position`
4. NEVER add overlapping notes on same pitch at same time
5. Use the template's validation code - IT PREVENTS CRASHES!

🚨🚨🚨 CRITICAL - BASSLINE MUST START FROM BAR 0 (FIRST BAR)! 🚨🚨🚨
⚠️ THE BASSLINE MUST ALIGN WITH THE KICK DRUM FROM THE VERY FIRST BAR! ⚠️

1. NEVER change `for bar in range(total_bars):` - it MUST start from bar 0!
2. NEVER use `range(1, total_bars)` or any offset - this skips the first bar!
3. DO NOT add ANY offset to `bar_start_beat` - keep it EXACTLY as `bar_start_beat = bar * 4`
4. The FIRST notes must appear at beat positions 0.25, 0.50, 0.75, 1.25, 1.50, 1.75... (bar 0)
5. Bar 0 is THE FIRST BAR - notes MUST start there to sync with the kick!

Output ONLY Python code, no explanations.
Copy the template structure EXACTLY - DO NOT modify the loop start!

USER PROMPT: "{prompt}"
"""
        elif is_galloping_bass or is_bassline:
            # BASSLINE MODE - Extract actual chord roots from analysis
            chord_roots_bass = []

            # Parse progression from chords_json
            progression = []
            if chords_json and chords_json.strip():
                try:
                    chords_data = json.loads(chords_json)
                    progression = chords_data.get('progression', [])
                except:
                    pass

            if progression:
                # Extract root notes from detected chords and convert to bass range
                note_map = {
                    'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3,
                    'E': 4, 'F': 5, 'F#': 6, 'Gb': 6, 'G': 7, 'G#': 8,
                    'Ab': 8, 'A': 9, 'A#': 10, 'Bb': 10, 'B': 11
                }

                for chord in progression[:8]:  # Limit to first 8 chords
                    chord_name = chord.get('chord_name', '')
                    root_semitone = None

                    # Parse root note
                    if len(chord_name) >= 2 and chord_name[:2] in note_map:
                        root_semitone = note_map[chord_name[:2]]
                    elif len(chord_name) >= 1 and chord_name[0] in note_map:
                        root_semitone = note_map[chord_name[0]]

                    if root_semitone is not None:
                        # Convert to bass octave (MIDI 48-60)
                        bass_note = 48 + root_semitone
                        while bass_note > 60:
                            bass_note -= 12
                        while bass_note < 48:
                            bass_note += 12
                        chord_roots_bass.append(bass_note)

            # Fallback to scale notes if no chords detected
            if not chord_roots_bass:
                for note in scale_midi_list[:4]:
                    bass_note = note
                    while bass_note < 48:
                        bass_note += 12
                    while bass_note > 60:
                        bass_note -= 12
                    chord_roots_bass.append(bass_note)

            print(f"[Loop Generator]   Chord roots for bassline: {chord_roots_bass}")

            # BASSLINE MODE - Give LLM creative freedom with constraints
            system_prompt = f"""You are a Python MIDI bassline generator for trance music.

🎵 GENERATE CREATIVE GALLOPING BASSLINE VARIATIONS 🎵

🚨 KICK DRUM ALIGNMENT (CRITICAL FOR TRANCE!) 🚨
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Per bar:
KICK:     |♪|  |♪|  |♪|  |♪|     ← Kick hits on downbeats
TIMING:   1.0  2.0  3.0  4.0

BASS:  ♪  |♪|♪  |♪|♪  |♪|♪       ← Bass plays WITH AND BETWEEN kicks
TIMING: 0.5 1.0 1.5 2.0 2.5 3.0 3.5

→ Bass hits WITH kicks (1.0, 2.0, 3.0, 4.0) = punchy, driving power!
→ Bass hits BETWEEN kicks (0.5, 1.5, 2.5, 3.5) = fills the groove!
→ Together they create dense, pumping trance bassline!
→ Can also hit on 0.0 (downbeat of bar) for extra emphasis!

You must follow these STRICT CONSTRAINTS:

1. **CHORD ROOTS** (provided): {chord_roots_bass}
   - These are the detected chord roots in MIDI 48-60 range
   - Use these notes as the foundation for your bassline
   - Each chord lasts {bars // len(chord_roots_bass) if chord_roots_bass else 2} bars

2. **BASS REGISTER**:
   - Stay in MIDI 48-60 (C3-C4 range)
   - Never go below 48 or above 60

3. **GALLOPING RHYTHM PATTERN**:
   - Base pattern: beats 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5 (7 notes per bar)
   - Can also add 0.0 for 8 notes per bar: 0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5
   - Notes at 0.5, 1.5, 2.5, 3.5 = BETWEEN kicks (offbeat groove)
   - Notes at 1.0, 2.0, 3.0, 4.0 = WITH kicks (on-beat punch)
   - Together creates dense, driving trance bassline!
   - Duration: 0.25-0.40 beats per note (short, punchy)
   - You can vary density: sparse (4-5 notes), medium (6-7 notes), dense (8 notes)

4. **CREATIVE VARIATIONS YOU CAN DO**:
   - Add occasional jumps to the 5th (+7 semitones) or octave (+12) of the root
   - Vary the velocity (85-110 range) - louder on downbeats (1.0, 2.0), softer between
   - Use different note durations (0.25-0.40 beats)
   - Change pattern density: sparse, medium, or dense
   - Add passing notes (but keep them in MIDI 48-60!)
   - Accent certain beats with higher velocity

5. **WHAT TO KEEP CONSISTENT**:
   - Follow the chord progression (change root note when chord changes)
   - Keep the driving, pumping trance bassline feel
   - Stay simple - this is a BASSLINE, not a melody
   - Maintain galloping rhythm feel throughout

CODE TEMPLATE (modify creatively within constraints):

```python
from midiutil import MIDIFile
import random

random.seed({actual_seed})  # For variation

# Create MIDI file
midi = MIDIFile(1)
track = 0
channel = 0
midi.addTempo(track, 0, {bpm})

# Chord roots from detected progression
chord_roots = {chord_roots_bass}

# Base galloping pattern - you can vary this!
# RECOMMENDED PATTERN (hits WITH and BETWEEN kicks):
# - [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5] (dense, driving - 7 notes/bar)
# - [0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5] (very dense - 8 notes/bar)
#
# Other variations:
# - [0.5, 1.5, 2.5, 3.5] (sparse offbeat - 4 notes/bar)
# - [0.5, 1.0, 1.5, 2.5, 3.0, 3.5] (classic gallop - 6 notes/bar)
gallop_pattern = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5]  # Modify if you want!

# Track used notes to prevent overlaps (CRITICAL!)
used_notes = set()

# Generate bassline with variations
bars_per_chord = 2
total_bars = {bars}
total_beats = total_bars * 4

for bar in range(total_bars):
    chord_index = (bar // bars_per_chord) % len(chord_roots)
    root_note = chord_roots[chord_index]
    bar_start_beat = bar * 4

    for beat_offset in gallop_pattern:
        beat_position = bar_start_beat + beat_offset

        # Skip if past end
        if beat_position >= total_beats:
            continue

        # VARIATION: Occasionally jump to 5th or octave
        note = root_note
        if random.random() < 0.15:  # 15% chance for variation
            jump = random.choice([7, 12])  # 5th or octave
            note = root_note + jump
            # Keep in bass range
            if note > 60:
                note = root_note

        # VARIATION: Vary velocity
        velocity = random.randint(95, 105)

        # VARIATION: Vary duration (short, punchy notes)
        # Notes can overlap with kicks - they work together!
        duration = random.choice([0.25, 0.30, 0.35, 0.40])

        # Ensure note doesn't extend past end
        if beat_position + duration > total_beats:
            duration = total_beats - beat_position

        # Skip if duration too short
        if duration < 0.1:
            continue

        # Create unique key for this note event
        note_key = (int(beat_position * 100), note)

        # Only add if not already used (prevents overlapping same pitch)
        if note_key not in used_notes:
            midi.addNote(track, 0, note, beat_position, duration, velocity)
            used_notes.add(note_key)

# Save file (use the provided filename variable)
# The 'filename' variable is provided in the execution context
if 'filename' not in dir():
    # Fallback if LLM removes the variable for some reason
    output_filename = '{filename}'
else:
    output_filename = filename

# Write MIDI file
with open(output_filename, 'wb') as output_file:
    midi.writeFile(output_file)

print(f"Generated galloping bassline: {{len(chord_roots)}} chords, {bars} bars, {{len(used_notes)}} notes")
print(f"Saved to: {{output_filename}}")
```

🎹 YOUR TASK:
Create a CREATIVE VARIATION of this bassline while following all constraints above.
Make it sound different each time but keep the trance galloping feel!

🚨 CRITICAL - PREVENT MIDIUTIL ERRORS:
1. ALWAYS use `used_notes = set()` to track added notes
2. ALWAYS check `if beat_position >= total_beats: continue`
3. ALWAYS limit duration: `if beat_position + duration > total_beats: duration = total_beats - beat_position`
4. NEVER add overlapping notes on same pitch at same time
5. Use the template's validation code - IT PREVENTS CRASHES!

🚨🚨🚨 CRITICAL - BASSLINE MUST START FROM BAR 0 (FIRST BAR)! 🚨🚨🚨
⚠️ THE BASSLINE MUST ALIGN WITH THE KICK DRUM FROM THE VERY FIRST BAR! ⚠️

1. NEVER change `for bar in range(total_bars):` - it MUST start from bar 0!
2. NEVER use `range(1, total_bars)` or any offset - this skips the first bar!
3. DO NOT add ANY offset to `bar_start_beat` - keep it EXACTLY as `bar_start_beat = bar * 4`
4. The FIRST notes must appear at beat positions 0.5, 1.0, 1.5, 2.5, 3.0, 3.5 (bar 0)
5. Bar 0 is THE FIRST BAR - notes MUST start there to sync with the kick!
6. Bassline starting at bar 1 instead of bar 0 will be OFF-BEAT with the kick!

Output ONLY Python code, no explanations.
Copy the template structure EXACTLY - DO NOT modify the loop start!

USER PROMPT: "{prompt}"
"""
        elif is_chord_riff:
            # CHORD RIFF MODE - Extract chord tones for rhythmic patterns
            print(f"[Loop Generator] 🎹 Building rhythmic chord riff from progression...")

            # Parse progression from chords_json
            progression = []
            if chords_json and chords_json.strip():
                try:
                    chords_data = json.loads(chords_json)
                    progression = chords_data.get('progression', [])
                except:
                    pass

            # Extract chord tones (same as pad mode)
            chord_arrays = []
            chord_names_list = []

            if progression:
                note_map = {
                    'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3,
                    'E': 4, 'F': 5, 'F#': 6, 'Gb': 6, 'G': 7, 'G#': 8,
                    'Ab': 8, 'A': 9, 'A#': 10, 'Bb': 10, 'B': 11
                }

                for chord in progression[:8]:
                    chord_name = chord.get('chord_name', '')
                    notes = chord.get('notes', [])
                    chord_type = chord.get('type', '')

                    # Get unique pitch classes
                    pitch_classes = sorted(set([note % 12 for note in notes]))

                    # For chord riffs, use 3-4 notes
                    is_extended = '7' in chord_type or '6' in chord_type
                    num_notes = min(4 if is_extended else 3, len(pitch_classes))

                    # Convert to mid-range (MIDI 60-72)
                    chord_tones = []
                    for pitch_class in pitch_classes[:num_notes]:
                        normalized = pitch_class + 60
                        chord_tones.append(normalized)

                    chord_tones = sorted(chord_tones)
                    while len(chord_tones) < 3:
                        chord_tones.append(chord_tones[0] + 12)

                    max_notes = 4 if is_extended else 3
                    chord_arrays.append(chord_tones[:max_notes])
                    chord_names_list.append(chord_name)

            # Fallback
            if not chord_arrays:
                scale_midi = scale_midi_list if scale_midi_list else [60, 62, 64, 65, 67, 69, 71, 72]
                chord_arrays = [
                    [scale_midi[0], scale_midi[2], scale_midi[4]],
                    [scale_midi[3], scale_midi[5], scale_midi[0]],
                    [scale_midi[4], scale_midi[6], scale_midi[1]],
                    [scale_midi[0], scale_midi[2], scale_midi[4]],
                ]
                chord_names_list = ["I", "IV", "V", "I"]

            # Format chord arrays
            chords_python_code = "[\n"
            for i, (chord_tones, name) in enumerate(zip(chord_arrays, chord_names_list)):
                chords_python_code += f"    {chord_tones},  # {name}\n"
            chords_python_code += "]"

            print(f"[Loop Generator]   Extracted {len(chord_arrays)} chords:")
            for name, tones in zip(chord_names_list, chord_arrays):
                note_names = [self.NOTE_NAMES[n % 12] for n in tones]
                print(f"[Loop Generator]     {name}: {note_names} (MIDI {tones})")

            system_prompt = f"""You are a Python MIDI chord riff generator for trance music.

🎹 GENERATE RHYTHMIC CHORD RIFF PATTERNS 🎹

🚨 KICK DRUM ALIGNMENT (CRITICAL FOR TRANCE!) 🚨
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Per bar:
KICK:     |♪|  |♪|  |♪|  |♪|     ← Kick hits on downbeats
TIMING:   1.0  2.0  3.0  4.0

CHORD RIFFS can:
→ Hit WITH kicks (1.0, 2.0) for punchy stabs
→ Hit BETWEEN kicks (0.5, 1.5, 2.5, 3.5) for offbeat groove
→ Mix both for complex rhythms

You must follow these STRICT CONSTRAINTS:

1. **CHORD PROGRESSION** (EXTRACTED FROM YOUR MIDI FILE):
   - These are the EXACT chords detected from the chord MIDI file
   - Chords: {', '.join(chord_names_list)}
   - You MUST use ONLY these chord tones - NO OTHER NOTES!

2. **CHORD RIFF CHARACTERISTICS**:
   - Play 2-4 notes simultaneously (chord stabs/hits)
   - Rhythmic patterns: on-beat, offbeat, syncopated
   - Short durations: 0.25-0.75 beats (punchy)
   - Mid-high register (MIDI 55-75)
   - Create driving, rhythmic energy

3. **HARMONIC RULES** 🚨 CRITICAL 🚨:
   - ONLY use notes from the provided chords below
   - Each chord stab MUST use notes from the current chord's tones
   - DO NOT add random notes outside the chord
   - Variations allowed: rhythm, velocity, which chord tones to play
   - Variations NOT allowed: pitch (must stay within chord tones)

4. **RHYTHMIC PATTERNS**:
   Common trance chord riff rhythms:
   - On-beat stabs: 1.0, 2.0, 3.0, 4.0 (with kicks)
   - Offbeat stabs: 0.5, 1.5, 2.5, 3.5 (between kicks)
   - Syncopated: 0.75, 2.25, 3.5 (creates tension)
   - Mixed: Combine all above for variation

   Duration: 0.25-0.75 beats (short, punchy chord hits)
   Velocity: 90-110 for aggressive, driving feel

5. **CREATIVE VARIATIONS**:
   - Which chord tones to play (all 3? just 2? root+5th?)
   - Rhythm density (sparse vs dense)
   - Octave placement (+12/-12 shifts)
   - Velocity accents (some hits louder)
   - Duration variation (0.25 = stab, 0.75 = longer)

6. **REGISTER**:
   - Stay in MIDI 55-75 range (middle-high register)
   - Can layer octaves for thickness
   - Avoid bass range (below 55) and very high (above 75)

CODE TEMPLATE - USE EXACTLY THESE CHORDS:

```python
from midiutil import MIDIFile
import random

random.seed({actual_seed})

# Create MIDI file
midi = MIDIFile(1)
track = 0
channel = 0
midi.addTempo(track, 0, {bpm})

# 🚨 THESE ARE THE EXACT CHORDS FROM YOUR PROGRESSION 🚨
# Chord names: {', '.join(chord_names_list)}
chords = {chords_python_code}

total_bars = {bars}
beats_per_bar = 4
total_beats = total_bars * beats_per_bar

# Track used notes to prevent overlaps (CRITICAL!)
used_notes = set()

# 🎹 CREATIVE CHORD RIFF GENERATOR
# Create rhythmic patterns using ONLY the chord tones above!
#
# EXAMPLE RHYTHMS:
# - Offbeat groove: [0.5, 1.5, 2.5, 3.5]
# - On-beat punches: [1.0, 3.0]
# - Syncopated: [0.75, 2.25, 3.5]
# - Dense: [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0]
#
# Mix and match to create your unique pattern!

bars_per_chord = {bars // len(chord_arrays) if chord_arrays else 2}

for bar in range(total_bars):
    chord_index = (bar // bars_per_chord) % len(chords)
    chord_tones = chords[chord_index]
    bar_start_beat = bar * beats_per_bar

    # DEFINE YOUR RHYTHMIC PATTERN HERE (be creative!)
    # Example: Offbeat stabs
    rhythm_pattern = [0.5, 1.5, 2.5, 3.5]  # Modify this!

    for beat_offset in rhythm_pattern:
        beat_position = bar_start_beat + beat_offset

        if beat_position >= total_beats:
            continue

        # CHOOSE WHICH CHORD TONES TO PLAY (be creative!)
        # Example variations:
        # - Play all: chord_tones
        # - Play 2 notes: [chord_tones[0], chord_tones[2]]
        # - Random 2-3 notes: random.sample(chord_tones, random.randint(2, 3))

        notes_to_play = chord_tones[:3]  # Modify this!

        # Duration (0.25 = stab, 0.5 = medium, 0.75 = longer)
        duration = random.choice([0.25, 0.35, 0.5])

        # Velocity
        velocity = random.randint(95, 110)

        # Add each note in the chord stab
        for note in notes_to_play:
            # Ensure duration doesn't exceed total_beats
            if beat_position + duration > total_beats:
                duration = total_beats - beat_position

            if duration < 0.1:
                continue

            # Track to prevent overlaps
            note_key = (int(beat_position * 100), note)

            if note_key not in used_notes:
                midi.addNote(track, channel, note, beat_position, duration, velocity)
                used_notes.add(note_key)

# Save file
if 'filename' not in dir():
    output_filename = '{filename}'
else:
    output_filename = filename

with open(output_filename, 'wb') as output_file:
    midi.writeFile(output_file)

print(f"Generated chord riff: {{len(chords)}} chords, {bars} bars, {{len(used_notes)}} notes")
print(f"Saved to: {{output_filename}}")
```

🎹 YOUR TASK:
Create a CREATIVE RHYTHMIC CHORD RIFF using the detected chords!
Experiment with different rhythms, chord voicings, and densities!

🚨 CRITICAL:
1. ONLY use notes from the `chords` array - NO OTHER NOTES!
2. Track used notes with `used_notes` set
3. Check beat_position < total_beats
4. Validate duration doesn't exceed bounds
5. Start from bar 0 (NEVER skip first bar!)

Output ONLY Python code, no explanations.

USER PROMPT: "{prompt}"
"""
        elif is_pad:
            # PAD MODE - Extract chord tones for atmospheric pads
            print(f"[Loop Generator] 🎹 Building pad from chord progression...")

            # Parse progression from chords_json
            progression = []
            if chords_json and chords_json.strip():
                try:
                    chords_data = json.loads(chords_json)
                    progression = chords_data.get('progression', [])
                except:
                    pass

            # PRE-EXTRACT ACTUAL CHORD TONES from the progression
            # This ensures the LLM uses ONLY the real chord notes, not random notes
            chord_arrays = []
            chord_names_list = []

            if progression:
                # Note name to MIDI offset mapping
                note_map = {
                    'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3,
                    'E': 4, 'F': 5, 'F#': 6, 'Gb': 6, 'G': 7, 'G#': 8,
                    'Ab': 8, 'A': 9, 'A#': 10, 'Bb': 10, 'B': 11
                }

                for chord in progression[:8]:  # Use first 8 chords
                    chord_name = chord.get('chord_name', '')
                    notes = chord.get('notes', [])
                    chord_type = chord.get('type', '')

                    # Build chord array from actual MIDI notes in the progression
                    # First, get unique pitch classes (note % 12) to avoid duplicates
                    pitch_classes = sorted(set([note % 12 for note in notes]))

                    # For 7th chords and 6th chords, use all 4 pitch classes. Otherwise use 3
                    is_extended = '7' in chord_type or '6' in chord_type
                    num_notes = min(4 if is_extended else 3, len(pitch_classes))

                    # Convert to mid-range for pads (MIDI 60-72)
                    chord_tones = []
                    for pitch_class in pitch_classes[:num_notes]:
                        # Place in middle octave (60-72 range)
                        normalized = pitch_class + 60
                        chord_tones.append(normalized)

                    # Sort and ensure we have minimum 3 notes
                    chord_tones = sorted(chord_tones)
                    while len(chord_tones) < 3:
                        # Add octave of root if needed
                        chord_tones.append(chord_tones[0] + 12)

                    # Keep 3-4 notes (3 for triads, 4 for 7th/6th chords)
                    max_notes = 4 if is_extended else 3
                    chord_arrays.append(chord_tones[:max_notes])
                    chord_names_list.append(chord_name)

            # Fallback: use scale notes if no chords detected
            if not chord_arrays:
                # Build basic triads from scale
                scale_midi = scale_midi_list if scale_midi_list else [60, 62, 64, 65, 67, 69, 71, 72]
                # I chord (root, 3rd, 5th)
                chord_arrays = [
                    [scale_midi[0], scale_midi[2], scale_midi[4]],  # I
                    [scale_midi[3], scale_midi[5], scale_midi[0]],  # IV
                    [scale_midi[4], scale_midi[6], scale_midi[1]],  # V
                    [scale_midi[0], scale_midi[2], scale_midi[4]],  # I
                ]
                chord_names_list = ["I", "IV", "V", "I"]

            # Format chord arrays as Python code
            chords_python_code = "[\n"
            for i, (chord_tones, name) in enumerate(zip(chord_arrays, chord_names_list)):
                chords_python_code += f"    {chord_tones},  # {name}\n"
            chords_python_code += "]"

            print(f"[Loop Generator]   Extracted {len(chord_arrays)} chords:")
            for name, tones in zip(chord_names_list, chord_arrays):
                note_names = [self.NOTE_NAMES[n % 12] for n in tones]
                print(f"[Loop Generator]     {name}: {note_names} (MIDI {tones})")

            system_prompt = f"""You are a Python MIDI pad generator for trance music.

🎹 GENERATE ATMOSPHERIC PAD SOUNDS 🎹

You must follow these STRICT CONSTRAINTS:

1. **PAD CHARACTERISTICS**:
   - Full chord voicings (all chord tones played together)
   - Whole note duration (4 beats = full bar)
   - Play root, 3rd, 5th simultaneously across octaves
   - Mid-range register (MIDI 48-84)
   - Smooth, atmospheric, supportive sound
   - Change with chord progression (one chord per bar or every 2 bars)

2. **CHORD PROGRESSION** (EXTRACTED FROM YOUR MIDI FILE):
   - These are the EXACT chords detected from the chord MIDI file
   - Chords: {', '.join(chord_names_list)}
   - You MUST use ONLY these notes - NO OTHER NOTES!

3. **HARMONIC RULES** 🚨 CRITICAL 🚨:
   - ONLY use notes from the provided chords below
   - DO NOT add random notes or variations outside the chord tones
   - Variations are allowed in: velocity, octave (+12/-12), duration
   - Variations are NOT allowed in: pitch (must stay within chord tones)
   - Each note MUST come from the current chord's [root, 3rd, 5th]

4. **MUSICAL RULES**:
   - Use long durations: 2.0, 3.0, 4.0 beats
   - Layer 2-3 chord tones playing together (polyphonic)
   - Start notes on strong beats (0, 2) of each bar
   - Low velocity (60-80) for soft, atmospheric sound
   - Overlap notes to create smooth transitions

5. **REGISTER**:
   - Stay in MIDI 48-84 (C4-C6 range)
   - Layer octaves for thickness (root at 60, same note at 72)
   - Avoid bass range (below 60)

CODE TEMPLATE - USE EXACTLY THESE CHORDS:

```python
from midiutil import MIDIFile
import random

random.seed({actual_seed})

# Create MIDI file
midi = MIDIFile(1)
track = 0
channel = 0
midi.addTempo(track, 0, {bpm})

# 🚨 THESE ARE THE EXACT CHORDS FROM YOUR PROGRESSION 🚨
# DO NOT CHANGE THESE - THEY WERE EXTRACTED FROM THE CHORD MIDI FILE!
# Chord names: {', '.join(chord_names_list)}
chords = {chords_python_code}

total_bars = {bars}
beats_per_bar = 4
total_beats = total_bars * beats_per_bar

# Track used notes to prevent overlaps (CRITICAL!)
used_notes = set()

# 🎹 CREATIVE PAD GENERATOR
# Use random.seed({actual_seed}) to create different variations!
#
# ALLOWED VARIATIONS (be creative!):
# - Which chord tones to play (root only? 3rd+5th? all 3? mix it up!)
# - Octave placement (chord_tones[0] + 12 for octave up, -12 for down)
# - Velocity (60-80 range, vary for dynamics)
# - Duration (3.0, 3.5, 4.0 beats)
# - Which notes to layer (2 notes vs 5 notes playing together)
#
# 🚨 CRITICAL: Loop through ALL bars (0 to total_bars-1), don't break early!

for bar in range(total_bars):
    # 1. Get current chord for this bar (proportional mapping)
    # Map bar position (0 to total_bars-1) to chord index (0 to num_chords-1)
    num_chords = len(chords)
    chord_index = int((bar / total_bars) * num_chords) if total_bars > 0 else 0
    # Ensure we don't exceed chord array bounds
    chord_index = min(chord_index, num_chords - 1)
    chord_tones = chords[chord_index]  # [root, 3rd, 5th] or [root, 3rd, 5th, 7th]

    # 2. Calculate beat position for this bar (CRITICAL: use bar * 4)
    beat_position = bar * 4.0  # Bar 0 = beat 0, Bar 1 = beat 4, Bar 2 = beat 8, etc.

    # Don't go past end
    if beat_position >= total_beats:
        continue

    # 3. Set duration (pad = long notes)
    duration = random.choice([3.5, 4.0])

    # Clip duration to not extend past end
    if beat_position + duration > total_beats:
        duration = total_beats - beat_position

    if duration < 1.0:
        continue

    # 4. Set velocity (soft for pads)
    velocity = random.randint(65, 75)

    # 5. CREATE YOUR VARIATION HERE!
    # Pick which notes to play from chord_tones
    # chord_tones has 3-4 notes: [root, 3rd, 5th] or [root, 3rd, 5th, 7th]
    # Examples:
    #   - notes_to_play = [chord_tones[0], chord_tones[2]]  # root + 5th
    #   - notes_to_play = chord_tones  # all tones (3 or 4 notes)
    #   - notes_to_play = random.sample(chord_tones, 2)  # random 2 tones
    #   - notes_to_play = [chord_tones[0], chord_tones[0] + 12]  # root in 2 octaves

    # Example: Play all chord tones + some octaves
    notes_to_play = []

    # Add base chord tones (pick 2-4 of them depending on chord size)
    num_tones = random.randint(2, min(3, len(chord_tones)))
    selected_tones = random.sample(chord_tones, num_tones)
    notes_to_play.extend(selected_tones)

    # Maybe add octave of root (50% chance)
    if random.random() < 0.5:
        octave_note = chord_tones[0] + 12  # Root up one octave
        if octave_note <= 84:
            notes_to_play.append(octave_note)

    # Maybe add octave of another tone (30% chance)
    if random.random() < 0.3 and len(chord_tones) >= 3:
        tone_index = random.randint(1, len(chord_tones) - 1)
        octave_note = chord_tones[tone_index] + 12
        if octave_note <= 84:
            notes_to_play.append(octave_note)

    # 6. Add all notes to MIDI (with validation!)
    for pitch in notes_to_play:
        # Ensure pitch is valid (48-84 range for pads)
        if 48 <= pitch <= 84:
            # 🚨 CRITICAL VALIDATION: Check if note is actually from a chord tone
            # Get pitch class (note mod 12)
            pitch_class = pitch % 12
            # Check if this pitch class exists in ANY chord tone
            valid = False
            for chord in chords:
                for tone in chord:
                    if tone % 12 == pitch_class:
                        valid = True
                        break
                if valid:
                    break

            if not valid:
                print(f"WARNING: Note {{pitch}} ({{['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'][pitch_class]}}) is NOT in any chord! Skipping.")
                continue

            note_key = (int(beat_position * 100), pitch)
            if note_key not in used_notes:
                midi.addNote(track, channel, pitch, beat_position, duration, velocity)
                used_notes.add(note_key)

# Save file (use the provided filename variable)
# The 'filename' variable is provided in the execution context
if 'filename' not in dir():
    # Fallback if LLM removes the variable for some reason
    output_filename = '{filename}'
else:
    output_filename = filename

# Write MIDI file
with open(output_filename, 'wb') as output_file:
    midi.writeFile(output_file)

print(f"Generated atmospheric pad: {{len(chords)}} chords, {bars} bars")
print(f"Saved to: {{output_filename}}")
```

🚨 CRITICAL REQUIREMENTS - READ CAREFULLY:

1. **HARMONIC CONSTRAINT** (ABSOLUTE RULE!):
   - ONLY use notes from the `chords` array above
   - Each chord has 3-4 notes: [root, 3rd, 5th] or [root, 3rd, 5th, 7th] for 7th chords
   - You can use these notes in ANY OCTAVE: +12, +24, -12, -24
   - Example: Chord [60, 63, 67] → you can use 48, 60, 63, 67, 72, 75, 79, 84 (octaves of the chord tones)
   - Example: Chord [63, 66, 70, 73] (7th chord) → you can use 51, 54, 58, 61, 63, 66, 70, 73, 75, 78, 82
   - ❌ FORBIDDEN: notes NOT in the chord array
   - The template includes VALIDATION that will skip any wrong notes!

2. **CREATIVE FREEDOM** (USE THE SEED!):
   - Seed is {actual_seed} - use random.seed() to create DIFFERENT variations each run
   - Each generation should sound DIFFERENT but stay harmonic
   - Be creative with: voicing, octaves, velocity, duration, timing, density

3. **VARIATION IDEAS** (all using ONLY chord tones):
   ✓ Minimal pad: Play only root + 5th (2 notes)
   ✓ Full voicing: Play all 3 tones + octave doubles (5-6 notes)
   ✓ Moving pad: Different tones emphasized in different bars
   ✓ Sparse pad: Long notes, few layers
   ✓ Dense pad: Many octave layers, thick sound
   ✓ Dynamic pad: Vary velocity per note (60-80 range)
   ✓ Rhythmic pad: Notes at different beat positions (0, 0.5, 1.0, 2.0)
   ✓ Octave variations: Root in bass (-12), 3rd and 5th in high register (+12, +24)

4. **PAD CHARACTERISTICS**:
   - Long sustained notes (typically 3.0-4.0 beats)
   - Atmospheric and supportive (not melodic)
   - Low-medium velocity (60-80 range)
   - Polyphonic (multiple notes playing together)

5. **TECHNICAL REQUIREMENTS**:
   - MUST start from bar 0 (first bar)
   - MUST use EXACTLY {bars} bars
   - MUST use the provided 'filename' variable
   - MUST use `used_notes = set()` to prevent overlapping notes
   - Follow the chord progression - chord changes every {bars // len(chord_arrays) if chord_arrays else 2} bars

6. **EXAMPLES OF CREATIVE VARIATIONS** (seed-based):

   Seed 123: "Minimal atmospheric pad"
   - Play root + 5th only
   - Root at MIDI 48 (bass), 5th at MIDI 67
   - Velocity 68, duration 4.0

   Seed 456: "Rich layered pad"
   - Play all 3 chord tones in mid range
   - Add root -12 (bass) and 3rd +12 (high)
   - Total: 5 note layers
   - Velocity 72, duration 3.5

   Seed 789: "Moving pad"
   - Bar 0-1: root + 3rd emphasis
   - Bar 2-3: 3rd + 5th emphasis
   - Bar 4-5: root + 5th emphasis
   - Creates subtle movement while staying harmonic

🎹 YOUR TASK:
1. Create a UNIQUE pad variation using seed {actual_seed}
2. Modify ONLY the "# 5. CREATE YOUR VARIATION HERE!" section
3. Keep the loop structure EXACTLY as shown (don't break early!)
4. Use ONLY chord tones from the chords array (no other notes!)

🚨 COMMON MISTAKES TO AVOID:
❌ Don't use "break" in the loop (use "continue" if needed)
❌ Don't calculate beat_position differently (keep "bar * 4.0")
❌ Don't add notes outside chord tones (no scale notes, passing tones, etc.)
❌ Don't change total_bars value
❌ Don't skip bars (loop must go 0 to total_bars-1)

✅ SAFE VARIATIONS:
✓ Change which chord tones to select: random.sample(chord_tones, 2)
✓ Add octaves of chord tones: chord_tones[0] + 12, chord_tones[1] - 12
✓ Vary velocity: random.randint(60, 80)
✓ Vary duration: random.choice([3.0, 3.5, 4.0])
✓ Vary probability of octave doubling: random.random() < 0.7

Output ONLY Python code, no explanations.
The template is designed to be safe - modify only the variation section!

USER PROMPT: "{prompt}"
"""
        else:
            # MELODY/LEAD MODE (original)
            system_prompt = f"""You are a Python MIDI code generator with ADVANCED music theory knowledge. Generate Python code using the midiutil library.

{chord_aware_context}

🎵 MELODY GENERATION RULES 🎵

CRITICAL - CREATE DIFFERENT MELODIES EACH TIME:
- Use random.seed({actual_seed}) to pick DIFFERENT starting notes each run
- Use random.choice() to select from chord notes
- Vary rhythm patterns (don't always use same note lengths)
- Start melodies on DIFFERENT chord tones (not always the root)
- Mix ascending, descending, and jumping patterns
- Create MEMORABLE, SINGABLE phrases

MELODY RULE - STAY IN HARMONY:
- Melodies MUST use notes FROM the current chord (chord tones)
- Em chord [64,67,71] → melody picks from E(64), G(67), B(71) + octaves
- Am chord [69,72,76] → melody picks from A(69), C(72), E(76) + octaves
- Cm chord [60,63,67] → melody picks from C(60), Eb(63), G(67) + octaves
- This keeps melodies harmonically correct!

STRUCTURAL GUIDELINES:
- DENSITY: Using {note_density} setting = {min_notes}-{max_notes} notes per bar
- MELODIC: Create memorable, singable phrases with smooth transitions
- HARMONIC: Follow chord progressions using chord tones
- VARIED: Different rhythm, different starting notes, different intervals
- Sparse settings (1-4 notes/bar) = minimal leads with space
- Dense settings (6-12 notes/bar) = flowing, continuous melodies

🚨🚨🚨 CRITICAL LOOP REQUIREMENTS 🚨🚨🚨

1. FILL ALL {bars} BARS: Generate notes through EVERY SINGLE bar from 0 to {bars - 1}
2. EXACT DURATION: {duration:.2f} seconds @ {bpm} BPM = {bars * 4} beats total
3. QUANTIZED NOTES: Snap to eighth/sixteenth note grid (0, 0.25, 0.5, 0.75, 1, 1.25, 1.5... per bar)
4. QUANTIZED DURATIONS: Use 0.25, 0.5, 0.75, 1.0, 1.5 beats (shorter for flowing melodies!)
5. MELODIC SPACING: {min_notes}-{max_notes} notes per bar (density: {note_density})
6. CHORD AWARENESS: Pick melody notes from current chord tones
7. LOOP-READY: Must loop perfectly back to start
8. OCTAVE VARIETY: Add +12 to chord notes for higher octave variations

⚠️ CRITICAL MISTAKES TO AVOID:
❌ STOPPING AT BAR 7! You MUST loop through ALL {bars} bars (range(total_bars))!
❌ USING 'break' - Use 'continue' instead so the loop doesn't stop!
❌ UNQUANTIZED NOTES! Use the quantize_grid, not random.uniform()!
❌ TOO DENSE! 2-4 notes/bar, not 8+!
❌ Leaving bars empty!
❌ OVERLAPPING NOTES! Track used_positions in each bar to prevent notes at same beat position!
❌ SAME MELODY EVERY TIME! Use random.choice() and vary starting notes!

CODE REQUIREMENTS:
- Use 'from midiutil import MIDIFile'
- Use 'import random' and add random.seed({actual_seed})
- Set BPM to {bpm}
- Generate SPARSE lead melody (2-4 notes per bar)
- Use scale: {scale if scale else "C D E F G A B"}
- Match chord progression timing if provided
- Save file as '{filename}'
- Output ONLY the Python code, no explanations

CHORD PROGRESSIONS FOR KEY:
{scale if scale else "C major"} uses these chord progressions:
- Build chords from scale degrees (I, ii, iii, IV, V, vi)
- Each chord has 3 notes (root, 3rd, 5th)
- Melody picks notes FROM current chord for harmonic correctness

EXAMPLE CHORD VALUES FOR COMMON KEYS:
C minor: Cm [60,63,67], Fm [65,68,72], Gm [67,70,74], Ab [68,72,75]
E minor: Em [64,67,71], Am [69,72,76], Bm [71,74,78], C [60,64,67]
D minor: Dm [62,65,69], Gm [67,70,74], Am [69,72,76], F [65,69,72]

CODE TEMPLATE FOR MELODIC TRANCE LEADS:

```python
from midiutil import MIDIFile
import random

random.seed({actual_seed})  # Creates variation each run!

# Create MIDI file
midi = MIDIFile(1)
track = 0
channel = 0

midi.addTempo(track, 0, {bpm})

# Define scale as MIDI note numbers
scale_notes = {scale_midi_str}  # {scale if scale else "C D E F G A B"}

# Build chord progression from scale
# For {scale if scale else "C major"}, use triads built from scale degrees
# Example: C minor → Cm, Fm, Gm, Cm progression
# Each chord = [root, 3rd, 5th] from scale

# Example chord progression (adjust for actual key)
chords = [
    {{'notes': [60, 63, 67]}},  # i chord (Cm if C minor)
    {{'notes': [65, 68, 72]}},  # iv chord (Fm if C minor)
    {{'notes': [67, 70, 74]}},  # v chord (Gm if C minor)
    {{'notes': [60, 63, 67]}}   # i chord (back to root)
]

# Lead melody parameters
total_bars = {bars}
beats_per_bar = 4
total_beats = total_bars * beats_per_bar  # {bars * 4} beats

# QUANTIZATION grids - sixteenth notes for flowing melodies
quantize_grid = [0, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 3.75]
note_durations = [0.25, 0.5, 0.75, 1.0, 1.5]  # Shorter durations for more notes

# 🎹 ARPEGGIO MODE: Check if prompt contains "arpeggio" or "arp"
prompt_lower = "{prompt}".lower()
is_arpeggio = "arpeggio" in prompt_lower or "arp" in prompt_lower

# Generate MELODIC LEAD or ARPEGGIO - MUST fill ALL {bars} bars (0 to {bars - 1})
for bar in range(total_bars):  # CRITICAL: This MUST loop through ALL bars!
    bar_start_beat = bar * beats_per_bar

    # Get current chord from progression (cycle through)
    chord = chords[bar % len(chords)]

    if is_arpeggio:
        # TRANCE ARPEGGIO: Rhythmic interval patterns (like professional trance arps)
        # Use root, fifth, octave in rhythmic patterns
        root = chord['notes'][0]
        third = chord['notes'][1] if len(chord['notes']) > 1 else root + 4
        fifth = chord['notes'][2] if len(chord['notes']) > 2 else root + 7

        # Build intervals: root, fifth, octave
        octave = root + 12
        fifth_high = fifth + 12

        # Create trance-style rhythmic pattern (not sequential!)
        # Pattern: root-fifth, root-fifth, fifth-octave, fifth-root, octave-fifth, root-octave
        arp_pattern = [
            root, fifth,      # 0.0, 0.25
            root, fifth,      # 0.5, 0.75
            fifth, octave,    # 1.0, 1.25
            fifth, root,      # 1.5, 1.75
            octave, fifth,    # 2.0, 2.25
            root, octave,     # 2.5, 2.75
            fifth, root,      # 3.0, 3.25
            octave, fifth     # 3.5, 3.75
        ]

        # Play pattern with sixteenth note rhythm
        duration = 0.25
        for i, note in enumerate(arp_pattern):
            beat_position = bar_start_beat + (i * duration)
            if beat_position >= total_beats:
                break
            velocity = random.randint(90, 105)
            midi.addNote(track, channel, note, beat_position, duration, velocity)

    else:
        # MELODY MODE: Random chord tones with varied rhythm
        # Expand chord with octave variations
        chord_tones = chord['notes'] + [n + 12 for n in chord['notes']]

        # Generate notes per bar based on density setting
        # Density: {note_density}
        notes_this_bar = random.randint({min_notes}, {max_notes})

        # Track used positions to avoid overlaps (CRITICAL!)
        used_positions = []

        for i in range(notes_this_bar):
            # QUANTIZED position - snap to grid (eighth notes)
            available_positions = [p for p in quantize_grid if p not in used_positions]
            if not available_positions:
                continue  # Skip if all positions used

            beat_offset = random.choice(available_positions)
            used_positions.append(beat_offset)

            beat_position = bar_start_beat + beat_offset

            # Make sure we don't go past total beats
            if beat_position >= total_beats:
                continue

            # QUANTIZED duration - VARY the rhythm!
            duration = random.choice(note_durations)

            # Ensure note doesn't extend past the loop point
            if beat_position + duration > total_beats:
                duration = total_beats - beat_position

            # Skip if duration too short
            if duration < 0.25:
                continue

            # Pick melodic pitch FROM CURRENT CHORD (harmonically correct!)
            pitch = random.choice(chord_tones)

            # Vary velocity slightly
            velocity = random.randint(85, 100)

            # Add the note
            midi.addNote(track, channel, pitch, beat_position, duration, velocity)

if is_arpeggio:
    print(f"✓ Generated arpeggio pattern with chord progression spanning ALL {bars} bars")
else:
    print(f"✓ Generated melodic lead with chord progression spanning ALL {bars} bars")

# Save MIDI file
with open('{filename}', 'wb') as output_file:
    midi.writeFile(output_file)

print(f"✓ Saved to {filename}")
```

🔍 VERIFICATION CHECKLIST:
After generating, verify your code does this:
✓ for bar in range(total_bars) - loops through ALL {bars} bars
✓ Uses quantize_grid with sixteenth notes [0, 0.25, 0.5, 0.75, 1, ...]
✓ Uses note_durations with shorter values [0.25, 0.5, 0.75, 1.0, 1.5]
✓ Uses 'continue' not 'break' in the inner loop
✓ Generates {min_notes}-{max_notes} notes per bar (based on density setting: {note_density})
✓ Tracks used_positions = [] to prevent overlapping notes in same bar
✓ Uses chord progression - cycles through chords with bar % len(chords)
✓ Picks melody notes from chord_tones (chord['notes'] + octaves)
✓ Uses random.choice() for variation in notes AND rhythm

🎹 CREATIVE REQUIREMENTS:
- Build a CHORD PROGRESSION (i-iv-v-i or similar)
- Notes MUST come from current chord tones (harmonically correct!)
- Add octave extensions: chord_tones = chord['notes'] + [n+12 for n in chord['notes']]
- **DENSITY CONTROL**: Current setting is {note_density} = {min_notes}-{max_notes} notes/bar
- **Adjust durations based on density**: More notes = shorter durations (0.25, 0.5), Fewer notes = longer durations (1.0, 1.5)

FOR ARPEGGIOS (if prompt contains "arpeggio"/"arp"):
- Play chord notes in SEQUENTIAL ORDER (ascending: 60,63,67,72,75,79 or descending: 79,75,72,67,63,60)
- Use UNIFORM durations (all notes same length: 0.25 or 0.5)
- Use 2-3 octaves: chord['notes'] + [n+12 for n in chord['notes']] + [n+24 for n in chord['notes']]
- Fill EVERY beat position (12-16 notes per bar)
- Example: sorted(chord_tones_extended) for ascending, reversed() for descending

FOR MELODIES (if NOT arpeggio):
- VARY starting notes each run (use random.choice, not always root!)
- VARY rhythm patterns (mix 0.25, 0.5, 0.75, 1.0, 1.5 beat durations)
- Create MEMORABLE phrases that match the mood described in prompt
- Each generation should sound DIFFERENT (use the seed for variation!)

MUSIC THEORY TIPS:
- Start phrases on chord tones (root, 3rd, or 5th)
- Use stepwise motion for smooth transitions
- Jump to different octaves for interest
- End phrases on stable tones (root or 5th)

USER'S CREATIVE PROMPT: "{prompt}"

NOTE DENSITY SETTING: {note_density}
- Generate {min_notes}-{max_notes} notes per bar
- Adjust durations: Fewer notes = longer durations (1.0, 1.5), More notes = shorter durations (0.25, 0.5)

🎹 SPECIAL INSTRUCTIONS FOR TRANCE ARPEGGIOS:
If the prompt contains "arpeggio", "arp", "arpeggiated":
- DON'T play notes sequentially (root, 3rd, 5th, octave...)
- INSTEAD: Create RHYTHMIC INTERVAL PATTERNS like professional trance arpeggios
- Use chord tones (root, 3rd, 5th) and their octaves (+12, +24)
- Create JUMPING patterns: root→fifth, fifth→octave, octave→root, etc.
- Use UNIFORM sixteenth note rhythm (0.25 beat duration)
- Example pattern for ANY chord: [root, fifth, root, fifth, fifth, octave, fifth, root, octave, fifth, root, octave]
- The PATTERN stays similar, but NOTES come from current chord in current key!
- This creates the driving, rhythmic trance arp sound!

Now generate Python code that creates a {bars}-bar pattern that:
1. Uses a chord progression (cycle through chords)
2. **IF ARPEGGIO**: Create RHYTHMIC JUMPING patterns using chord tones (root, 3rd, 5th, octaves)
   - Extract: root = chord['notes'][0], fifth = chord['notes'][2], octave = root + 12
   - Pattern example: [root, fifth, root, fifth, fifth, octave, fifth, root, octave, fifth, root, octave, fifth, root, octave, fifth]
   - Use uniform 0.25 duration for all notes
   - Pattern adapts to CURRENT CHORD in CURRENT KEY automatically!
3. **IF MELODY**: Pick random notes from chord tones with varied rhythm
4. Has octave variety (adds +12, +24 to chord notes)
5. Uses notes_this_bar = random.randint({min_notes}, {max_notes}) for density control (melody only)
6. Sounds DIFFERENT each time (random.choice for variation)
7. Matches the mood/style described in the prompt
8. Fills ALL {bars} bars completely
"""

        # Parse scale_midi from string
        if isinstance(scale_midi_str, str):
            import ast
            scale_midi_list = ast.literal_eval(scale_midi_str)
        else:
            scale_midi_list = [60, 62, 64, 65, 67, 69, 71, 72]  # Default C major

        # Branch based on generation mode
        if generation_mode == "local":
            # LOCAL MODE: Use fixed algorithm (fast, reliable)
            print(f"[Loop Generator] 🎯 LOCAL MODE: Generating with fixed algorithm...")

            try:
                self._generate_lead_like_example(output_path, bpm, bars, scale_midi_list, actual_seed, min_notes, max_notes)
            except Exception as e:
                print(f"[Loop Generator] ✗ Error generating MIDI: {e}")
                import traceback
                traceback.print_exc()
                return ("", f"ERROR: {str(e)}")

        else:
            # LLM MODE: Use LLM to generate creative melodies
            print(f"[Loop Generator] 🤖 LLM MODE: Generating with {model}...")

            if llm_provider == "ollama":
                llm_response = self._call_ollama(model, system_prompt, prompt, temperature)
            else:
                return ("", "ERROR: Only Ollama is supported currently")

            if not llm_response:
                return ("", "ERROR: No response from LLM")

            print(f"[Loop Generator] ✓ Response received, executing code...")

            # Extract and execute code
            import re

            # Try multiple extraction patterns
            code = None

            # Pattern 1: ```python\n...\n```
            code_match = re.search(r'```python\n(.*?)```', llm_response, re.DOTALL)
            if code_match:
                code = code_match.group(1)

            # Pattern 2: ```\n...\n``` (no language specified)
            if not code:
                code_match = re.search(r'```\n(.*?)```', llm_response, re.DOTALL)
                if code_match:
                    code = code_match.group(1)

            # Pattern 3: Look for "from midiutil" as start marker
            if not code:
                if 'from midiutil import MIDIFile' in llm_response:
                    lines = llm_response.split('\n')
                    code_lines = []
                    in_code = False
                    for line in lines:
                        if 'from midiutil import MIDIFile' in line:
                            in_code = True
                        if in_code:
                            # Stop at markdown fence or obvious non-code
                            if line.strip().startswith('```') or (line.strip() and not line[0].isspace() and ':' not in line and '=' not in line and 'import' not in line and 'from' not in line and '#' not in line and 'midi' not in line.lower() and 'random' not in line.lower()):
                                break
                            code_lines.append(line)
                    code = '\n'.join(code_lines)

            # Fallback: use entire response
            if not code or len(code.strip()) < 10:
                code = llm_response

            # Clean up code
            code = code.strip()

            # Debug: Show first 300 chars of extracted code
            print(f"[Loop Generator] Extracted code ({len(code)} chars):")
            print(f"[Loop Generator] Preview:\n{code[:300]}...")

            # Validate code before executing
            if not code or len(code.strip()) < 10:
                return ("", "ERROR: LLM returned empty or invalid code")

            # Execute in safe directory
            original_dir = os.getcwd()
            try:
                os.chdir(self._output_folder)

                # Import required modules for exec
                exec_globals = {
                    '__name__': '__main__',
                    'MIDIFile': __import__('midiutil').MidiFile.MIDIFile,
                    'random': __import__('random'),
                    '__file__': os.path.join(self._output_folder, filename),
                    'filename': filename,  # Make filename available to generated code
                    'output_path': output_path  # Full path as backup
                }

                print(f"[Loop Generator] Executing LLM code in: {os.getcwd()}")
                print(f"[Loop Generator] Target filename: {filename}")
                exec(code, exec_globals)
                print(f"[Loop Generator] Code execution completed")

                # Check if file was created immediately after exec
                if os.path.exists(filename):
                    print(f"[Loop Generator] ✓ File exists: {filename} ({os.path.getsize(filename)} bytes)")

                    # Validate the file has correct duration
                    try:
                        check_midi = mido.MidiFile(filename)
                        generated_length = check_midi.length
                        expected_length = duration
                        length_diff = abs(generated_length - expected_length)

                        if length_diff > expected_length * 0.5:  # More than 50% off
                            print(f"[Loop Generator] ⚠️ WARNING: Generated MIDI is too short!")
                            print(f"[Loop Generator]   Expected: {expected_length:.2f}s, Got: {generated_length:.2f}s")
                            print(f"[Loop Generator]   This suggests the LLM broke the loop early")
                            os.chdir(original_dir)
                            return ("", f"ERROR: Generated MIDI is incomplete ({generated_length:.2f}s instead of {expected_length:.2f}s). Try again or use 'local' mode.")
                    except Exception as e:
                        print(f"[Loop Generator] ⚠️ Could not validate MIDI length: {e}")

                else:
                    print(f"[Loop Generator] ✗ File NOT found: {filename}")
                    # List all MIDI files in current directory for debugging
                    import glob
                    midi_files = glob.glob("*.mid")
                    print(f"[Loop Generator] MIDI files in {os.getcwd()}: {midi_files}")

                os.chdir(original_dir)
            except SyntaxError as e:
                os.chdir(original_dir)
                print(f"[Loop Generator] ✗ SYNTAX ERROR in LLM code: {e}")
                print(f"[Loop Generator] First 500 chars of code:\n{code[:500]}")
                import traceback
                traceback.print_exc()
                return ("", f"ERROR: invalid syntax - LLM returned malformed code. Try 'local' mode instead.")
            except Exception as e:
                os.chdir(original_dir)
                print(f"[Loop Generator] ✗ Error executing LLM code: {e}")
                import traceback
                traceback.print_exc()
                return ("", f"ERROR: {str(e)}")

        # Verify the file was created and is valid
        print(f"[Loop Generator] Checking for MIDI file at: {output_path}")
        print(f"[Loop Generator] File exists: {os.path.exists(output_path)}")
        if os.path.exists(output_path):
            # Try to load it to verify it's valid
            try:
                generated_midi = mido.MidiFile(output_path)
                print(f"[Loop Generator] ✓ MIDI file is valid")

                # Validate loop properties
                generated_duration = generated_midi.length

                duration_diff = abs(generated_duration - duration)
                duration_percent_diff = (duration_diff / duration) * 100 if duration > 0 else 100

                print(f"")
                print(f"[Loop Generator] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                print(f"[Loop Generator] LOOP VALIDATION:")
                print(f"[Loop Generator]   Target duration: {duration:.2f}s")
                print(f"[Loop Generator]   Generated duration: {generated_duration:.2f}s")
                print(f"[Loop Generator]   Difference: {duration_diff:.2f}s ({duration_percent_diff:.1f}%)")

                if duration_percent_diff < 5:
                    print(f"[Loop Generator]   ✓ PERFECT LOOP! Duration match!")
                elif duration_percent_diff < 10:
                    print(f"[Loop Generator]   ✓ Good loop (within 10%)")
                else:
                    print(f"[Loop Generator]   ⚠ Warning: Duration mismatch > 10%")

                print(f"[Loop Generator] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                print(f"")
                print(f"╔═══════════════════════════════════════╗")
                print(f"║  🔄 LOOP GENERATION: SUCCESS ✓        ║")
                print(f"╚═══════════════════════════════════════╝")
                print(f"")

                return (output_path, f"SUCCESS: Loop MIDI generated ({bars} bars, {bpm} BPM)")
            except Exception as e:
                print(f"[Loop Generator] ✗ MIDI validation error: {e}")
                import traceback
                traceback.print_exc()
                return ("", f"ERROR: Invalid MIDI file: {str(e)}")
        else:
            return ("", "ERROR: MIDI file was not created")
