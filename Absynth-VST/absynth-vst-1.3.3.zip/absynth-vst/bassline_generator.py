"""
Trance Bassline Generator - DEEP SUB BASS

This generator uses RHYTHM PATTERNS from your reference MIDI files,
but plays them MUCH DEEPER for proper sub-bass:

- example-bassline.mid → offbeat_trance rhythm (DEEP version)
- TLM Sub Bass.mid → driving_offbeat rhythm (DEEP version)

KEY FEATURES:
- DEEP SUB BASS: All notes stay MIDI 36-50 (never goes high!)
- Jumps by 5th (+7 semitones) instead of octave (+12)
- Roots: MIDI 36-48 range (C2 to C3)
- Jumps: Max MIDI 50 (D3) - stays LOW!

NO high notes! This is DEEP bass that rumbles.
"""

import random
from typing import List, Tuple, Dict
from dataclasses import dataclass

@dataclass
class BasslineNote:
    """Represents a single bassline note"""
    note: int  # MIDI note number
    start_beat: float  # Position in beats
    duration: float  # Duration in beats
    velocity: int


class TranceBassliceGenerator:
    """
    Generates trance basslines by EXACTLY COPYING your reference MIDI files

    - Copies EXACT rhythm patterns from example-bassline.mid and TLM Sub Bass.mid
    - Transposes to detected key/scale
    - Keeps all notes in MIDI 39-60 range
    - NO variations, just exact copy + transpose
    """

    # Scale intervals (semitones from root)
    SCALES = {
        'major': [0, 2, 4, 5, 7, 9, 11],
        'minor': [0, 2, 3, 5, 7, 8, 10],
        'harmonic_minor': [0, 2, 3, 5, 7, 8, 11],
        'melodic_minor': [0, 2, 3, 5, 7, 9, 11],
        'dorian': [0, 2, 3, 5, 7, 9, 10],
        'phrygian': [0, 1, 3, 5, 7, 8, 10],
        'mixolydian': [0, 2, 4, 5, 7, 9, 10],
    }

    # Common trance chord progressions (scale degrees, 0-indexed)
    PROGRESSIONS = {
        'classic': [0, 5, 3, 4],  # I - VI - IV - V (e.g., C - Am - F - G in C major)
        'emotional': [0, 4, 5, 3],  # I - V - VI - IV
        'uplifting': [0, 2, 5, 4],  # I - III - VI - V
        'dark': [0, 5, 3, 6],  # i - VI - iv - VII
        'simple': [0, 3, 4, 0],  # I - IV - V - I
    }

    # Note name to semitone mapping
    NOTE_MAP = {
        'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3,
        'E': 4, 'F': 5, 'F#': 6, 'Gb': 6, 'G': 7, 'G#': 8,
        'Ab': 8, 'A': 9, 'A#': 10, 'Bb': 10, 'B': 11
    }

    def __init__(self, root_note: int, scale: str = 'minor', octave: int = 3):
        """
        Initialize the bassline generator

        Args:
            root_note: MIDI note number for the root (e.g., 0 for C)
            scale: Scale type (major, minor, harmonic_minor, etc.)
            octave: Bass octave (3 = C2-C3 range, MIDI 36-60) - ALWAYS use 3 for proper bass depth

        MIDI Note Ranges:
            - Octave 3 = C2 (MIDI 36) to B2 (MIDI 47) - PROPER BASS RANGE
            - Octave jumps go to C3 (MIDI 48) to B3 (MIDI 59)
            - Matches example-bassline.mid (MIDI 39-60) and MDTM bass (MIDI 36-56)
        """
        self.root_note = root_note
        self.scale = scale
        self.octave = octave
        self.base_midi_note = (octave * 12) + root_note

    def parse_chord_root(self, chord_name: str) -> int:
        """
        Extract root note from chord name

        Examples:
            'Cm' -> 0 (C)
            'F#m' -> 6 (F#)
            'Bb7' -> 10 (Bb)

        Returns:
            Semitone value (0-11) of the root note
        """
        if not chord_name:
            return 0

        # Try two-character note names first (C#, Db, etc.)
        if len(chord_name) >= 2 and chord_name[:2] in self.NOTE_MAP:
            return self.NOTE_MAP[chord_name[:2]]
        # Try single-character note names
        elif len(chord_name) >= 1 and chord_name[0] in self.NOTE_MAP:
            return self.NOTE_MAP[chord_name[0]]
        else:
            return 0  # Default to C if can't parse

    def get_scale_notes(self, octave_offset: int = 0) -> List[int]:
        """Get all notes in the scale for the given octave"""
        scale_intervals = self.SCALES.get(self.scale, self.SCALES['minor'])
        base = self.base_midi_note + (octave_offset * 12)
        return [base + interval for interval in scale_intervals]

    def get_progression_notes(self, progression: str = 'classic') -> List[int]:
        """
        Get root notes for a chord progression

        IMPORTANT: Ensures all roots stay in MIDI 36-48 range (C2-C3)
        This keeps octave jumps (+12) within MIDI 48-60 range, matching your examples
        """
        scale_notes = self.get_scale_notes()
        degrees = self.PROGRESSIONS.get(progression, self.PROGRESSIONS['classic'])
        roots = [scale_notes[degree % len(scale_notes)] for degree in degrees]

        # Ensure all roots are in proper bass range (MIDI 36-48)
        # If a root goes above 48, drop it one octave
        adjusted_roots = []
        for root in roots:
            while root > 48:
                root -= 12
            while root < 36:
                root += 12
            adjusted_roots.append(root)

        return adjusted_roots

    def generate_offbeat_trance(
        self,
        bars: int = 16,
        progression: str = 'classic',
        bars_per_chord: int = 4,
        velocity: int = 100,
        custom_chord_roots: List[int] = None
    ) -> List[BasslineNote]:
        """
        DEEP bass - pattern based on example-bassline.mid but MUCH LOWER

        Pattern per 4 bars (one chord):
        - Beat 0.50: Root (DEEP - MIDI 36-48)
        - Beat 1.00: Root
        - Beat 1.50: Root
        - Beat 1.75: Root+7 (5th jump, not octave - stays LOW)
        - Beat 2.00: Root
        - Beat 2.50: Root
        - Beat 3.00: Root
        - Beat 3.50: Root
        - Beat 3.75: Root+7 (5th jump - stays LOW)

        DEEP BASS - No high notes! All notes stay MIDI 36-50
        """
        notes = []
        # Use custom chord roots if provided, otherwise use predefined progression
        if custom_chord_roots:
            progression_notes = custom_chord_roots
        else:
            progression_notes = self.get_progression_notes(progression)

        for bar in range(bars):
            chord_index = (bar // bars_per_chord) % len(progression_notes)
            root = progression_notes[chord_index]

            # Jump by 5th (+7 semitones) instead of octave (+12)
            # This keeps it DEEP - max around MIDI 48-50
            fifth_up = min(root + 7, 50)

            beat_offset = bar * 4

            # Pattern - stays DEEP! (9 notes per bar)
            pattern = [
                (0.50, root),
                (1.00, root),
                (1.50, root),
                (1.75, fifth_up),  # 5th, not octave - stays low!
                (2.00, root),
                (2.50, root),
                (3.00, root),
                (3.50, root),
                (3.75, fifth_up),  # 5th, not octave - stays low!
            ]

            for beat, note in pattern:
                notes.append(BasslineNote(
                    note=note,
                    start_beat=beat_offset + beat,
                    duration=0.25,
                    velocity=velocity
                ))

        return notes

    def generate_simple_root(
        self,
        bars: int = 16,
        progression: str = 'classic',
        bars_per_chord: int = 4,
        velocity: int = 100,
        custom_chord_roots: List[int] = None
    ) -> List[BasslineNote]:
        """
        SUPER SIMPLE - Just plays the root note as 8th notes

        Pattern from example-bassline2.mid:
        - Just ONE note per chord (the root)
        - Repeated 8th notes (every 0.5 beats)
        - 8 notes per bar
        - DEEP version: MIDI 36-48 range

        This is the SIMPLEST bassline - just follows chord roots!
        """
        notes = []
        # Use custom chord roots if provided, otherwise use predefined progression
        if custom_chord_roots:
            progression_notes = custom_chord_roots
        else:
            progression_notes = self.get_progression_notes(progression)

        for bar in range(bars):
            chord_index = (bar // bars_per_chord) % len(progression_notes)
            root = progression_notes[chord_index]

            beat_offset = bar * 4

            # Super simple: 8th notes on every beat and offbeat
            for i in range(8):
                beat = i * 0.5
                notes.append(BasslineNote(
                    note=root,
                    start_beat=beat_offset + beat,
                    duration=0.25,
                    velocity=velocity
                ))

        return notes

    def generate_driving_offbeat(
        self,
        bars: int = 16,
        progression: str = 'classic',
        bars_per_chord: int = 2,
        velocity: int = 100,
        custom_chord_roots: List[int] = None
    ) -> List[BasslineNote]:
        """
        DEEP driving bass - pattern based on TLM Sub Bass.mid but MUCH LOWER

        Pattern per 2 bars (one chord):
        - Beat 0.25: Root (DEEP - MIDI 36-48)
        - Beat 0.75: Root
        - Beat 1.25: Root
        - Beat 1.50: Root+7 (5th jump - stays LOW, max MIDI 50)
        - Beat 1.75: Root
        - Beat 2.25: Root
        - Beat 2.75: Root
        - Beat 3.25: Root
        - Beat 3.50: Root+7 (5th jump - stays LOW)
        - Beat 3.75: Root

        100% OFFBEAT - NO downbeats!
        DEEP BASS - All notes stay MIDI 36-50, no high jumps!
        """
        notes = []
        # Use custom chord roots if provided, otherwise use predefined progression
        if custom_chord_roots:
            progression_notes = custom_chord_roots
        else:
            progression_notes = self.get_progression_notes(progression)

        for bar in range(bars):
            chord_index = (bar // bars_per_chord) % len(progression_notes)
            root = progression_notes[chord_index]

            # Jump by 5th (+7 semitones) instead of octave (+12)
            # Keeps it DEEP - max around MIDI 48-50
            fifth_up = min(root + 7, 50)

            beat_offset = bar * 4

            # Pattern - stays DEEP! (10 notes per bar)
            pattern = [
                (0.25, root),
                (0.75, root),
                (1.25, root),
                (1.50, fifth_up),  # 5th, not octave - stays low!
                (1.75, root),
                (2.25, root),
                (2.75, root),
                (3.25, root),
                (3.50, fifth_up),  # 5th, not octave - stays low!
                (3.75, root),
            ]

            for beat, note in pattern:
                notes.append(BasslineNote(
                    note=note,
                    start_beat=beat_offset + beat,
                    duration=0.25,
                    velocity=velocity
                ))

        return notes

    def generate_rolling_bass(
        self,
        bars: int = 16,
        progression: str = 'classic',
        bars_per_chord: int = 2,
        velocity: int = 100,
        custom_chord_roots: List[int] = None
    ) -> List[BasslineNote]:
        """
        Generate rolling bassline with more scale movement

        Pattern: Root -> 3rd -> 5th -> octave, repeated
        More melodic, moves through the scale
        """
        notes = []
        # Use custom chord roots if provided, otherwise use predefined progression
        if custom_chord_roots:
            progression_notes = custom_chord_roots
        else:
            progression_notes = self.get_progression_notes(progression)
        scale_notes = self.get_scale_notes()

        for bar in range(bars):
            chord_index = (bar // bars_per_chord) % len(progression_notes)
            root = progression_notes[chord_index]

            # Find root in scale, then get 3rd and 5th
            root_idx = scale_notes.index(root % 12 + self.base_midi_note // 12 * 12)
            third = scale_notes[(root_idx + 2) % len(scale_notes)]
            fifth = scale_notes[(root_idx + 4) % len(scale_notes)]

            # Make sure all notes are in bass range
            if third < root:
                third += 12
            if fifth < root:
                fifth += 12

            # Keep third and fifth in proper bass range (max MIDI 60)
            while third > 60:
                third -= 12
            while fifth > 60:
                fifth -= 12

            # Octave jump capped at MIDI 60
            octave_up = min(root + 12, 60)

            beat_offset = bar * 4

            # Rolling pattern with 8th notes - all notes capped at MIDI 60
            pattern = [
                (0.0, root),
                (0.5, min(third, 60)),
                (1.0, min(fifth, 60)),
                (1.5, octave_up),  # Max MIDI 60
                (2.0, min(fifth, 60)),
                (2.5, min(third, 60)),
                (3.0, root),
                (3.5, root),
            ]

            for beat, note in pattern:
                notes.append(BasslineNote(
                    note=note,
                    start_beat=beat_offset + beat,
                    duration=0.25,
                    velocity=velocity
                ))

        return notes

    def generate_pumping_bass(
        self,
        bars: int = 16,
        progression: str = 'classic',
        bars_per_chord: int = 4,
        velocity_pattern: List[int] = None,
        custom_chord_roots: List[int] = None
    ) -> List[BasslineNote]:
        """
        Generate pumping bassline with velocity variations (sidechain effect)

        8th note pattern on root with velocity automation
        """
        if velocity_pattern is None:
            # Default sidechain-like velocity pattern
            velocity_pattern = [100, 70, 85, 70, 100, 70, 85, 70]

        notes = []
        # Use custom chord roots if provided, otherwise use predefined progression
        if custom_chord_roots:
            progression_notes = custom_chord_roots
        else:
            progression_notes = self.get_progression_notes(progression)

        for bar in range(bars):
            chord_index = (bar // bars_per_chord) % len(progression_notes)
            root = progression_notes[chord_index]

            beat_offset = bar * 4

            # 8th notes throughout the bar
            for i in range(8):
                beat = i * 0.5
                velocity = velocity_pattern[i % len(velocity_pattern)]

                notes.append(BasslineNote(
                    note=root,
                    start_beat=beat_offset + beat,
                    duration=0.25,
                    velocity=velocity
                ))

        return notes

    def generate_syncopated_bass(
        self,
        bars: int = 16,
        progression: str = 'classic',
        bars_per_chord: int = 2,
        velocity: int = 100,
        custom_chord_roots: List[int] = None
    ) -> List[BasslineNote]:
        """
        Generate syncopated pattern with rests and varied rhythm

        More sparse, groovy pattern
        """
        notes = []
        # Use custom chord roots if provided, otherwise use predefined progression
        if custom_chord_roots:
            progression_notes = custom_chord_roots
        else:
            progression_notes = self.get_progression_notes(progression)

        for bar in range(bars):
            chord_index = (bar // bars_per_chord) % len(progression_notes)
            root = progression_notes[chord_index]

            # Octave jump capped at MIDI 60
            octave_up = min(root + 12, 60)

            beat_offset = bar * 4

            # Syncopated pattern with deliberate gaps - all notes max MIDI 60
            pattern = [
                (0.0, root),
                (0.75, root),
                (1.5, octave_up),  # Max MIDI 60
                (2.0, root),
                (2.75, root),
                (3.25, root),
                (3.75, octave_up),  # Max MIDI 60
            ]

            for beat, note in pattern:
                notes.append(BasslineNote(
                    note=note,
                    start_beat=beat_offset + beat,
                    duration=0.25,
                    velocity=velocity
                ))

        return notes

    def generate_galloping_bass(
        self,
        bars: int = 16,
        progression: str = 'classic',
        bars_per_chord: int = 2,
        velocity: int = 100,
        custom_chord_roots: List[int] = None
    ) -> List[BasslineNote]:
        """
        Generate galloping trance bassline pattern (like example-bassline3.mid)

        Pattern per bar (triplet gallop feel):
        - Beat 0.50: Root (offbeat start)
        - Beat 1.00: Root (onbeat)
        - Beat 1.50: Root (offbeat)
        - [Rest at beat 2.00]
        - Beat 2.50: Root (offbeat)
        - Beat 3.00: Root (onbeat)
        - Beat 3.50: Root (offbeat)
        - [Rest at beat 4.00]

        Creates "da-dum-dum [rest] da-dum-dum [rest]" gallop feel
        Uses root notes from chord progression
        All notes in MIDI 36-60 (bass octave range)
        """
        notes = []
        # Use custom chord roots if provided, otherwise use predefined progression
        if custom_chord_roots:
            progression_notes = custom_chord_roots
        else:
            progression_notes = self.get_progression_notes(progression)

        for bar in range(bars):
            chord_index = (bar // bars_per_chord) % len(progression_notes)
            root = progression_notes[chord_index]

            beat_offset = bar * 4

            # Galloping pattern - 6 notes per bar (3+3 with rests)
            pattern = [
                (0.50, root),  # Offbeat start
                (1.00, root),  # Onbeat
                (1.50, root),  # Offbeat
                # Rest at 2.00
                (2.50, root),  # Offbeat
                (3.00, root),  # Onbeat
                (3.50, root),  # Offbeat
                # Rest at 4.00 (bar end)
            ]

            for beat, note in pattern:
                notes.append(BasslineNote(
                    note=note,
                    start_beat=beat_offset + beat,
                    duration=0.25,  # 16th note duration
                    velocity=velocity
                ))

        return notes


def generate_bassline(
    root_note: int,
    scale: str,
    style: str = 'offbeat_trance',
    bars: int = 16,
    progression: str = 'classic',
    octave: int = 3,
    **kwargs
) -> List[BasslineNote]:
    """
    Main function to generate a trance bassline in proper bass register

    AUTOMATIC BASS DEPTH:
        - Always generates in PROPER BASS RANGE (MIDI 36-60)
        - C2 (MIDI 36) to C4 (MIDI 60) - perfect for trance bass
        - NO need to prompt "make it deep" - it's ALWAYS deep!
        - Matches your example basslines (MDTM, example-bassline.mid)

    Args:
        root_note: Root note (0-11, where 0=C, 1=C#, etc.)
        scale: Scale type (minor, major, harmonic_minor, etc.)
        style: Bassline style (offbeat_trance, driving_offbeat, rolling, pumping, syncopated)
        bars: Number of bars to generate
        progression: Chord progression type (classic, emotional, uplifting, dark, simple)
        octave: Bass octave (3 = proper bass range) - DO NOT CHANGE
        **kwargs: Additional parameters passed to specific generators

    Returns:
        List of BasslineNote objects in proper bass register
    """
    generator = TranceBassliceGenerator(root_note, scale, octave)

    style_map = {
        'simple_root': generator.generate_simple_root,
        'offbeat_trance': generator.generate_offbeat_trance,
        'driving_offbeat': generator.generate_driving_offbeat,
        'rolling': generator.generate_rolling_bass,
        'pumping': generator.generate_pumping_bass,
        'syncopated': generator.generate_syncopated_bass,
        'galloping': generator.generate_galloping_bass,
    }

    generate_func = style_map.get(style, generator.generate_offbeat_trance)
    return generate_func(bars=bars, progression=progression, **kwargs)
