"""
Convert generated basslines to MIDI files
"""

import mido
from typing import List

try:
    from .bassline_generator import BasslineNote
except ImportError:
    from bassline_generator import BasslineNote


def bassline_to_midi(
    notes: List[BasslineNote],
    output_path: str,
    tempo: int = 138,
    ticks_per_beat: int = 480,
    track_name: str = "BASSLINE"
) -> None:
    """
    Convert a list of BasslineNote objects to a MIDI file

    Args:
        notes: List of BasslineNote objects
        output_path: Path to save the MIDI file
        tempo: BPM (default 138 for trance)
        ticks_per_beat: MIDI resolution (default 480)
        track_name: Name for the MIDI track
    """
    # Create MIDI file
    mid = mido.MidiFile(ticks_per_beat=ticks_per_beat)
    track = mido.MidiTrack()
    mid.tracks.append(track)

    # Set track name
    track.append(mido.MetaMessage('track_name', name=track_name, time=0))

    # Set tempo
    microseconds_per_beat = mido.bpm2tempo(tempo)
    track.append(mido.MetaMessage('set_tempo', tempo=microseconds_per_beat, time=0))

    # Sort notes by start time
    sorted_notes = sorted(notes, key=lambda n: n.start_beat)

    # Convert to MIDI messages
    # We need to track note_on and note_off events separately
    events = []

    for note in sorted_notes:
        start_ticks = int(note.start_beat * ticks_per_beat)
        end_ticks = int((note.start_beat + note.duration) * ticks_per_beat)

        events.append({
            'time': start_ticks,
            'type': 'note_on',
            'note': note.note,
            'velocity': note.velocity
        })

        events.append({
            'time': end_ticks,
            'type': 'note_off',
            'note': note.note,
            'velocity': 0
        })

    # Sort all events by time
    events.sort(key=lambda e: (e['time'], e['type'] == 'note_on'))

    # Convert to delta times and add to track
    current_time = 0
    for event in events:
        delta = event['time'] - current_time

        if event['type'] == 'note_on':
            track.append(mido.Message('note_on',
                                     note=event['note'],
                                     velocity=event['velocity'],
                                     time=delta))
        else:
            track.append(mido.Message('note_off',
                                     note=event['note'],
                                     velocity=0,
                                     time=delta))

        current_time = event['time']

    # Add end of track
    track.append(mido.MetaMessage('end_of_track', time=0))

    # Save file
    mid.save(output_path)
    print(f"Saved bassline MIDI to: {output_path}")


def bassline_notes_to_comfy_format(notes: List[BasslineNote]) -> dict:
    """
    Convert bassline notes to ComfyUI-compatible format

    Returns a dictionary with note data that can be passed through ComfyUI
    """
    return {
        'notes': [
            {
                'note': n.note,
                'start_beat': n.start_beat,
                'duration': n.duration,
                'velocity': n.velocity
            }
            for n in notes
        ],
        'total_beats': max(n.start_beat + n.duration for n in notes) if notes else 0
    }


if __name__ == '__main__':
    # Test the conversion
    try:
        from .bassline_generator import generate_bassline
    except ImportError:
        from bassline_generator import generate_bassline

    # Generate a test bassline in C minor (PROPER BASS RANGE: MIDI 36-60)
    notes = generate_bassline(
        root_note=0,  # C
        scale='minor',
        style='offbeat_trance',
        bars=8,
        progression='classic',
        octave=3  # C2-C3 range (MIDI 36-60) - proper bass depth
    )

    # Save to MIDI
    bassline_to_midi(notes, 'test_bassline_offbeat.mid')

    # Try driving offbeat style
    notes2 = generate_bassline(
        root_note=0,
        scale='minor',
        style='driving_offbeat',
        bars=8,
        progression='classic',
        octave=3  # Always proper bass range
    )

    bassline_to_midi(notes2, 'test_bassline_driving.mid')

    print(f"Generated {len(notes)} notes for offbeat trance (MIDI range: {min(n.note for n in notes)}-{max(n.note for n in notes)})")
    print(f"Generated {len(notes2)} notes for driving offbeat (MIDI range: {min(n.note for n in notes2)}-{max(n.note for n in notes2)})")
