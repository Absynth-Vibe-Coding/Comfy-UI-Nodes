import os
import numpy as np
import soundfile as sf
import dawdreamer as daw
import mido
import torch

class AbsynthVSTNode:
    """Absynth-VST v1.2.7: Load VST instruments and process MIDI input using DawDreamer"""
    
    VERSION = "1.2"
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _default_preset_folder = os.path.join(_script_dir, "presets")
    _default_midi_folder = os.path.join(_script_dir, "midi")
    
    if not os.path.exists(_default_preset_folder):
        os.makedirs(_default_preset_folder)
    if not os.path.exists(_default_midi_folder):
        os.makedirs(_default_midi_folder)
    
    _preset_cache = {}
    _midi_cache = {}
    
    @classmethod
    def INPUT_TYPES(cls):
        presets = cls.scan_presets(cls._default_preset_folder)
        preset_list = ["load preset"] + presets
        midi_files = cls.scan_midi_files(cls._default_midi_folder)
        midi_list = ["select MIDI file"] + midi_files
        
        return {
            "required": {
                "vst_path": ("STRING", {"default": "C:\\Program Files\\Common Files\\VST3\\Serum2.vst3", "multiline": False}),
                "preset": (preset_list, {"default": preset_list[0]}),
                "midi_file": (midi_list, {"default": midi_list[0]}),
                "sample_rate": ("INT", {"default": 48000, "min": 22050, "max": 192000}),
                "buffer_size": ("INT", {"default": 512, "min": 128, "max": 2048, "step": 128}),
                "reverb_tail": ("FLOAT", {"default": 2.0, "min": 0.0, "max": 10.0, "step": 0.1, "display": "slider"}),
                "override_bpm": ("INT", {"default": 0, "min": 0, "max": 300, "step": 1}),
                "output_gain": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 2.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_1": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_1_index": ("INT", {"default": -1, "min": -1, "max": 10000, "step": 1}),
                "parameter_1_name": ("STRING", {"default": "cutoff", "multiline": False}),
                "parameter_2": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_2_index": ("INT", {"default": -1, "min": -1, "max": 10000, "step": 1}),
                "parameter_2_name": ("STRING", {"default": "reverb", "multiline": False}),
                "parameter_3": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_3_index": ("INT", {"default": -1, "min": -1, "max": 10000, "step": 1}),
                "parameter_3_name": ("STRING", {"default": "resonance", "multiline": False}),
                "parameter_4": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_4_index": ("INT", {"default": -1, "min": -1, "max": 10000, "step": 1}),
                "parameter_4_name": ("STRING", {"default": "attack", "multiline": False}),
                "parameter_5": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_5_index": ("INT", {"default": -1, "min": -1, "max": 10000, "step": 1}),
                "parameter_5_name": ("STRING", {"default": "release", "multiline": False}),
                "parameter_6": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_6_index": ("INT", {"default": -1, "min": -1, "max": 10000}),
                "parameter_6_name": ("STRING", {"default": "decay", "multiline": False}),
                "output_path": ("STRING", {"default": "output/vst_audio.wav", "multiline": False})
            },
            "optional": {"midi_path_input": ("STRING", {"default": "", "forceInput": True})}
        }
    
    RETURN_TYPES = ("STRING", "AUDIO", "VST_INFO")
    RETURN_NAMES = ("file_path", "audio", "plugin_info")
    FUNCTION = "process_vst"
    CATEGORY = "absynth-vst"
    BLACKLISTED_VSTS = ['spire', 'omnisphere', 'kontakt', 'battery', 'massive x']
    
    @classmethod
    def scan_presets(cls, folder):
        preset_list = []
        cls._preset_cache = {}
        if not os.path.exists(folder):
            return preset_list
        try:
            for root, dirs, files in os.walk(folder):
                for file in files:
                    if file.lower().endswith('.vstpreset'):
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, folder)
                        cls._preset_cache[rel_path] = full_path
                        preset_list.append(rel_path)
            preset_list.sort()
        except Exception as e:
            print(f"[Absynth-VST] Scan error: {e}")
        return preset_list
    
    @classmethod
    def scan_midi_files(cls, folder):
        midi_list = []
        cls._midi_cache = {}
        if not os.path.exists(folder):
            return midi_list
        try:
            for root, dirs, files in os.walk(folder):
                for file in files:
                    if file.lower().endswith(('.mid', '.midi')):
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, folder)
                        cls._midi_cache[rel_path] = full_path
                        midi_list.append(rel_path)
            midi_list.sort()
        except Exception as e:
            print(f"[Absynth-VST] MIDI scan error: {e}")
        return midi_list
    
    def load_midi_events(self, midi_file, override_bpm=0):
        midi = mido.MidiFile(midi_file)
        events = []
        active_notes = {}
        ticks_per_beat = midi.ticks_per_beat
        original_tempo = 500000
        
        for track in midi.tracks:
            for msg in track:
                if msg.type == 'set_tempo':
                    original_tempo = msg.tempo
                    break
        
        tempo_scale = 1.0
        if override_bpm > 0:
            original_bpm = mido.tempo2bpm(original_tempo)
            tempo_scale = original_bpm / override_bpm
            target_bpm = override_bpm
        else:
            target_bpm = mido.tempo2bpm(original_tempo)
        
        for track in midi.tracks:
            current_time_ticks = 0
            for msg in track:
                current_time_ticks += msg.time
                beats = current_time_ticks / ticks_per_beat
                original_time_seconds = beats * (original_tempo / 1000000.0)
                scaled_time_seconds = original_time_seconds * tempo_scale
                
                if msg.type == 'note_on' and msg.velocity > 0:
                    channel = msg.channel if hasattr(msg, 'channel') else 0
                    note_key = (msg.note, channel)
                    active_notes[note_key] = {
                        'start_time': scaled_time_seconds, 
                        'velocity': msg.velocity,
                        'channel': channel
                    }
                elif msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0):
                    channel = msg.channel if hasattr(msg, 'channel') else 0
                    note_key = (msg.note, channel)
                    if note_key in active_notes:
                        note_info = active_notes[note_key]
                        duration = scaled_time_seconds - note_info['start_time']
                        events.append({
                            'time': note_info['start_time'],
                            'note': msg.note,
                            'velocity': note_info['velocity'],
                            'duration': max(0.1, duration),
                            'channel': note_info['channel']
                        })
                        del active_notes[note_key]
        
        events.sort(key=lambda x: x['time'])
        total_duration = max([e['time'] + e['duration'] for e in events]) if events else 0.0
        
        print(f"[Absynth-VST] Loaded {len(events)} MIDI events")
        if events:
            channels_used = set(e['channel'] for e in events)
            print(f"[Absynth-VST] MIDI channels detected: {sorted(channels_used)}")
        
        return events, total_duration, target_bpm
    
    def process_vst(self, vst_path, preset, midi_file, sample_rate, buffer_size, reverb_tail=2.0, override_bpm=0, output_gain=1.0,
                   parameter_1=-1.0, parameter_1_index=-1, parameter_1_name="cutoff",
                   parameter_2=-1.0, parameter_2_index=-1, parameter_2_name="reverb",
                   parameter_3=-1.0, parameter_3_index=-1, parameter_3_name="resonance",
                   parameter_4=-1.0, parameter_4_index=-1, parameter_4_name="attack",
                   parameter_5=-1.0, parameter_5_index=-1, parameter_5_name="release",
                   parameter_6=-1.0, parameter_6_index=-1, parameter_6_name="decay",
                   output_path="output/vst_audio.wav", midi_path_input=""):
        
        import time
        if not os.path.isabs(output_path):
            comfy_root = os.path.abspath(os.path.join(self._script_dir, '..', '..'))
            output_path = os.path.join(comfy_root, output_path)
        
        if not os.path.exists(vst_path):
            empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
            return (f"Error: VST not found", empty_audio, None)
        
        midi_path = None
        if midi_path_input and midi_path_input.strip():
            midi_path = midi_path_input.strip()
            if not os.path.exists(midi_path):
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Connected MIDI file not found", empty_audio, None)
        else:
            if midi_file == "select MIDI file":
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Please select a MIDI file", empty_audio, None)
            midi_path = self._midi_cache.get(midi_file, "")
            if not midi_path:
                midi_path = midi_file if os.path.isabs(midi_file) else os.path.join(self._default_midi_folder, midi_file)
            if not os.path.exists(midi_path):
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: MIDI file not found", empty_audio, None)
        
        try:
            engine = daw.RenderEngine(sample_rate, buffer_size)
            synth = engine.make_plugin_processor("synth", vst_path)
            
            preset_loaded = False
            if preset != "load preset":
                preset_path = self._preset_cache.get(preset, "")
                if not preset_path:
                    preset_path = os.path.join(self._default_preset_folder, preset)
                
                print(f"[Absynth-VST] Attempting to load preset: {preset}")
                print(f"[Absynth-VST] Preset path: {preset_path}")
                print(f"[Absynth-VST] Preset exists: {os.path.exists(preset_path)}")
                
                if os.path.exists(preset_path):
                    try:
                        synth.load_vst3_preset(preset_path)
                        preset_loaded = True
                        print(f"[Absynth-VST] ✓ Preset loaded successfully")
                    except Exception as e:
                        print(f"[Absynth-VST] ✗ Preset loading failed: {e}")
                        import traceback
                        traceback.print_exc()
                else:
                    print(f"[Absynth-VST] ✗ Preset file not found!")
            else:
                print(f"[Absynth-VST] No preset selected (using plugin defaults)")
            
            plugin_info = {'name': synth.get_name(), 'preset': preset, 'preset_loaded': preset_loaded}
            
            print(f"\n[Absynth-VST] === DIAGNOSTICS ===")
            print(f"[Absynth-VST] Plugin: {synth.get_name()}")
            
            dd_version = "unknown"
            try:
                dd_version = daw.__version__
            except:
                try:
                    import pkg_resources
                    dd_version = pkg_resources.get_distribution("dawdreamer").version
                except:
                    pass
            
            print(f"[Absynth-VST] DawDreamer version: {dd_version}")
            
            methods = [m for m in dir(synth) if not m.startswith('_')]
            midi_methods = [m for m in methods if 'midi' in m.lower()]
            print(f"[Absynth-VST] MIDI methods available: {midi_methods}")
            
            midi_events, midi_duration, actual_bpm = self.load_midi_events(midi_path, override_bpm)
            render_duration = midi_duration + reverb_tail
            
            channels_detected = set(e['channel'] for e in midi_events)
            print(f"[Absynth-VST] MIDI file: {len(midi_events)} events on channels {channels_detected}")
            print(f"[Absynth-VST] Duration: {midi_duration:.2f}s, Render: {render_duration:.2f}s")
            
            plugin_name_lower = synth.get_name().lower()
            is_drum_plugin = any(word in plugin_name_lower for word in ['drum', 'sitala', 'groove', 'battery'])
            has_channel_9 = 9 in channels_detected
            
            midi_loaded = False
            if hasattr(synth, 'load_midi'):
                try:
                    print(f"[Absynth-VST] Attempting load_midi()...")
                    synth.load_midi(midi_path)
                    midi_loaded = True
                    print(f"[Absynth-VST] ✓✓✓ load_midi() SUCCESS!")
                except Exception as e:
                    print(f"[Absynth-VST] ✗ load_midi() failed: {e}")
                    import traceback
                    traceback.print_exc()
            else:
                print(f"[Absynth-VST] ✗ load_midi() method NOT available")
            
            if not midi_loaded:
                print(f"[Absynth-VST] Falling back to add_midi_note()...")
                print(f"[Absynth-VST] ⚠ WARNING: Channel info will be LOST (drums may not work)")
                
                for event in midi_events:
                    synth.add_midi_note(
                        event['note'], 
                        event['velocity'], 
                        event['time'], 
                        event['duration']
                    )
                print(f"[Absynth-VST] Added {len(midi_events)} notes (all on default channel)")
            
            engine.load_graph([(synth, [])])
            print(f"[Absynth-VST] Rendering {render_duration:.2f} seconds...")
            engine.render(render_duration)
            audio_data = engine.get_audio()
            
            print(f"[Absynth-VST] Audio shape: {audio_data.shape}")
            print(f"[Absynth-VST] Audio dtype: {audio_data.dtype}")
            audio_peak = np.max(np.abs(audio_data))
            print(f"[Absynth-VST] Overall audio peak: {audio_peak:.6f}")
            
            if audio_data.shape[0] > 2:
                print(f"[Absynth-VST] Multi-output detected: {audio_data.shape[0]} channels")
                active_channels = []
                for i in range(audio_data.shape[0]):
                    channel_peak = np.max(np.abs(audio_data[i, :]))
                    if channel_peak > 0.0001:
                        active_channels.append((i, channel_peak))
                
                if active_channels:
                    print(f"[Absynth-VST] ✓ Found audio on {len(active_channels)} channels:")
                    for ch, peak in active_channels[:10]:
                        print(f"[Absynth-VST]   Channel {ch}: peak={peak:.6f}")
                else:
                    print(f"[Absynth-VST] ✗ NO audio on ANY channel!")
            
            if audio_peak < 0.0001:
                print(f"[Absynth-VST] ⚠ ⚠ ⚠   WARNING: Audio is SILENT/EMPTY!")
                print(f"[Absynth-VST] Possible causes:")
                
                if is_drum_plugin and has_channel_9:
                    try:
                        if dd_version != "unknown" and dd_version.startswith('0.8'):
                            print(f"[Absynth-VST]   *** MOST LIKELY: DawDreamer 0.8.x cannot send MIDI Channel 10 ***")
                            print(f"[Absynth-VST]   *** Drum plugins REQUIRE Channel 10 to work ***")
                            print(f"[Absynth-VST]   ")
                            print(f"[Absynth-VST]   SOLUTION: Upgrade DawDreamer!")
                            print(f"[Absynth-VST]   Run this command:")
                            print(f"[Absynth-VST]   python -m pip install dawdreamer==0.10.1 --force-reinstall --no-cache-dir")
                            print(f"[Absynth-VST]   ")
                        else:
                            print(f"[Absynth-VST]   - Drum plugin detected but MIDI Channel 10 may not be sent correctly")
                    except:
                        print(f"[Absynth-VST]   - Drum plugin detected, check DawDreamer version")
                else:
                    print(f"[Absynth-VST]   1. Preset not loaded correctly")
                    print(f"[Absynth-VST]   2. Plugin has no samples loaded")
                    print(f"[Absynth-VST]   3. MIDI notes don't match plugin's mapping")
                    print(f"[Absynth-VST]   4. Plugin needs specific initialization")
            else:
                print(f"[Absynth-VST] ✓ Audio contains signal!")
            print(f"[Absynth-VST] === END DIAGNOSTICS ===\n")
            
            if audio_data.shape[0] > 2:
                channel_peaks = [np.max(np.abs(audio_data[i, :])) for i in range(audio_data.shape[0])]
                active_channels = [i for i, peak in enumerate(channel_peaks) if peak > 0.001]
                
                last_two = audio_data[-2:, :]
                if np.max(np.abs(last_two)) > 0.001:
                    stereo_audio = last_two
                elif audio_data.shape[0] >= 2 and np.max(np.abs(audio_data[:2, :])) > 0.001:
                    stereo_audio = audio_data[:2, :]
                elif audio_data.shape[0] >= 4 and np.max(np.abs(audio_data[2:4, :])) > 0.001:
                    stereo_audio = audio_data[2:4, :]
                else:
                    if len(active_channels) > 0:
                        active_audio = audio_data[active_channels, :]
                        left = np.sum(active_audio[0::2, :], axis=0)
                        right = np.sum(active_audio[1::2, :], axis=0)
                        stereo_audio = np.stack([left, right], axis=0)
                    else:
                        stereo_audio = audio_data[:2, :]
                    max_val = np.max(np.abs(stereo_audio))
                    if max_val > 0:
                        stereo_audio = stereo_audio / max_val * 0.8
                audio_data = stereo_audio
            
            if output_gain != 1.0:
                audio_data = audio_data * output_gain
            
            try:
                output_path_abs = os.path.abspath(output_path)
                output_dir = os.path.dirname(output_path_abs)
                if output_dir and not os.path.exists(output_dir):
                    os.makedirs(output_dir, exist_ok=True)
                sf.write(output_path_abs, audio_data.T, sample_rate, subtype='PCM_16', format='WAV')
                output_path = output_path_abs
            except PermissionError:
                import tempfile
                fallback_dir = tempfile.gettempdir()
                fallback_path = os.path.join(fallback_dir, f"absynth_vst_audio_{int(time.time())}.wav")
                sf.write(fallback_path, audio_data.T, sample_rate, subtype='PCM_16', format='WAV')
                output_path = fallback_path
            
            audio_tensor = torch.from_numpy(audio_data).float().unsqueeze(0)
            audio_output = {"waveform": audio_tensor, "sample_rate": sample_rate}
            
            return (output_path, audio_output, plugin_info)
            
        except Exception as e:
            print(f"[Absynth-VST] Error: {str(e)}")
            import traceback
            traceback.print_exc()
            empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
            return (f"Error: {str(e)}", empty_audio, None)


class AbsynthVSTParameterListerNode:
    VERSION = "1.2"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "vst_path": ("STRING", {"default": "C:\\Program Files\\Common Files\\VST3\\Serum2.vst3", "multiline": False}),
                "search_filter": ("STRING", {"default": "", "multiline": False}),
                "sample_rate": ("INT", {"default": 44100, "min": 22050, "max": 192000})
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("parameter_list",)
    FUNCTION = "list_parameters"
    CATEGORY = "absynth-vst"
    OUTPUT_NODE = True
    
    def list_parameters(self, vst_path, search_filter, sample_rate):
        try:
            if not os.path.exists(vst_path):
                return ("Error: VST not found",)
            engine = daw.RenderEngine(sample_rate, 512)
            synth = engine.make_plugin_processor("synth", vst_path)
            param_count = synth.get_plugin_parameter_size()
            param_lines = [f"=== {synth.get_name()} Parameters ===", f"Total: {param_count} parameters\n"]
            search_lower = search_filter.lower().strip()
            matched_count = 0
            for i in range(param_count):
                try:
                    name = synth.get_parameter_name(i)
                    if search_lower and search_lower not in name.lower():
                        continue
                    matched_count += 1
                    value = synth.get_parameter(i)
                    text = synth.get_parameter_text(i)
                    param_lines.append(f"[{i:4d}] {name:50s} = {value:.3f} ({text})")
                except Exception as e:
                    param_lines.append(f"[{i:4d}] Error reading parameter: {e}")
            if search_lower:
                param_lines.append(f"\nMatched {matched_count} parameters with filter '{search_filter}'")
            result = "\n".join(param_lines)
            print(result)
            return (result,)
        except Exception as e:
            error = f"Error listing parameters: {str(e)}"
            print(f"[Absynth-VST] {error}")
            import traceback
            traceback.print_exc()
            return (error,)


class AbsynthMIDICreatorNode:
    VERSION = "1.2"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "notes": ("STRING", {"default": "60,64,67"}),
                "velocities": ("STRING", {"default": "100,100,100"}),
                "durations": ("STRING", {"default": "1.0,1.0,1.0"}),
                "output_path": ("STRING", {"default": "./output/test_midi.mid"})
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("midi_path",)
    FUNCTION = "create_midi"
    CATEGORY = "absynth-vst"
    
    def create_midi(self, notes, velocities, durations, output_path):
        try:
            note_list = [int(n.strip()) for n in notes.split(',')]
            velocity_list = [int(v.strip()) for v in velocities.split(',')]
            duration_list = [float(d.strip()) for d in durations.split(',')]
            mid = mido.MidiFile()
            track = mido.MidiTrack()
            mid.tracks.append(track)
            for note, velocity, duration in zip(note_list, velocity_list, duration_list):
                track.append(mido.Message('note_on', note=note, velocity=velocity, time=0))
                track.append(mido.Message('note_off', note=note, velocity=0, time=int(duration * 480)))
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            mid.save(output_path)
            return (output_path,)
        except Exception as e:
            error = f"Error: {str(e)}"
            print(f"[Absynth-VST] {error}")
            return (error,)


class AbsynthVSTInfoDisplayNode:
    VERSION = "1.2"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"vst_info": ("VST_INFO",)}}
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("info_text",)
    FUNCTION = "display_info"
    CATEGORY = "absynth-vst"
    OUTPUT_NODE = True
    
    def display_info(self, vst_info):
        if not vst_info:
            return ("No VST info available",)
        info_lines = ["=== VST INFO ==="]
        if 'name' in vst_info:
            info_lines.append(f"Plugin: {vst_info['name']}")
        if 'preset' in vst_info:
            info_lines.append(f"Preset: {vst_info['preset']}")
        if 'preset_loaded' in vst_info:
            status = "✓ Loaded" if vst_info['preset_loaded'] else "✗ Not loaded"
            info_lines.append(f"Status: {status}")
        info_text = "\n".join(info_lines)
        return (info_text,)


class AbsynthLLMMIDIGeneratorNode:
    VERSION = "1.2"
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _default_midi_folder = os.path.join(_script_dir, "midi")
    _drums_folder = os.path.join(_default_midi_folder, "drums")
    _synths_folder = os.path.join(_default_midi_folder, "synths")
    
    if not os.path.exists(_drums_folder):
        os.makedirs(_drums_folder)
    if not os.path.exists(_synths_folder):
        os.makedirs(_synths_folder)
    
    @classmethod
    def get_ollama_models(cls):
        try:
            import requests
            response = requests.get("http://localhost:11434/api/tags", timeout=2)
            if response.status_code == 200:
                data = response.json()
                models = [model['name'] for model in data.get('models', [])]
                if models:
                    return sorted(models)
                else:
                    return ["[No models installed]"]
            else:
                return ["[Ollama error]"]
        except requests.exceptions.ConnectionError:
            return ["[Ollama not running]"]
        except ImportError:
            return ["[Install requests: pip install requests]"]
        except Exception as e:
            return ["[Error connecting to Ollama]"]
    
    @classmethod
    def INPUT_TYPES(cls):
        ollama_models = cls.get_ollama_models()
        default_model = ollama_models[0] if ollama_models else "[No models available]"
        if "gpt-oss:20b" in ollama_models:
            default_model = "gpt-oss:20b"
        
        return {
            "required": {
                "prompt": ("STRING", {"default": "Melodic trance pattern in E minor", "multiline": True}),
                "api_key": ("STRING", {"default": "your-api-key-here", "multiline": False}),
                "llm_provider": (["local", "ollama", "openai", "anthropic"], {"default": "ollama"}),
                "model": (ollama_models, {"default": default_model}),
                "temperature": ("FLOAT", {"default": 1.2, "min": 0.0, "max": 2.0, "step": 0.1}),
                "seed": ("INT", {"default": -1, "min": -1, "max": 999999, "step": 1}),
                "bpm": ("INT", {"default": 128, "min": 60, "max": 200, "step": 1}),
                "duration": ("INT", {"default": 30, "min": 4, "max": 60, "step": 1}),
                "output_filename": ("STRING", {"default": "llm_generated", "multiline": False})
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("midi_path",)
    FUNCTION = "generate_midi"
    CATEGORY = "absynth-vst"
    
    def _extract_key_from_prompt(self, prompt):
        import re
        prompt_lower = prompt.lower()
        major_keys = ['c major', 'd major', 'e major', 'f major', 'g major', 'a major', 'b major']
        minor_keys = ['c minor', 'd minor', 'e minor', 'f minor', 'g minor', 'a minor', 'b minor']
        for key in major_keys + minor_keys:
            if key in prompt_lower:
                note = key.split()[0].replace('#', 'sharp').replace('b', 'flat')
                mode = 'maj' if 'major' in key else 'min'
                return f"{note.capitalize()}{mode}"
        return "Cmaj"
    
    def _call_ollama(self, model, system_prompt, user_prompt, temperature):
        try:
            import requests
            url = "http://localhost:11434/api/generate"
            full_prompt = f"{system_prompt}\n\nUser request: {user_prompt}"
            
            payload = {
                "model": model,
                "prompt": full_prompt,
                "stream": False,
                "options": {"temperature": temperature}
            }
            
            print(f"[Absynth-VST] Sending request to Ollama...")
            response = requests.post(url, json=payload, timeout=120)
            
            if response.status_code == 200:
                result = response.json()
                return result.get("response", "")
            else:
                print(f"[Absynth-VST] ✗ Ollama error: {response.status_code}")
                return None
                
        except requests.exceptions.ConnectionError:
            print("[Absynth-VST] ✗ Ollama not running!")
            return None
        except ImportError:
            print("[Absynth-VST] ✗ Requests library not installed")
            return None
        except Exception as e:
            print(f"[Absynth-VST] ✗ Ollama error: {e}")
            return None
    
    def _call_openai(self, api_key, model, system_prompt, user_prompt, temperature):
        try:
            import openai
            client = openai.OpenAI(api_key=api_key)
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=temperature
            )
            return response.choices[0].message.content
        except ImportError:
            print("[Absynth-VST] ✗ OpenAI library not installed")
            return None
        except Exception as e:
            print(f"[Absynth-VST] ✗ OpenAI error: {e}")
            return None
    
    def _call_anthropic(self, api_key, model, system_prompt, user_prompt, temperature):
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=api_key)
            message = client.messages.create(
                model=model,
                max_tokens=2048,
                temperature=temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}]
            )
            return message.content[0].text
        except ImportError:
            print("[Absynth-VST] ✗ Anthropic library not installed")
            return None
        except Exception as e:
            print(f"[Absynth-VST] ✗ Anthropic error: {e}")
            return None
    
    def _execute_generated_code(self, llm_response, filename, bpm, duration, target_folder):
        """Execute the Python code generated by LLM - KEEP IT SIMPLE!"""
        try:
            import time
            code = llm_response.strip()
            
            import re
            
            code = re.sub(r'<think>.*?</think>', '', code, flags=re.DOTALL | re.IGNORECASE)
            code = re.sub(r'<thinking>.*?</thinking>', '', code, flags=re.DOTALL | re.IGNORECASE)
            
            code_blocks = []
            python_blocks = re.findall(r'```python\s*(.*?)```', code, re.DOTALL)
            if python_blocks:
                code_blocks.extend(python_blocks)
            else:
                generic_blocks = re.findall(r'```\s*(.*?)```', code, re.DOTALL)
                if generic_blocks:
                    code_blocks.extend(generic_blocks)
            
            if code_blocks:
                code = max(code_blocks, key=len).strip()
            
            code = code.replace('```python', '').replace('```', '').strip()
            
            if not any(keyword in code for keyword in ['import', 'from', 'def', 'class', '=']):
                print(f"[Absynth-VST] ✗ Invalid code structure")
                return False, "Invalid code structure"
            
            safe_globals = {'__builtins__': __builtins__, 'print': print}
            import math
            from midiutil import MIDIFile
            safe_globals['MIDIFile'] = MIDIFile
            safe_globals['math'] = math
            safe_globals['filename'] = filename
            
            original_dir = os.getcwd()
            os.chdir(target_folder)
            
            try:
                exec(code, safe_globals)
                
                if os.path.exists(filename):
                    print(f"[Absynth-VST] ✓ MIDI file created successfully")
                    return True, None
                else:
                    mid_files = [f for f in os.listdir('.') if f.endswith('.mid')]
                    if mid_files:
                        newest = max(mid_files, key=os.path.getctime)
                        os.rename(newest, filename)
                        print(f"[Absynth-VST] ✓ MIDI file created (renamed)")
                        return True, None
                    else:
                        print(f"[Absynth-VST] ✗ No MIDI file created")
                        return False, "Code executed but no MIDI file was created"
            finally:
                os.chdir(original_dir)
            
        except IndexError as e:
            error_msg = str(e)
            if 'pop from empty list' in error_msg:
                print(f"[Absynth-VST] ✗ Error: Overlapping notes in MIDI")
                return False, "Overlapping notes detected (tell model to use shorter durations)"
            else:
                print(f"[Absynth-VST] ✗ IndexError: {error_msg}")
                return False, f"IndexError: {error_msg}"
        except Exception as e:
            error_msg = str(e)
            print(f"[Absynth-VST] ✗ Error: {error_msg}")
            return False, f"Execution error: {error_msg}"
    
    def generate_midi(self, prompt, api_key, llm_provider, model, temperature, seed, bpm, duration, output_filename):
        try:
            import random
            import time
            import re
            
            if seed == -1:
                actual_seed = random.randint(0, 999999)
            else:
                actual_seed = seed
            random.seed(actual_seed)
            
            prompt_lower = prompt.lower()
            
            synth_keywords = [
                'arpeggio', 'chord', 'melody', 'melodic', 'harmonic', 'harmony',
                'bass line', 'bassline', 'lead', 'pad', 'progression',
                'scale', 'note', 'key', 'major', 'minor',
                'synth', 'piano', 'strings', 'brass', 'ambient'
            ]
            is_synth = any(keyword in prompt_lower for keyword in synth_keywords)
            
            drum_keywords = [
                'drum', 'kick', 'snare', 'beat', 'percussion',
                'hi-hat', 'hihat', 'cymbal', 'tom',
                'clap', 'rim', 'cowbell'
            ]
            
            genre_drum_keywords = [
                'hip hop', 'hip-hop', 'hiphop', 'rap',
                'boom bap', 'boombap', 'trap',
                'house', 'techno', 'trance', 'edm',
                'groove', 'rhythm', 'pattern',
                'verse', 'hook', 'breakdown', 'drop'
            ]
            
            if is_synth:
                is_drums = False
            else:
                is_drums = any(keyword in prompt_lower for keyword in drum_keywords + genre_drum_keywords)
            
            if is_drums:
                key_info = "drums"
                target_folder = self._drums_folder
            else:
                key_info = self._extract_key_from_prompt(prompt)
                target_folder = self._synths_folder
            
            timestamp = int(time.time())
            clean_name = re.sub(r'[^\w\-]', '_', output_filename)
            filename = f"{clean_name}_{key_info}_{bpm}bpm_{actual_seed}_{timestamp}.mid"
            output_path = os.path.join(target_folder, filename)
            
            print(f"")
            print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
            print(f"[Absynth-VST] ║       LLM MIDI GENERATOR v1.2         ║")
            print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
            print(f"[Absynth-VST] Provider: {llm_provider}, BPM: {bpm}")
            print(f"[Absynth-VST] Detection: Synth keywords found={is_synth}, Drum keywords found={is_drums}")
            print(f"[Absynth-VST] Type: {'DRUMS' if is_drums else 'SYNTH'} → Folder: {os.path.basename(target_folder)}/")
            print(f"[Absynth-VST] Output: {filename}")
            print(f"")
            
            if llm_provider == "local":
                print(f"")
                print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
                print(f"[Absynth-VST] ║  🏠 LOCAL GENERATION MODE             ║")
                print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
                print(f"")
                return (self._create_fallback_midi(prompt, filename, bpm, duration, key_info, target_folder),)
            
            beats_per_second = bpm / 60.0
            total_beats = duration * beats_per_second
            total_bars = int(total_beats / 4)
            
            system_prompt = f"""You are a Python MIDI code generator with music theory knowledge. Generate Python code using the midiutil library.

REQUIREMENTS:
- Use 'from midiutil import MIDIFile'
- Set BPM to {bpm}
- Create music lasting approximately {duration} seconds
- Save file as '{filename}'
- Use the user's musical description to create appropriate melodies/basslines/patterns
- Output ONLY the Python code, no explanations

MUSIC THEORY - CIRCLE OF FIFTHS:
When creating chord progressions, use the Circle of Fifths for harmonic movement:
- E minor: Em - Am - Bm - Em (i - iv - v - i)
- E minor: Em - C - G - D (i - VI - III - VII)
- E minor: Em - D - C - Bm (i - VII - VI - v)

CRITICAL: Bass notes must follow chord roots!
- If chord is Em (E-G-B), bass plays E (note 40 or 52)
- If chord is Am (A-C-E), bass plays A (note 45 or 57)
- If chord is C (C-E-G), bass plays C (note 36 or 48)

EXAMPLE CODE STRUCTURE WITH PROPER HARMONY:
```python
from midiutil import MIDIFile
import math

bpm = {bpm}
duration_seconds = {duration}

midi = MIDIFile(2)  # 2 tracks: melody + bass
melody_track = 0
bass_track = 1
channel = 0

midi.addTempo(melody_track, 0, bpm)
midi.addTempo(bass_track, 0, bpm)
midi.addProgramChange(melody_track, channel, 0, 81)  # Synth Lead
midi.addProgramChange(bass_track, channel, 0, 38)    # Synth Bass

# E minor chord progression (Circle of Fifths)
# Chord: Em (E-G-B), Bass: E
# Chord: Am (A-C-E), Bass: A
# Chord: Bm (B-D-F#), Bass: B
# Chord: Em (E-G-B), Bass: E

chord_progression = [
    {{'name': 'Em', 'notes': [64, 67, 71], 'bass': 52}},  # E3, G3, B3 | E2
    {{'name': 'Am', 'notes': [69, 72, 76], 'bass': 57}},  # A3, C4, E4 | A2
    {{'name': 'Bm', 'notes': [71, 74, 78], 'bass': 59}},  # B3, D4, F#4 | B2
    {{'name': 'Em', 'notes': [64, 67, 71], 'bass': 52}}   # E3, G3, B3 | E2
]

time = 0.0
bar_length = 4.0  # 4 beats per bar

for chord in chord_progression:
    # Play chord (melody track)
    for note in chord['notes']:
        midi.addNote(melody_track, channel, note, time, bar_length, 80)
    
    # Play bass note (bass track) - MATCHES chord root!
    midi.addNote(bass_track, channel, chord['bass'], time, bar_length, 100)
    
    time += bar_length

with open("{filename}", "wb") as f:
    midi.writeFile(f)
```

IMPORTANT RULES FOR HARMONY:
1. Bass note MUST be the root of the current chord
2. Use Circle of Fifths for progressions (moves by 4ths/5ths sound good)
3. In E minor: Use notes E, F#, G, A, B, C, D (natural minor scale)
4. Common E minor chords: Em (i), Am (iv), Bm (v), C (VI), D (VII), G (III)

Generate creative, HARMONICALLY CORRECT code based on: {prompt}"""
            
            llm_response = None
            
            if llm_provider == "ollama":
                print(f"[Absynth-VST] 🤖 Calling Ollama: {model}")
                llm_response = self._call_ollama(model, system_prompt, prompt, temperature)
            elif llm_provider == "openai":
                print(f"[Absynth-VST] 🤖 Calling OpenAI: {model}")
                llm_response = self._call_openai(api_key, model, system_prompt, prompt, temperature)
            elif llm_provider == "anthropic":
                print(f"[Absynth-VST] 🤖 Calling Anthropic: {model}")
                llm_response = self._call_anthropic(api_key, model, system_prompt, prompt, temperature)
            
            if llm_response:
                print(f"[Absynth-VST] ✓ Response received, processing...")
                success, error_msg = self._execute_generated_code(llm_response, filename, bpm, duration, target_folder)
                
                if success and os.path.exists(output_path):
                    print(f"")
                    print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
                    print(f"[Absynth-VST] ║  🤖 LLM GENERATION: SUCCESS ✓         ║")
                    print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
                    print(f"[Absynth-VST] Model: {model}")
                    print(f"[Absynth-VST] File: {filename}")
                    print(f"[Absynth-VST] ✓✓✓ MIDI created: {output_path}")
                    print(f"")
                    return (output_path,)
                else:
                    print(f"")
                    print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
                    print(f"[Absynth-VST] ║  ⚠ LLM Failed - Using Local Fallback  ║")
                    print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
                    if error_msg:
                        print(f"[Absynth-VST] Error: {error_msg}")
                    print(f"[Absynth-VST] Tip: Try a different model or simpler prompt")
                    print(f"")
                    return (self._create_fallback_midi(prompt, filename, bpm, duration, key_info, target_folder),)
            else:
                print(f"")
                print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
                print(f"[Absynth-VST] ║  ✗ LLM Error - Using Local Fallback   ║")
                print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
                print(f"")
                return (self._create_fallback_midi(prompt, filename, bpm, duration, key_info, target_folder),)
            
        except Exception as e:
            print(f"")
            print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
            print(f"[Absynth-VST] ║  ✗ ERROR - Using Local Fallback       ║")
            print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
            print(f"[Absynth-VST] Error: {str(e)}")
            print(f"")
            drum_keywords = [
                'drum', 'kick', 'snare', 'beat', 'percussion',
                'hip hop', 'hip-hop', 'hiphop', 'rap',
                'boom bap', 'boombap', 'trap',
                'house', 'techno', 'trance', 'edm',
                'groove', 'rhythm', 'pattern',
                'verse', 'hook', 'breakdown', 'drop',
                'hi-hat', 'hihat', 'cymbal', 'tom',
                'clap', 'rim', 'cowbell'
            ]
            is_drums_fallback = any(keyword in prompt.lower() for keyword in drum_keywords)
            fallback_folder = self._drums_folder if is_drums_fallback else self._synths_folder
            return (self._create_fallback_midi(prompt, f"error_{bpm}bpm.mid", bpm, duration, "Cmaj", fallback_folder),)
    
    def _create_fallback_midi(self, prompt, filename, bpm, duration, key_info, target_folder):
        import random
        import time
        random.seed(int(time.time() * 1000000) % 999999 + random.randint(0, 999999))
        
        output_path = os.path.join(target_folder, filename)
        prompt_lower = prompt.lower()
        
        genre_keywords = {
            'trance': ['trance', 'uplifting', 'psy', 'progressive'],
            'techno': ['techno', 'minimal', 'industrial'],
            'house': ['house', 'deep', 'funky'],
            'boombap': ['boom', 'bap', 'hip hop', 'rap'],
            'lofi': ['lofi', 'lo-fi', 'chill', 'jazzy'],
            'trap': ['trap', '808', 'triplet'],
            'electro': ['electro', 'synth', '80s']
        }
        
        detected_genre = 'house'
        for genre, keywords in genre_keywords.items():
            if any(kw in prompt_lower for kw in keywords):
                detected_genre = genre
                break
        
        synth_keywords = [
            'arpeggio', 'chord', 'melody', 'melodic', 'harmonic', 'harmony',
            'bass line', 'bassline', 'lead', 'pad', 'progression',
            'scale', 'note', 'key', 'major', 'minor',
            'synth', 'piano', 'strings', 'brass', 'ambient'
        ]
        is_synth = any(keyword in prompt_lower for keyword in synth_keywords)
        
        drum_keywords = [
            'drum', 'kick', 'snare', 'beat', 'percussion',
            'hi-hat', 'hihat', 'cymbal', 'tom', 'clap', 'rim', 'cowbell',
            'hip hop', 'hip-hop', 'hiphop', 'rap',
            'boom bap', 'boombap', 'trap',
            'house', 'techno', 'trance', 'edm',
            'groove', 'rhythm', 'pattern',
            'verse', 'hook', 'breakdown', 'drop'
        ]
        
        if is_synth:
            is_drums = False
        elif key_info == "drums":
            is_drums = True
        else:
            is_drums = any(keyword in prompt_lower for keyword in drum_keywords)
        
        print(f"[Absynth-VST] Generating {detected_genre.upper()} pattern...")
        print(f"[Absynth-VST] Detection: Synth={is_synth}, Key={key_info}")
        print(f"[Absynth-VST] Type: {'DRUMS' if is_drums else 'SYNTH'} → Folder: {os.path.basename(target_folder)}/")
        
        try:
            mid = mido.MidiFile(type=0, ticks_per_beat=480)
            track = mido.MidiTrack()
            mid.tracks.append(track)
            
            track.append(mido.MetaMessage('track_name', name=detected_genre.title(), time=0))
            tempo = mido.bpm2tempo(bpm)
            track.append(mido.MetaMessage('set_tempo', tempo=tempo, time=0))
            track.append(mido.MetaMessage('time_signature', numerator=4, denominator=4, time=0))
            
            beats_total = (bpm / 60.0) * duration
            bars = int(beats_total / 4)
            events = []
            
            if is_drums or key_info == "drums":
                pattern_variation = random.randint(1, 3)
                
                if detected_genre == 'trance':
                    print(f"[Absynth-VST] Trance Pattern Variation #{pattern_variation}")
                    
                    for bar in range(bars):
                        time = bar * 4.0
                        
                        for beat in [0, 1, 2, 3]:
                            vel = random.randint(108, 115)
                            events.append({'time': time + beat, 'note': 36, 'duration': 0.25, 'velocity': vel, 'channel': 9})
                        
                        events.append({'time': time + 1, 'note': 38, 'duration': 0.25, 'velocity': random.randint(98, 105), 'channel': 9})
                        events.append({'time': time + 3, 'note': 38, 'duration': 0.25, 'velocity': random.randint(98, 105), 'channel': 9})
                        
                        for i in range(16):
                            vel = 85 if i % 4 == 0 else 65
                            vel += random.randint(-3, 3)
                            events.append({'time': time + i * 0.25, 'note': 42, 'duration': 0.15, 'velocity': vel, 'channel': 9})
                        
                        open_times = [0.5, 1.5, 2.5, 3.5]
                        for ot in open_times:
                            events.append({'time': time + ot, 'note': 46, 'duration': 0.35, 'velocity': random.randint(68, 75), 'channel': 9})
                        
                        if bar in [0, 16, 32, 48]:
                            events.append({'time': time, 'note': 49, 'duration': 2.0, 'velocity': random.randint(100, 108), 'channel': 9})
                
                elif detected_genre == 'boombap':
                    print(f"[Absynth-VST] Boom Bap Pattern Variation #{pattern_variation}")
                    
                    for bar in range(bars):
                        time = bar * 4.0
                        
                        if pattern_variation == 1:
                            kick_times = [0, 0.25, 0.5, 1.0, 1.5, 2.0, 2.25, 3.0, 3.5]
                        elif pattern_variation == 2:
                            kick_times = [0, 0.5, 1.0, 1.25, 2.0, 2.25, 2.5, 3.0, 3.25]
                        else:
                            kick_times = [0, 0.25, 1.0, 2.0, 2.25, 3.0, 3.5]
                        
                        for kt in kick_times:
                            events.append({'time': time + kt, 'note': 36, 'duration': 0.2, 'velocity': random.randint(120, 127), 'channel': 9})
                        
                        events.append({'time': time + 1, 'note': 38, 'duration': 0.25, 'velocity': random.randint(118, 125), 'channel': 9})
                        events.append({'time': time + 3, 'note': 38, 'duration': 0.25, 'velocity': random.randint(118, 125), 'channel': 9})
                        
                        if bar % 2 == 1:
                            ghost_times = [1.5, 2.75]
                            for gt in ghost_times:
                                events.append({'time': time + gt, 'note': 38, 'duration': 0.1, 'velocity': random.randint(40, 50), 'channel': 9})
                        
                        for sixteenth in range(16):
                            pos = sixteenth * 0.25
                            vel = random.randint(72, 78) if sixteenth % 4 == 0 else random.randint(60, 67)
                            events.append({'time': time + pos, 'note': 42, 'duration': 0.12, 'velocity': vel, 'channel': 9})
                
                else:
                    for bar in range(bars):
                        time = bar * 4.0
                        for beat in [0, 1, 2, 3]:
                            events.append({'time': time + beat, 'note': 36, 'duration': 0.25, 'velocity': random.randint(100, 108), 'channel': 9})
                        events.append({'time': time + 1, 'note': 38, 'duration': 0.25, 'velocity': random.randint(88, 95), 'channel': 9})
                        events.append({'time': time + 3, 'note': 38, 'duration': 0.25, 'velocity': random.randint(88, 95), 'channel': 9})
                        for eighth in [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]:
                            vel = random.randint(65, 75)
                            events.append({'time': time + eighth, 'note': 42, 'duration': 0.25, 'velocity': vel, 'channel': 9})
            
            else:
                scale = [0, 2, 4, 5, 7, 9, 11]
                root = 60
                current_time = 0.0
                while current_time < beats_total:
                    degree = random.choice([0, 2, 4, 5, 7])
                    note = root + scale[degree % len(scale)]
                    velocity = random.randint(80, 110)
                    events.append({'time': current_time, 'note': note, 'duration': 0.5, 'velocity': velocity, 'channel': 0})
                    current_time += 0.5
            
            midi_events = []
            for event in events:
                time_ticks = int(event['time'] * 480)
                midi_events.append({'time': time_ticks, 'type': 'note_on', 'note': event['note'], 'velocity': event['velocity'], 'channel': event['channel']})
                midi_events.append({'time': time_ticks + int(event['duration'] * 480), 'type': 'note_off', 'note': event['note'], 'velocity': 0, 'channel': event['channel']})
            
            midi_events.sort(key=lambda x: (x['time'], x['type'] == 'note_off'))
            
            last_time = 0
            for event in midi_events:
                delta = event['time'] - last_time
                if event['type'] == 'note_on':
                    track.append(mido.Message('note_on', note=event['note'], velocity=event['velocity'], channel=event['channel'], time=delta))
                else:
                    track.append(mido.Message('note_off', note=event['note'], velocity=0, channel=event['channel'], time=delta))
                last_time = event['time']
            
            track.append(mido.MetaMessage('end_of_track', time=0))
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            mid.save(output_path)
            
            print(f"")
            print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
            print(f"[Absynth-VST] ║      LOCAL GENERATION: SUCCESS ✓      ║")
            print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
            print(f"[Absynth-VST] Genre: {detected_genre.upper()}")
            print(f"[Absynth-VST] Events: {len(events)}")
            print(f"[Absynth-VST] File: {os.path.basename(output_path)}")
            print(f"")
            return output_path
            
        except Exception as e:
            print(f"[Absynth-VST] ✗ Error: {e}")
            import traceback
            traceback.print_exc()
            return output_path


class AbsynthVSTMixerNode:
    """4-Channel Mixer with Faders and Pan Controls (Like Cubase)"""
    
    VERSION = "1.0"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                # Track Names
                "track_1_name": ("STRING", {"default": "Track 1", "multiline": False}),
                "track_2_name": ("STRING", {"default": "Track 2", "multiline": False}),
                "track_3_name": ("STRING", {"default": "Track 3", "multiline": False}),
                "track_4_name": ("STRING", {"default": "Track 4", "multiline": False}),
                
                # Fader 1 (von unten nach oben = 0.0 bis 2.0)
                "track_1_fader": ("FLOAT", {
                    "default": 0.8, 
                    "min": 0.0, 
                    "max": 2.0, 
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "track_1_pan": ("FLOAT", {
                    "default": 0.0,  # -1.0 = Links, 0.0 = Center, 1.0 = Rechts
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                
                # Fader 2
                "track_2_fader": ("FLOAT", {
                    "default": 0.8,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "track_2_pan": ("FLOAT", {
                    "default": 0.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                
                # Fader 3
                "track_3_fader": ("FLOAT", {
                    "default": 0.8,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "track_3_pan": ("FLOAT", {
                    "default": 0.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                
                # Fader 4
                "track_4_fader": ("FLOAT", {
                    "default": 0.8,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "track_4_pan": ("FLOAT", {
                    "default": 0.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                
                # Master Fader
                "master_fader": ("FLOAT", {
                    "default": 1.0,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
            },
            "optional": {
                "audio_1": ("AUDIO",),
                "audio_2": ("AUDIO",),
                "audio_3": ("AUDIO",),
                "audio_4": ("AUDIO",),
            }
        }
    
    RETURN_TYPES = ("AUDIO", "AUDIO", "AUDIO", "AUDIO", "AUDIO")
    RETURN_NAMES = ("track_1_out", "track_2_out", "track_3_out", "track_4_out", "mix_output")
    FUNCTION = "mix_audio"
    CATEGORY = "absynth-vst"
    
    def apply_pan(self, audio_stereo, pan_value):
        """
        Wendet Panning auf Stereo-Audio an.
        pan_value: -1.0 (Links), 0.0 (Center), 1.0 (Rechts)
        """
        # Constant Power Panning (wie in Cubase)
        import math
        
        # Pan von -1.0...1.0 zu 0...π/2 konvertieren
        pan_angle = (pan_value + 1.0) * (math.pi / 4.0)
        
        left_gain = math.cos(pan_angle)
        right_gain = math.sin(pan_angle)
        
        # Auf beide Kanäle anwenden
        panned_audio = audio_stereo.clone()
        panned_audio[:, 0, :] *= left_gain   # Linker Kanal
        panned_audio[:, 1, :] *= right_gain  # Rechter Kanal
        
        return panned_audio
    
    def process_track(self, audio_input, fader, pan):
        """Verarbeitet einen Track mit Fader und Pan"""
        if audio_input is None:
            # Leeres Audio zurückgeben wenn kein Input
            return {"waveform": torch.zeros((1, 2, 1)), "sample_rate": 48000}
        
        waveform = audio_input["waveform"]
        sample_rate = audio_input["sample_rate"]
        
        # Sicherstellen dass wir Stereo haben
        if waveform.shape[1] == 1:
            # Mono zu Stereo
            waveform = torch.cat([waveform, waveform], dim=1)
        
        # Fader anwenden (Lautstärke)
        waveform = waveform * fader
        
        # Pan anwenden
        waveform = self.apply_pan(waveform, pan)
        
        return {"waveform": waveform, "sample_rate": sample_rate}
    
    def mix_audio(self, track_1_name, track_2_name, track_3_name, track_4_name,
                  track_1_fader, track_1_pan, track_2_fader, track_2_pan,
                  track_3_fader, track_3_pan, track_4_fader, track_4_pan,
                  master_fader, audio_1=None, audio_2=None, audio_3=None, audio_4=None):
        
        print(f"[Absynth-VST Mixer] ═══════════════════════════════")
        print(f"[Absynth-VST Mixer] 🎚️  4-CHANNEL MIXER v1.0")
        print(f"[Absynth-VST Mixer] ═══════════════════════════════")
        
        # Verarbeite jeden Track
        track_1_processed = self.process_track(audio_1, track_1_fader, track_1_pan)
        track_2_processed = self.process_track(audio_2, track_2_fader, track_2_pan)
        track_3_processed = self.process_track(audio_3, track_3_fader, track_3_pan)
        track_4_processed = self.process_track(audio_4, track_4_fader, track_4_pan)
        
        # Benutze die Custom Track-Namen in den Logs
        def format_pan(pan):
            if pan < -0.01:
                return f"L{abs(pan):.2f}"
            elif pan > 0.01:
                return f"R{pan:.2f}"
            else:
                return "C"
        
        print(f"[Absynth-VST Mixer] 🎵 {track_1_name:12s}: Vol={track_1_fader:.2f}, Pan={format_pan(track_1_pan)}")
        print(f"[Absynth-VST Mixer] 🎵 {track_2_name:12s}: Vol={track_2_fader:.2f}, Pan={format_pan(track_2_pan)}")
        print(f"[Absynth-VST Mixer] 🎵 {track_3_name:12s}: Vol={track_3_fader:.2f}, Pan={format_pan(track_3_pan)}")
        print(f"[Absynth-VST Mixer] 🎵 {track_4_name:12s}: Vol={track_4_fader:.2f}, Pan={format_pan(track_4_pan)}")
        print(f"[Absynth-VST Mixer] 🎛️  Master Fader: {master_fader:.2f}")
        
        # Finde die längste Audio-Datei für Mix-Länge
        max_length = 1
        sample_rate = 48000
        
        tracks = [track_1_processed, track_2_processed, track_3_processed, track_4_processed]
        valid_tracks = [t for t in tracks if t["waveform"].shape[2] > 1]
        
        if valid_tracks:
            max_length = max(t["waveform"].shape[2] for t in valid_tracks)
            sample_rate = valid_tracks[0]["sample_rate"]
        
        # Erstelle Mix-Buffer
        mix_buffer = torch.zeros((1, 2, max_length))
        
        # Summiere alle Tracks
        for track in tracks:
            waveform = track["waveform"]
            track_length = waveform.shape[2]
            
            if track_length > 1:  # Nur wenn Audio vorhanden
                # Auf Mix-Länge padden wenn nötig
                if track_length < max_length:
                    padding = torch.zeros((1, 2, max_length - track_length))
                    waveform = torch.cat([waveform, padding], dim=2)
                
                mix_buffer += waveform
        
        # Master Fader auf Mix anwenden
        mix_buffer = mix_buffer * master_fader
        
        # Limitiere auf -1.0 bis +1.0 (verhindert Clipping)
        mix_buffer = torch.clamp(mix_buffer, -1.0, 1.0)
        
        mix_output = {"waveform": mix_buffer, "sample_rate": sample_rate}
        
        # Audio-Peak-Analyse
        if max_length > 1:
            peak = torch.max(torch.abs(mix_buffer)).item()
            print(f"[Absynth-VST Mixer] Mix Peak: {peak:.3f} ({peak*100:.1f}%)")
            if peak > 0.95:
                print(f"[Absynth-VST Mixer] ⚠️  WARNING: Signal is close to clipping!")
        
        print(f"[Absynth-VST Mixer] ═══════════════════════════════")
        
        return (track_1_processed, track_2_processed, track_3_processed, track_4_processed, mix_output)


NODE_CLASS_MAPPINGS = {
    "AbsynthVST": AbsynthVSTNode,
    "AbsynthVSTParameterLister": AbsynthVSTParameterListerNode,
    "AbsynthMIDICreator": AbsynthMIDICreatorNode,
    "AbsynthVSTInfoDisplay": AbsynthVSTInfoDisplayNode,
    "AbsynthLLMMIDIGenerator": AbsynthLLMMIDIGeneratorNode,
    "AbsynthVSTMixer": AbsynthVSTMixerNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AbsynthVST": "Absynth-VST Player v1.2",
    "AbsynthVSTParameterLister": "Absynth-VST Parameter Lister v1.2",
    "AbsynthMIDICreator": "Absynth-VST MIDI Creator v1.2",
    "AbsynthVSTInfoDisplay": "Absynth-VST Info Display v1.2",
    "AbsynthLLMMIDIGenerator": "Absynth-VST LLM MIDI Generator v1.2",
    "AbsynthVSTMixer": "Absynth-VST Mixer v1.0 🎚️"
}