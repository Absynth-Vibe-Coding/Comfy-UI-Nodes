import os
import numpy as np
import soundfile as sf
import dawdreamer as daw
import mido
import torch

class AbsynthVSTNode:
    """Absynth-VST v1.2.5: Load VST instruments and process MIDI input using DawDreamer"""

    VERSION = "1.2.5"
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _default_preset_folder = os.path.join(_script_dir, "presets")
    _default_midi_folder = os.path.join(_script_dir, "midi")
    
    if not os.path.exists(_default_preset_folder):
        os.makedirs(_default_preset_folder)
    if not os.path.exists(_default_midi_folder):
        os.makedirs(_default_midi_folder)
    
    _preset_cache = {}
    _midi_cache = {}
    
    @classmethod
    def INPUT_TYPES(cls):
        presets = cls.scan_presets(cls._default_preset_folder)
        preset_list = ["load preset"] + presets
        midi_files = cls.scan_midi_files(cls._default_midi_folder)
        midi_list = ["select MIDI file"] + midi_files
        
        return {
            "required": {
                "vst_path": ("STRING", {"default": "C:\\Program Files\\Common Files\\VST3\\Serum2.vst3", "multiline": False}),
                "preset": (preset_list, {"default": preset_list[0]}),
                "midi_file": (midi_list, {"default": midi_list[0]}),
                "sample_rate": ("INT", {"default": 48000, "min": 22050, "max": 192000}),
                "buffer_size": ("INT", {"default": 512, "min": 128, "max": 2048, "step": 128}),
                "reverb_tail": ("FLOAT", {"default": 2.0, "min": 0.0, "max": 10.0, "step": 0.1, "display": "slider"}),
                "override_bpm": ("INT", {"default": 0, "min": 0, "max": 300, "step": 1}),
                "output_gain": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 2.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_1": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_1_index": ("INT", {"default": -1, "min": -1, "max": 10000, "step": 1}),
                "parameter_1_name": ("STRING", {"default": "cutoff", "multiline": False}),
                "parameter_2": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_2_index": ("INT", {"default": -1, "min": -1, "max": 10000, "step": 1}),
                "parameter_2_name": ("STRING", {"default": "reverb", "multiline": False}),
                "parameter_3": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_3_index": ("INT", {"default": -1, "min": -1, "max": 10000, "step": 1}),
                "parameter_3_name": ("STRING", {"default": "resonance", "multiline": False}),
                "parameter_4": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_4_index": ("INT", {"default": -1, "min": -1, "max": 10000, "step": 1}),
                "parameter_4_name": ("STRING", {"default": "attack", "multiline": False}),
                "parameter_5": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_5_index": ("INT", {"default": -1, "min": -1, "max": 10000, "step": 1}),
                "parameter_5_name": ("STRING", {"default": "release", "multiline": False}),
                "parameter_6": ("FLOAT", {"default": -1.0, "min": -1.0, "max": 1.0, "step": 0.01, "display": "slider", "round": 0.01}),
                "parameter_6_index": ("INT", {"default": -1, "min": -1, "max": 10000}),
                "parameter_6_name": ("STRING", {"default": "decay", "multiline": False}),
                "output_path": ("STRING", {"default": "output/vst_audio.wav", "multiline": False})
            },
            "optional": {"midi_path_input": ("STRING", {"default": "", "forceInput": True})}
        }
    
    RETURN_TYPES = ("STRING", "AUDIO", "VST_INFO")
    RETURN_NAMES = ("file_path", "audio", "plugin_info")
    FUNCTION = "process_vst"
    CATEGORY = "absynth-vst"
    BLACKLISTED_VSTS = ['spire', 'omnisphere', 'kontakt', 'battery', 'massive x']
    
    @classmethod
    def scan_presets(cls, folder):
        preset_list = []
        cls._preset_cache = {}
        if not os.path.exists(folder):
            return preset_list
        try:
            for root, dirs, files in os.walk(folder):
                for file in files:
                    if file.lower().endswith('.vstpreset'):
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, folder)
                        cls._preset_cache[rel_path] = full_path
                        preset_list.append(rel_path)
            preset_list.sort()
        except Exception as e:
            print(f"[Absynth-VST] Scan error: {e}")
        return preset_list
    
    @classmethod
    def scan_midi_files(cls, folder):
        midi_list = []
        cls._midi_cache = {}
        if not os.path.exists(folder):
            return midi_list
        try:
            for root, dirs, files in os.walk(folder):
                for file in files:
                    if file.lower().endswith(('.mid', '.midi')):
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, folder)
                        cls._midi_cache[rel_path] = full_path
                        midi_list.append(rel_path)
            midi_list.sort()
        except Exception as e:
            print(f"[Absynth-VST] MIDI scan error: {e}")
        return midi_list
    
    def load_midi_events(self, midi_file, override_bpm=0):
        midi = mido.MidiFile(midi_file)
        events = []
        active_notes = {}
        ticks_per_beat = midi.ticks_per_beat
        original_tempo = 500000
        
        for track in midi.tracks:
            for msg in track:
                if msg.type == 'set_tempo':
                    original_tempo = msg.tempo
                    break
        
        tempo_scale = 1.0
        if override_bpm > 0:
            original_bpm = mido.tempo2bpm(original_tempo)
            tempo_scale = original_bpm / override_bpm
            target_bpm = override_bpm
        else:
            target_bpm = mido.tempo2bpm(original_tempo)
        
        for track in midi.tracks:
            current_time_ticks = 0
            for msg in track:
                current_time_ticks += msg.time
                beats = current_time_ticks / ticks_per_beat
                original_time_seconds = beats * (original_tempo / 1000000.0)
                scaled_time_seconds = original_time_seconds * tempo_scale
                
                if msg.type == 'note_on' and msg.velocity > 0:
                    channel = msg.channel if hasattr(msg, 'channel') else 0
                    note_key = (msg.note, channel)
                    active_notes[note_key] = {
                        'start_time': scaled_time_seconds, 
                        'velocity': msg.velocity,
                        'channel': channel
                    }
                elif msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0):
                    channel = msg.channel if hasattr(msg, 'channel') else 0
                    note_key = (msg.note, channel)
                    if note_key in active_notes:
                        note_info = active_notes[note_key]
                        duration = scaled_time_seconds - note_info['start_time']
                        events.append({
                            'time': note_info['start_time'],
                            'note': msg.note,
                            'velocity': note_info['velocity'],
                            'duration': max(0.1, duration),
                            'channel': note_info['channel']
                        })
                        del active_notes[note_key]
        
        events.sort(key=lambda x: x['time'])
        total_duration = max([e['time'] + e['duration'] for e in events]) if events else 0.0
        
        print(f"[Absynth-VST] Loaded {len(events)} MIDI events")
        if events:
            channels_used = set(e['channel'] for e in events)
            print(f"[Absynth-VST] MIDI channels detected: {sorted(channels_used)}")
        
        return events, total_duration, target_bpm
    
    def process_vst(self, vst_path, preset, midi_file, sample_rate, buffer_size, reverb_tail=2.0, override_bpm=0, output_gain=1.0,
                   parameter_1=-1.0, parameter_1_index=-1, parameter_1_name="cutoff",
                   parameter_2=-1.0, parameter_2_index=-1, parameter_2_name="reverb",
                   parameter_3=-1.0, parameter_3_index=-1, parameter_3_name="resonance",
                   parameter_4=-1.0, parameter_4_index=-1, parameter_4_name="attack",
                   parameter_5=-1.0, parameter_5_index=-1, parameter_5_name="release",
                   parameter_6=-1.0, parameter_6_index=-1, parameter_6_name="decay",
                   output_path="output/vst_audio.wav", midi_path_input=""):
        
        import time
        if not os.path.isabs(output_path):
            comfy_root = os.path.abspath(os.path.join(self._script_dir, '..', '..'))
            output_path = os.path.join(comfy_root, output_path)
        
        if not os.path.exists(vst_path):
            empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
            return (f"Error: VST not found", empty_audio, None)
        
        midi_path = None
        if midi_path_input and midi_path_input.strip():
            midi_path = midi_path_input.strip()
            if not os.path.exists(midi_path):
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Connected MIDI file not found", empty_audio, None)
        else:
            if midi_file == "select MIDI file":
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: Please select a MIDI file", empty_audio, None)
            midi_path = self._midi_cache.get(midi_file, "")
            if not midi_path:
                midi_path = midi_file if os.path.isabs(midi_file) else os.path.join(self._default_midi_folder, midi_file)
            if not os.path.exists(midi_path):
                empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
                return ("Error: MIDI file not found", empty_audio, None)
        
        try:
            engine = daw.RenderEngine(sample_rate, buffer_size)
            synth = engine.make_plugin_processor("synth", vst_path)
            
            preset_loaded = False
            if preset != "load preset":
                preset_path = self._preset_cache.get(preset, "")
                if not preset_path:
                    preset_path = os.path.join(self._default_preset_folder, preset)
                
                print(f"[Absynth-VST] Attempting to load preset: {preset}")
                print(f"[Absynth-VST] Preset path: {preset_path}")
                print(f"[Absynth-VST] Preset exists: {os.path.exists(preset_path)}")
                
                if os.path.exists(preset_path):
                    try:
                        synth.load_vst3_preset(preset_path)
                        preset_loaded = True
                        print(f"[Absynth-VST] ✓ Preset loaded successfully")
                    except Exception as e:
                        print(f"[Absynth-VST] ✗ Preset loading failed: {e}")
                        import traceback
                        traceback.print_exc()
                else:
                    print(f"[Absynth-VST] ✗ Preset file not found!")
            else:
                print(f"[Absynth-VST] No preset selected (using plugin defaults)")
            
            plugin_info = {'name': synth.get_name(), 'preset': preset, 'preset_loaded': preset_loaded}
            
            print(f"\n[Absynth-VST] === DIAGNOSTICS ===")
            print(f"[Absynth-VST] Plugin: {synth.get_name()}")
            
            dd_version = "unknown"
            try:
                dd_version = daw.__version__
            except:
                try:
                    import pkg_resources
                    dd_version = pkg_resources.get_distribution("dawdreamer").version
                except:
                    pass
            
            print(f"[Absynth-VST] DawDreamer version: {dd_version}")
            
            methods = [m for m in dir(synth) if not m.startswith('_')]
            midi_methods = [m for m in methods if 'midi' in m.lower()]
            print(f"[Absynth-VST] MIDI methods available: {midi_methods}")
            
            midi_events, midi_duration, actual_bpm = self.load_midi_events(midi_path, override_bpm)
            render_duration = midi_duration + reverb_tail
            
            channels_detected = set(e['channel'] for e in midi_events)
            print(f"[Absynth-VST] MIDI file: {len(midi_events)} events on channels {channels_detected}")
            print(f"[Absynth-VST] Duration: {midi_duration:.2f}s, Render: {render_duration:.2f}s")
            
            plugin_name_lower = synth.get_name().lower()
            is_drum_plugin = any(word in plugin_name_lower for word in ['drum', 'sitala', 'groove', 'battery'])
            has_channel_9 = 9 in channels_detected
            
            midi_loaded = False
            if hasattr(synth, 'load_midi'):
                try:
                    print(f"[Absynth-VST] Attempting load_midi()...")
                    synth.load_midi(midi_path)
                    midi_loaded = True
                    print(f"[Absynth-VST] ✓✓✓ load_midi() SUCCESS!")
                except Exception as e:
                    print(f"[Absynth-VST] ✗ load_midi() failed: {e}")
                    import traceback
                    traceback.print_exc()
            else:
                print(f"[Absynth-VST] ✗ load_midi() method NOT available")
            
            if not midi_loaded:
                print(f"[Absynth-VST] Falling back to add_midi_note()...")
                print(f"[Absynth-VST] ⚠ WARNING: Channel info will be LOST (drums may not work)")
                
                for event in midi_events:
                    synth.add_midi_note(
                        event['note'], 
                        event['velocity'], 
                        event['time'], 
                        event['duration']
                    )
                print(f"[Absynth-VST] Added {len(midi_events)} notes (all on default channel)")
            
            engine.load_graph([(synth, [])])
            print(f"[Absynth-VST] Rendering {render_duration:.2f} seconds...")
            engine.render(render_duration)
            audio_data = engine.get_audio()
            
            print(f"[Absynth-VST] Audio shape: {audio_data.shape}")
            print(f"[Absynth-VST] Audio dtype: {audio_data.dtype}")
            audio_peak = np.max(np.abs(audio_data))
            print(f"[Absynth-VST] Overall audio peak: {audio_peak:.6f}")
            
            if audio_data.shape[0] > 2:
                print(f"[Absynth-VST] Multi-output detected: {audio_data.shape[0]} channels")
                active_channels = []
                for i in range(audio_data.shape[0]):
                    channel_peak = np.max(np.abs(audio_data[i, :]))
                    if channel_peak > 0.0001:
                        active_channels.append((i, channel_peak))
                
                if active_channels:
                    print(f"[Absynth-VST] ✓ Found audio on {len(active_channels)} channels:")
                    for ch, peak in active_channels[:10]:
                        print(f"[Absynth-VST]   Channel {ch}: peak={peak:.6f}")
                else:
                    print(f"[Absynth-VST] ✗ NO audio on ANY channel!")
            
            if audio_peak < 0.0001:
                print(f"[Absynth-VST] ⚠ ⚠ ⚠   WARNING: Audio is SILENT/EMPTY!")
                print(f"[Absynth-VST] Possible causes:")
                
                if is_drum_plugin and has_channel_9:
                    try:
                        if dd_version != "unknown" and dd_version.startswith('0.8'):
                            print(f"[Absynth-VST]   *** MOST LIKELY: DawDreamer 0.8.x cannot send MIDI Channel 10 ***")
                            print(f"[Absynth-VST]   *** Drum plugins REQUIRE Channel 10 to work ***")
                            print(f"[Absynth-VST]   ")
                            print(f"[Absynth-VST]   SOLUTION: Upgrade DawDreamer!")
                            print(f"[Absynth-VST]   Run this command:")
                            print(f"[Absynth-VST]   python -m pip install dawdreamer==0.10.1 --force-reinstall --no-cache-dir")
                            print(f"[Absynth-VST]   ")
                        else:
                            print(f"[Absynth-VST]   - Drum plugin detected but MIDI Channel 10 may not be sent correctly")
                    except:
                        print(f"[Absynth-VST]   - Drum plugin detected, check DawDreamer version")
                else:
                    print(f"[Absynth-VST]   1. Preset not loaded correctly")
                    print(f"[Absynth-VST]   2. Plugin has no samples loaded")
                    print(f"[Absynth-VST]   3. MIDI notes don't match plugin's mapping")
                    print(f"[Absynth-VST]   4. Plugin needs specific initialization")
            else:
                print(f"[Absynth-VST] ✓ Audio contains signal!")
            print(f"[Absynth-VST] === END DIAGNOSTICS ===\n")
            
            if audio_data.shape[0] > 2:
                channel_peaks = [np.max(np.abs(audio_data[i, :])) for i in range(audio_data.shape[0])]
                active_channels = [i for i, peak in enumerate(channel_peaks) if peak > 0.001]
                
                last_two = audio_data[-2:, :]
                if np.max(np.abs(last_two)) > 0.001:
                    stereo_audio = last_two
                elif audio_data.shape[0] >= 2 and np.max(np.abs(audio_data[:2, :])) > 0.001:
                    stereo_audio = audio_data[:2, :]
                elif audio_data.shape[0] >= 4 and np.max(np.abs(audio_data[2:4, :])) > 0.001:
                    stereo_audio = audio_data[2:4, :]
                else:
                    if len(active_channels) > 0:
                        active_audio = audio_data[active_channels, :]
                        left = np.sum(active_audio[0::2, :], axis=0)
                        right = np.sum(active_audio[1::2, :], axis=0)
                        stereo_audio = np.stack([left, right], axis=0)
                    else:
                        stereo_audio = audio_data[:2, :]
                    max_val = np.max(np.abs(stereo_audio))
                    if max_val > 0:
                        stereo_audio = stereo_audio / max_val * 0.8
                audio_data = stereo_audio
            
            if output_gain != 1.0:
                audio_data = audio_data * output_gain
            
            try:
                output_path_abs = os.path.abspath(output_path)
                output_dir = os.path.dirname(output_path_abs)
                if output_dir and not os.path.exists(output_dir):
                    os.makedirs(output_dir, exist_ok=True)
                sf.write(output_path_abs, audio_data.T, sample_rate, subtype='PCM_16', format='WAV')
                output_path = output_path_abs
            except PermissionError:
                import tempfile
                fallback_dir = tempfile.gettempdir()
                fallback_path = os.path.join(fallback_dir, f"absynth_vst_audio_{int(time.time())}.wav")
                sf.write(fallback_path, audio_data.T, sample_rate, subtype='PCM_16', format='WAV')
                output_path = fallback_path
            
            audio_tensor = torch.from_numpy(audio_data).float().unsqueeze(0)
            audio_output = {"waveform": audio_tensor, "sample_rate": sample_rate}
            
            return (output_path, audio_output, plugin_info)
            
        except Exception as e:
            print(f"[Absynth-VST] Error: {str(e)}")
            import traceback
            traceback.print_exc()
            empty_audio = {"waveform": torch.zeros((1, 2, 1)), "sample_rate": sample_rate}
            return (f"Error: {str(e)}", empty_audio, None)


class AbsynthVSTParameterListerNode:
    VERSION = "1.2.5"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "vst_path": ("STRING", {"default": "C:\\Program Files\\Common Files\\VST3\\Serum2.vst3", "multiline": False}),
                "search_filter": ("STRING", {"default": "", "multiline": False}),
                "sample_rate": ("INT", {"default": 44100, "min": 22050, "max": 192000})
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("parameter_list",)
    FUNCTION = "list_parameters"
    CATEGORY = "absynth-vst"
    OUTPUT_NODE = True
    
    def list_parameters(self, vst_path, search_filter, sample_rate):
        try:
            if not os.path.exists(vst_path):
                return ("Error: VST not found",)
            engine = daw.RenderEngine(sample_rate, 512)
            synth = engine.make_plugin_processor("synth", vst_path)
            param_count = synth.get_plugin_parameter_size()
            param_lines = [f"=== {synth.get_name()} Parameters ===", f"Total: {param_count} parameters\n"]
            search_lower = search_filter.lower().strip()
            matched_count = 0
            for i in range(param_count):
                try:
                    name = synth.get_parameter_name(i)
                    if search_lower and search_lower not in name.lower():
                        continue
                    matched_count += 1
                    value = synth.get_parameter(i)
                    text = synth.get_parameter_text(i)
                    param_lines.append(f"[{i:4d}] {name:50s} = {value:.3f} ({text})")
                except Exception as e:
                    param_lines.append(f"[{i:4d}] Error reading parameter: {e}")
            if search_lower:
                param_lines.append(f"\nMatched {matched_count} parameters with filter '{search_filter}'")
            result = "\n".join(param_lines)
            print(result)
            return (result,)
        except Exception as e:
            error = f"Error listing parameters: {str(e)}"
            print(f"[Absynth-VST] {error}")
            import traceback
            traceback.print_exc()
            return (error,)


class AbsynthMIDICreatorNode:
    VERSION = "1.2.5"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "notes": ("STRING", {"default": "60,64,67"}),
                "velocities": ("STRING", {"default": "100,100,100"}),
                "durations": ("STRING", {"default": "1.0,1.0,1.0"}),
                "output_path": ("STRING", {"default": "./output/test_midi.mid"})
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("midi_path",)
    FUNCTION = "create_midi"
    CATEGORY = "absynth-vst"
    
    def create_midi(self, notes, velocities, durations, output_path):
        try:
            note_list = [int(n.strip()) for n in notes.split(',')]
            velocity_list = [int(v.strip()) for v in velocities.split(',')]
            duration_list = [float(d.strip()) for d in durations.split(',')]
            mid = mido.MidiFile()
            track = mido.MidiTrack()
            mid.tracks.append(track)
            for note, velocity, duration in zip(note_list, velocity_list, duration_list):
                track.append(mido.Message('note_on', note=note, velocity=velocity, time=0))
                track.append(mido.Message('note_off', note=note, velocity=0, time=int(duration * 480)))
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            mid.save(output_path)
            return (output_path,)
        except Exception as e:
            error = f"Error: {str(e)}"
            print(f"[Absynth-VST] {error}")
            return (error,)


class AbsynthVSTInfoDisplayNode:
    VERSION = "1.2.5"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"vst_info": ("VST_INFO",)}}
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("info_text",)
    FUNCTION = "display_info"
    CATEGORY = "absynth-vst"
    OUTPUT_NODE = True
    
    def display_info(self, vst_info):
        if not vst_info:
            return ("No VST info available",)
        info_lines = ["=== VST INFO ==="]
        if 'name' in vst_info:
            info_lines.append(f"Plugin: {vst_info['name']}")
        if 'preset' in vst_info:
            info_lines.append(f"Preset: {vst_info['preset']}")
        if 'preset_loaded' in vst_info:
            status = "✓ Loaded" if vst_info['preset_loaded'] else "✗ Not loaded"
            info_lines.append(f"Status: {status}")
        info_text = "\n".join(info_lines)
        return (info_text,)


class AbsynthLLMMIDIGeneratorNode:
    VERSION = "1.3.1"
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _default_midi_folder = os.path.join(_script_dir, "midi")
    _drums_folder = os.path.join(_default_midi_folder, "drums")
    _synths_folder = os.path.join(_default_midi_folder, "synths")
    
    if not os.path.exists(_drums_folder):
        os.makedirs(_drums_folder)
    if not os.path.exists(_synths_folder):
        os.makedirs(_synths_folder)
    
    @classmethod
    def get_ollama_models(cls):
        try:
            import requests
            response = requests.get("http://localhost:11434/api/tags", timeout=2)
            if response.status_code == 200:
                data = response.json()
                models = [model['name'] for model in data.get('models', [])]
                if models:
                    return sorted(models)
                else:
                    return ["[No models installed]"]
            else:
                return ["[Ollama error]"]
        except requests.exceptions.ConnectionError:
            return ["[Ollama not running]"]
        except ImportError:
            return ["[Install requests: pip install requests]"]
        except Exception as e:
            return ["[Error connecting to Ollama]"]
    
    @classmethod
    def INPUT_TYPES(cls):
        ollama_models = cls.get_ollama_models()
        default_model = ollama_models[0] if ollama_models else "[No models available]"
        if "gpt-oss:20b" in ollama_models:
            default_model = "gpt-oss:20b"
        
        return {
            "required": {
                "prompt": ("STRING", {"default": "Melodic trance pattern in E minor", "multiline": True}),
                "api_key": ("STRING", {"default": "your-api-key-here", "multiline": False}),
                "llm_provider": (["local", "ollama", "openai", "anthropic"], {"default": "ollama"}),
                "model": (ollama_models, {"default": default_model}),
                "temperature": ("FLOAT", {"default": 1.2, "min": 0.0, "max": 2.0, "step": 0.1}),
                "seed": ("INT", {"default": -1, "min": -1, "max": 999999, "step": 1}),
                "bpm": ("INT", {"default": 128, "min": 60, "max": 200, "step": 1}),
                "duration": ("INT", {"default": 30, "min": 4, "max": 60, "step": 1}),
                "output_filename": ("STRING", {"default": "llm_generated", "multiline": False})
            }
        }
    
    RETURN_TYPES = ("STRING", "STRING")
    RETURN_NAMES = ("midi_path", "status")
    FUNCTION = "generate_midi"
    CATEGORY = "absynth-vst"
    
    def _extract_key_from_prompt(self, prompt):
        import re
        prompt_lower = prompt.lower()
        major_keys = ['c major', 'd major', 'e major', 'f major', 'g major', 'a major', 'b major']
        minor_keys = ['c minor', 'd minor', 'e minor', 'f minor', 'g minor', 'a minor', 'b minor']
        for key in major_keys + minor_keys:
            if key in prompt_lower:
                note = key.split()[0].replace('#', 'sharp').replace('b', 'flat')
                mode = 'maj' if 'major' in key else 'min'
                return f"{note.capitalize()}{mode}"
        return "Cmaj"
    
    def _call_ollama(self, model, system_prompt, user_prompt, temperature):
        try:
            import requests
            url = "http://localhost:11434/api/generate"
            full_prompt = f"{system_prompt}\n\nUser request: {user_prompt}"
            
            payload = {
                "model": model,
                "prompt": full_prompt,
                "stream": False,
                "options": {"temperature": temperature}
            }
            
            print(f"[Absynth-VST] Sending request to Ollama...")
            response = requests.post(url, json=payload, timeout=120)
            
            if response.status_code == 200:
                result = response.json()
                return result.get("response", "")
            else:
                print(f"[Absynth-VST] ✗ Ollama error: {response.status_code}")
                return None
                
        except requests.exceptions.ConnectionError:
            print("[Absynth-VST] ✗ Ollama not running!")
            return None
        except ImportError:
            print("[Absynth-VST] ✗ Requests library not installed")
            return None
        except Exception as e:
            print(f"[Absynth-VST] ✗ Ollama error: {e}")
            return None
    
    def _call_openai(self, api_key, model, system_prompt, user_prompt, temperature):
        try:
            import openai
            client = openai.OpenAI(api_key=api_key)
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=temperature
            )
            return response.choices[0].message.content
        except ImportError:
            print("[Absynth-VST] ✗ OpenAI library not installed")
            return None
        except Exception as e:
            print(f"[Absynth-VST] ✗ OpenAI error: {e}")
            return None
    
    def _call_anthropic(self, api_key, model, system_prompt, user_prompt, temperature):
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=api_key)
            message = client.messages.create(
                model=model,
                max_tokens=2048,
                temperature=temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}]
            )
            return message.content[0].text
        except ImportError:
            print("[Absynth-VST] ✗ Anthropic library not installed")
            return None
        except Exception as e:
            print(f"[Absynth-VST] ✗ Anthropic error: {e}")
            return None
    
    def _execute_generated_code(self, llm_response, filename, bpm, duration, target_folder):
        """Execute the Python code generated by LLM - KEEP IT SIMPLE!"""
        try:
            import time
            code = llm_response.strip()
            
            import re
            
            code = re.sub(r'<think>.*?</think>', '', code, flags=re.DOTALL | re.IGNORECASE)
            code = re.sub(r'<thinking>.*?</thinking>', '', code, flags=re.DOTALL | re.IGNORECASE)
            
            code_blocks = []
            python_blocks = re.findall(r'```python\s*(.*?)```', code, re.DOTALL)
            if python_blocks:
                code_blocks.extend(python_blocks)
            else:
                generic_blocks = re.findall(r'```\s*(.*?)```', code, re.DOTALL)
                if generic_blocks:
                    code_blocks.extend(generic_blocks)
            
            if code_blocks:
                code = max(code_blocks, key=len).strip()
            
            code = code.replace('```python', '').replace('```', '').strip()
            
            if not any(keyword in code for keyword in ['import', 'from', 'def', 'class', '=']):
                print(f"[Absynth-VST] ✗ Invalid code structure")
                return False, "Invalid code structure"
            
            safe_globals = {'__builtins__': __builtins__, 'print': print}
            import math
            from midiutil import MIDIFile
            safe_globals['MIDIFile'] = MIDIFile
            safe_globals['math'] = math
            safe_globals['filename'] = filename
            
            original_dir = os.getcwd()
            os.chdir(target_folder)
            
            try:
                exec(code, safe_globals)
                
                if os.path.exists(filename):
                    print(f"[Absynth-VST] ✓ MIDI file created successfully")
                    return True, None
                else:
                    mid_files = [f for f in os.listdir('.') if f.endswith('.mid')]
                    if mid_files:
                        newest = max(mid_files, key=os.path.getctime)
                        os.rename(newest, filename)
                        print(f"[Absynth-VST] ✓ MIDI file created (renamed)")
                        return True, None
                    else:
                        print(f"[Absynth-VST] ✗ No MIDI file created")
                        return False, "Code executed but no MIDI file was created"
            finally:
                os.chdir(original_dir)
            
        except IndexError as e:
            error_msg = str(e)
            if 'pop from empty list' in error_msg:
                print(f"[Absynth-VST] ✗ Error: Overlapping notes in MIDI")
                return False, "Overlapping notes detected (tell model to use shorter durations)"
            else:
                print(f"[Absynth-VST] ✗ IndexError: {error_msg}")
                return False, f"IndexError: {error_msg}"
        except Exception as e:
            error_msg = str(e)
            print(f"[Absynth-VST] ✗ Error: {error_msg}")
            return False, f"Execution error: {error_msg}"
    
    def generate_midi(self, prompt, api_key, llm_provider, model, temperature, seed, bpm, duration, output_filename):
        try:
            import random
            import time
            import re
            
            if seed == -1:
                actual_seed = random.randint(0, 999999)
            else:
                actual_seed = seed
            random.seed(actual_seed)
            
            prompt_lower = prompt.lower()
            
            synth_keywords = [
                'arpeggio', 'chord', 'melody', 'melodic', 'harmonic', 'harmony',
                'bass line', 'bassline', 'lead', 'pad', 'progression',
                'scale', 'note', 'key', 'major', 'minor',
                'synth', 'piano', 'strings', 'brass', 'ambient'
            ]
            is_synth = any(keyword in prompt_lower for keyword in synth_keywords)
            
            drum_keywords = [
                'drum', 'kick', 'snare', 'beat', 'percussion',
                'hi-hat', 'hihat', 'cymbal', 'tom',
                'clap', 'rim', 'cowbell'
            ]
            
            genre_drum_keywords = [
                'hip hop', 'hip-hop', 'hiphop', 'rap',
                'boom bap', 'boombap', 'trap',
                'house', 'techno', 'trance', 'edm',
                'groove', 'rhythm', 'pattern',
                'verse', 'hook', 'breakdown', 'drop'
            ]
            
            if is_synth:
                is_drums = False
            else:
                is_drums = any(keyword in prompt_lower for keyword in drum_keywords + genre_drum_keywords)
            
            if is_drums:
                key_info = "drums"
                target_folder = self._drums_folder
            else:
                key_info = self._extract_key_from_prompt(prompt)
                target_folder = self._synths_folder
            
            timestamp = int(time.time())
            clean_name = re.sub(r'[^\w\-]', '_', output_filename)
            filename = f"{clean_name}_{key_info}_{bpm}bpm_{actual_seed}_{timestamp}.mid"
            output_path = os.path.join(target_folder, filename)
            
            print(f"")
            print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
            print(f"[Absynth-VST] ║     LLM MIDI GENERATOR v1.3.1         ║")
            print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
            print(f"[Absynth-VST] Provider: {llm_provider}, BPM: {bpm}")
            print(f"[Absynth-VST] Detection: Synth keywords found={is_synth}, Drum keywords found={is_drums}")
            print(f"[Absynth-VST] Type: {'DRUMS' if is_drums else 'SYNTH'} → Folder: {os.path.basename(target_folder)}/")
            print(f"[Absynth-VST] Output: {filename}")
            print(f"")
            
            if llm_provider == "local":
                print(f"")
                print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
                print(f"[Absynth-VST] ║  🏠 LOCAL GENERATION MODE             ║")
                print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
                print(f"[Absynth-VST] Seed: {actual_seed}")
                print(f"")
                midi_path = self._create_fallback_midi(prompt, filename, bpm, duration, key_info, target_folder, seed=actual_seed)
                return (midi_path, "SUCCESS:LOCAL")
            
            beats_per_second = bpm / 60.0
            total_beats = duration * beats_per_second
            total_bars = int(total_beats / 4)

            # Create different prompts for drums vs melodies
            if is_drums:
                system_prompt = f"""You are a Python MIDI drum pattern generator. Generate Python code using the midiutil library.

REQUIREMENTS:
- Use 'from midiutil import MIDIFile'
- Use 'import random' and add random.seed({actual_seed})
- Set BPM to {bpm}
- DURATION: {duration} seconds = {int(total_bars)} bars (MUST generate this many bars!)
- Save file as '{filename}'
- Output ONLY the Python code, no explanations

CRITICAL - TRANCE/HOUSE/TECHNO DRUMS:
- Four-to-the-floor: Kick drum on EVERY beat (1, 2, 3, 4)
- NO syncopation, NO variations - just straight beats!
- Kick: Note 36, plays on beats 1, 2, 3, 4 (every beat!)
- Hi-Hat: Note 42 (closed) or 46 (open), plays on 8ths or 16ths
- Clap/Snare: Note 38 (snare) or 39 (clap), plays on beats 2 and 4
- Keep it SIMPLE and STEADY

GM DRUM NOTES (General MIDI Standard):
Kick: 36 | Snare: 38 | Clap: 39 | Closed Hi-Hat: 42 | Open Hi-Hat: 46

EXAMPLE - Simple 4-to-the-Floor Pattern:
```python
from midiutil import MIDIFile
import random

random.seed({actual_seed})

midi = MIDIFile(1)
track = 0
channel = 9  # Channel 10 (9 in 0-indexed) for drums

midi.addTempo(track, 0, {bpm})

time = 0.0
beat_length = 1.0  # Quarter note

# Calculate bars needed: {duration}s at {bpm} BPM = {int(total_bars)} bars
num_bars = {int(total_bars)}

# IMPORTANT: Loop for EXACTLY num_bars to match duration!
for bar in range(num_bars):
    # Kick on EVERY beat (1, 2, 3, 4)
    for beat in range(4):
        midi.addNote(track, channel, 36, time + beat, beat_length, 100)

    # Hi-hat on every 8th note
    for eighth in range(8):
        midi.addNote(track, channel, 42, time + eighth * 0.5, 0.5, 80)

    # Snare/Clap on beats 2 and 4
    midi.addNote(track, channel, 38, time + 1.0, beat_length, 90)
    midi.addNote(track, channel, 38, time + 3.0, beat_length, 90)

    time += 4.0  # Move to next bar

with open("{filename}", "wb") as f:
    midi.writeFile(f)
```

KEY RULES FOR DRUMS:
1. MUST generate {int(total_bars)} bars to match {duration} seconds!
2. Kick drum on EVERY beat (no variations!)
3. Channel 9 for drums (MIDI standard)
4. Keep patterns simple and steady
5. Four-to-the-floor = kick on 1, 2, 3, 4

Generate simple, STEADY drum pattern ({int(total_bars)} bars) for: {prompt}"""
            else:
                system_prompt = f"""You are a Python MIDI code generator with music theory knowledge. Generate Python code using the midiutil library.

REQUIREMENTS:
- Use 'from midiutil import MIDIFile'
- Use 'import random' and add random.seed({actual_seed})  ← USE THIS TO CREATE VARIATION!
- Set BPM to {bpm}
- DURATION: {duration} seconds = {int(total_bars)} bars (MUST generate this many bars!)
- Save file as '{filename}'
- Output ONLY the Python code, no explanations

CRITICAL - CREATE DIFFERENT MELODIES EACH TIME:
- Use random.seed({actual_seed}) to pick DIFFERENT starting notes each run
- Use random.choice() to select from chord notes
- Vary rhythm patterns (don't always use same note lengths)
- Start melodies on DIFFERENT chord tones (not always the root)
- Mix ascending, descending, and jumping patterns

MELODY RULE - STAY IN HARMONY:
- Melodies MUST use notes FROM the current chord (chord tones)
- Em chord [64,67,71] → melody picks from E(64), G(67), B(71) + octaves
- Am chord [69,72,76] → melody picks from A(69), C(72), E(76) + octaves
- Bm chord [71,74,78] → melody picks from B(71), D(74), F#(78) + octaves
- This keeps melodies harmonically correct!

CHORD PROGRESSIONS (Circle of Fifths):
E minor: Em-Am-Bm-Em, Em-C-G-D, Em-D-C-Bm
D minor: Dm-Gm-Am-Dm, Dm-Am-Bb-F
C major: C-F-G-C, C-G-Am-F, C-Am-F-G

CHORD NOTE VALUES:
Em: [64,67,71] bass: 52 | Am: [69,72,76] bass: 57 | Bm: [71,74,78] bass: 59
C: [60,64,67] bass: 48 | G: [67,71,74] bass: 55 | D: [62,66,69] bass: 50
Dm: [62,65,69] bass: 50 | Gm: [67,70,74] bass: 55 | F: [65,69,72] bass: 53

EXAMPLE - Creating Melodies from Chord Tones:
```python
from midiutil import MIDIFile
import random

random.seed({actual_seed})  # Creates variation each run!

midi = MIDIFile(2)
melody_track = 0
bass_track = 1

midi.addTempo(melody_track, 0, {bpm})
midi.addTempo(bass_track, 0, {bpm})
midi.addProgramChange(melody_track, 0, 0, 81)
midi.addProgramChange(bass_track, 0, 0, 38)

# E minor progression
chords = [
    {{'notes': [64,67,71], 'bass': 52}},  # Em
    {{'notes': [69,72,76], 'bass': 57}},  # Am
    {{'notes': [71,74,78], 'bass': 59}},  # Bm
    {{'notes': [64,67,71], 'bass': 52}}   # Em
]

time = 0.0

# Calculate how many bars needed: {duration}s at {bpm} BPM = {int(total_bars)} bars
num_bars = {int(total_bars)}

# IMPORTANT: Loop until we reach num_bars!
for bar in range(num_bars):
    chord = chords[bar % len(chords)]  # Cycle through progression

    # Bass plays root note
    midi.addNote(bass_track, 0, chord['bass'], time, 4.0, 100)

    # Melody picks notes FROM the chord (harmonically correct!)
    chord_tones = chord['notes'] + [n+12 for n in chord['notes']]  # Add octave

    # Create varied melody using random selection
    for i in range(4):  # 4 notes per bar
        note = random.choice(chord_tones)
        duration = random.choice([0.5, 1.0, 1.5])  # Vary rhythm!
        velocity = random.randint(70, 95)
        midi.addNote(melody_track, 0, note, time, duration, velocity)
        time += 1.0

with open("{filename}", "wb") as f:
    midi.writeFile(f)
```

KEY RULES:
1. MUST generate {int(total_bars)} bars to match {duration} seconds!
2. Melody notes MUST come from current chord (chord tones only!)
3. Use random.choice() to pick different notes each time
4. Vary note durations for rhythm variety
5. Bass always plays chord root
6. Each run with different seed = different melody

Generate VARIED, HARMONICALLY CORRECT melody ({int(total_bars)} bars) for: {prompt}"""
            
            llm_response = None
            
            if llm_provider == "ollama":
                print(f"[Absynth-VST] 🤖 Calling Ollama: {model}")
                llm_response = self._call_ollama(model, system_prompt, prompt, temperature)
            elif llm_provider == "openai":
                print(f"[Absynth-VST] 🤖 Calling OpenAI: {model}")
                llm_response = self._call_openai(api_key, model, system_prompt, prompt, temperature)
            elif llm_provider == "anthropic":
                print(f"[Absynth-VST] 🤖 Calling Anthropic: {model}")
                llm_response = self._call_anthropic(api_key, model, system_prompt, prompt, temperature)
            
            if llm_response:
                print(f"[Absynth-VST] ✓ Response received, processing...")
                success, error_msg = self._execute_generated_code(llm_response, filename, bpm, duration, target_folder)
                
                if success and os.path.exists(output_path):
                    print(f"")
                    print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
                    print(f"[Absynth-VST] ║  🤖 LLM GENERATION: SUCCESS ✓         ║")
                    print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
                    print(f"[Absynth-VST] Model: {model}")
                    print(f"[Absynth-VST] File: {filename}")
                    print(f"[Absynth-VST] ✓✓✓ MIDI created: {output_path}")
                    print(f"")
                    return (output_path, f"SUCCESS:LLM:{model}")
                else:
                    print(f"")
                    print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
                    print(f"[Absynth-VST] ║  ✗ LLM FAILED - No Fallback           ║")
                    print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
                    if error_msg:
                        print(f"[Absynth-VST] Error: {error_msg}")
                    print(f"[Absynth-VST] Tip: Try a different model or simpler prompt")
                    print(f"")
                    return (f"Error: LLM generation failed - {error_msg if error_msg else 'unknown error'}", f"FAILED:LLM:{model}:{error_msg if error_msg else 'unknown'}")
            else:
                print(f"")
                print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
                print(f"[Absynth-VST] ║  ✗ LLM Error - No Response            ║")
                print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
                print(f"[Absynth-VST] Check API connection or model availability")
                print(f"")
                return (f"Error: LLM did not return a response", f"FAILED:LLM:{model}:No response")
            
        except Exception as e:
            print(f"")
            print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
            print(f"[Absynth-VST] ║  ✗ EXCEPTION ERROR                    ║")
            print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
            print(f"[Absynth-VST] Error: {str(e)}")
            print(f"")
            import traceback
            traceback.print_exc()
            return (f"Error: Exception during generation - {str(e)}", f"FAILED:EXCEPTION:{str(e)}")
    
    def _create_fallback_midi(self, prompt, filename, bpm, duration, key_info, target_folder, seed=None):
        import random
        import time

        # Use provided seed or generate new one based on time + hash
        if seed is None:
            seed_value = int(time.time() * 1000) % 999999
        else:
            seed_value = seed

        random.seed(seed_value)
        print(f"[Absynth-VST] Local generation seed: {seed_value}")
        
        output_path = os.path.join(target_folder, filename)
        prompt_lower = prompt.lower()
        
        genre_keywords = {
            'trance': ['trance', 'uplifting', 'psy', 'progressive'],
            'techno': ['techno', 'minimal', 'industrial'],
            'house': ['house', 'deep', 'funky'],
            'boombap': ['boom', 'bap', 'hip hop', 'rap'],
            'lofi': ['lofi', 'lo-fi', 'chill', 'jazzy'],
            'trap': ['trap', '808', 'triplet'],
            'electro': ['electro', 'synth', '80s']
        }
        
        detected_genre = 'house'
        for genre, keywords in genre_keywords.items():
            if any(kw in prompt_lower for kw in keywords):
                detected_genre = genre
                break
        
        synth_keywords = [
            'arpeggio', 'chord', 'melody', 'melodic', 'harmonic', 'harmony',
            'bass line', 'bassline', 'lead', 'pad', 'progression',
            'scale', 'note', 'key', 'major', 'minor',
            'synth', 'piano', 'strings', 'brass', 'ambient'
        ]
        is_synth = any(keyword in prompt_lower for keyword in synth_keywords)
        
        drum_keywords = [
            'drum', 'kick', 'snare', 'beat', 'percussion',
            'hi-hat', 'hihat', 'cymbal', 'tom', 'clap', 'rim', 'cowbell',
            'hip hop', 'hip-hop', 'hiphop', 'rap',
            'boom bap', 'boombap', 'trap',
            'house', 'techno', 'trance', 'edm',
            'groove', 'rhythm', 'pattern',
            'verse', 'hook', 'breakdown', 'drop'
        ]
        
        if is_synth:
            is_drums = False
        elif key_info == "drums":
            is_drums = True
        else:
            is_drums = any(keyword in prompt_lower for keyword in drum_keywords)
        
        print(f"[Absynth-VST] Generating {detected_genre.upper()} pattern...")
        print(f"[Absynth-VST] Detection: Synth={is_synth}, Key={key_info}")
        print(f"[Absynth-VST] Type: {'DRUMS' if is_drums else 'SYNTH'} → Folder: {os.path.basename(target_folder)}/")
        
        try:
            mid = mido.MidiFile(type=0, ticks_per_beat=480)
            track = mido.MidiTrack()
            mid.tracks.append(track)
            
            track.append(mido.MetaMessage('track_name', name=detected_genre.title(), time=0))
            tempo = mido.bpm2tempo(bpm)
            track.append(mido.MetaMessage('set_tempo', tempo=tempo, time=0))
            track.append(mido.MetaMessage('time_signature', numerator=4, denominator=4, time=0))
            
            beats_total = (bpm / 60.0) * duration
            bars = int(beats_total / 4)
            events = []
            
            if is_drums or key_info == "drums":
                pattern_variation = random.randint(1, 3)
                
                if detected_genre == 'trance':
                    print(f"[Absynth-VST] Trance Pattern Variation #{pattern_variation}")
                    
                    for bar in range(bars):
                        time = bar * 4.0
                        
                        for beat in [0, 1, 2, 3]:
                            vel = random.randint(108, 115)
                            events.append({'time': time + beat, 'note': 36, 'duration': 0.25, 'velocity': vel, 'channel': 9})
                        
                        events.append({'time': time + 1, 'note': 38, 'duration': 0.25, 'velocity': random.randint(98, 105), 'channel': 9})
                        events.append({'time': time + 3, 'note': 38, 'duration': 0.25, 'velocity': random.randint(98, 105), 'channel': 9})
                        
                        for i in range(16):
                            vel = 85 if i % 4 == 0 else 65
                            vel += random.randint(-3, 3)
                            events.append({'time': time + i * 0.25, 'note': 42, 'duration': 0.15, 'velocity': vel, 'channel': 9})
                        
                        open_times = [0.5, 1.5, 2.5, 3.5]
                        for ot in open_times:
                            events.append({'time': time + ot, 'note': 46, 'duration': 0.35, 'velocity': random.randint(68, 75), 'channel': 9})
                        
                        if bar in [0, 16, 32, 48]:
                            events.append({'time': time, 'note': 49, 'duration': 2.0, 'velocity': random.randint(100, 108), 'channel': 9})
                
                elif detected_genre == 'boombap':
                    print(f"[Absynth-VST] Boom Bap Pattern Variation #{pattern_variation}")
                    
                    for bar in range(bars):
                        time = bar * 4.0
                        
                        if pattern_variation == 1:
                            kick_times = [0, 0.25, 0.5, 1.0, 1.5, 2.0, 2.25, 3.0, 3.5]
                        elif pattern_variation == 2:
                            kick_times = [0, 0.5, 1.0, 1.25, 2.0, 2.25, 2.5, 3.0, 3.25]
                        else:
                            kick_times = [0, 0.25, 1.0, 2.0, 2.25, 3.0, 3.5]
                        
                        for kt in kick_times:
                            events.append({'time': time + kt, 'note': 36, 'duration': 0.2, 'velocity': random.randint(120, 127), 'channel': 9})
                        
                        events.append({'time': time + 1, 'note': 38, 'duration': 0.25, 'velocity': random.randint(118, 125), 'channel': 9})
                        events.append({'time': time + 3, 'note': 38, 'duration': 0.25, 'velocity': random.randint(118, 125), 'channel': 9})
                        
                        if bar % 2 == 1:
                            ghost_times = [1.5, 2.75]
                            for gt in ghost_times:
                                events.append({'time': time + gt, 'note': 38, 'duration': 0.1, 'velocity': random.randint(40, 50), 'channel': 9})
                        
                        for sixteenth in range(16):
                            pos = sixteenth * 0.25
                            vel = random.randint(72, 78) if sixteenth % 4 == 0 else random.randint(60, 67)
                            events.append({'time': time + pos, 'note': 42, 'duration': 0.12, 'velocity': vel, 'channel': 9})
                
                else:
                    for bar in range(bars):
                        time = bar * 4.0
                        for beat in [0, 1, 2, 3]:
                            events.append({'time': time + beat, 'note': 36, 'duration': 0.25, 'velocity': random.randint(100, 108), 'channel': 9})
                        events.append({'time': time + 1, 'note': 38, 'duration': 0.25, 'velocity': random.randint(88, 95), 'channel': 9})
                        events.append({'time': time + 3, 'note': 38, 'duration': 0.25, 'velocity': random.randint(88, 95), 'channel': 9})
                        for eighth in [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]:
                            vel = random.randint(65, 75)
                            events.append({'time': time + eighth, 'note': 42, 'duration': 0.25, 'velocity': vel, 'channel': 9})
            
            else:
                # SYNTH MODE - Use real trance progressions from Above & Beyond, Paul van Dyk
                print(f"[Absynth-VST] Generating SYNTH with proven trance progressions...")
                print(f"[Absynth-VST] Detected key: {key_info}")

                # Define progressions for different keys (I-V-vi-IV and I-vi-IV-V patterns)
                key_progressions = {
                    'Cmaj': {
                        'name': 'C major',
                        'progressions': [
                            [[60, 64, 67], [67, 71, 74], [69, 72, 76], [65, 69, 72]],  # I-V-vi-IV: C-G-Am-F
                            [[60, 64, 67], [69, 72, 76], [65, 69, 72], [67, 71, 74]],  # I-vi-IV-V: C-Am-F-G
                        ],
                        'scale': [48, 50, 52, 53, 55, 57, 59, 60, 62, 64, 65, 67, 69, 71, 72, 74, 76, 77, 79, 81]
                    },
                    'Dmaj': {
                        'name': 'D major',
                        'progressions': [
                            [[62, 66, 69], [69, 73, 76], [71, 74, 78], [67, 71, 74]],  # I-V-vi-IV: D-A-Bm-G
                            [[62, 66, 69], [71, 74, 78], [67, 71, 74], [69, 73, 76]],  # I-vi-IV-V: D-Bm-G-A
                        ],
                        'scale': [50, 52, 54, 55, 57, 59, 61, 62, 64, 66, 67, 69, 71, 73, 74, 76, 78, 79, 81, 83]
                    },
                    'Emaj': {
                        'name': 'E major',
                        'progressions': [
                            [[64, 68, 71], [71, 75, 78], [73, 76, 80], [69, 73, 76]],  # I-V-vi-IV: E-B-C#m-A
                            [[64, 68, 71], [73, 76, 80], [69, 73, 76], [71, 75, 78]],  # I-vi-IV-V
                        ],
                        'scale': [52, 54, 56, 57, 59, 61, 63, 64, 66, 68, 69, 71, 73, 75, 76, 78, 80, 81, 83, 85]
                    },
                    'Gmaj': {
                        'name': 'G major',
                        'progressions': [
                            [[67, 71, 74], [74, 78, 81], [76, 79, 83], [72, 76, 79]],  # I-V-vi-IV: G-D-Em-C
                            [[67, 71, 74], [76, 79, 83], [72, 76, 79], [74, 78, 81]],  # I-vi-IV-V
                        ],
                        'scale': [55, 57, 59, 60, 62, 64, 66, 67, 69, 71, 72, 74, 76, 78, 79, 81, 83, 84, 86, 88]
                    },
                    'Amaj': {
                        'name': 'A major',
                        'progressions': [
                            [[69, 73, 76], [76, 80, 83], [78, 81, 85], [74, 78, 81]],  # I-V-vi-IV: A-E-F#m-D
                            [[69, 73, 76], [78, 81, 85], [74, 78, 81], [76, 80, 83]],  # I-vi-IV-V
                        ],
                        'scale': [57, 59, 61, 62, 64, 66, 68, 69, 71, 73, 74, 76, 78, 80, 81, 83, 85, 86, 88, 90]
                    },
                    'Amin': {
                        'name': 'A minor',
                        'progressions': [
                            [[69, 72, 76], [76, 79, 83], [72, 76, 79], [65, 69, 72]],  # i-v-VI-III: Am-Em-F-C
                            [[69, 72, 76], [65, 69, 72], [67, 71, 74], [76, 79, 83]],  # i-VI-VII-v: Am-F-G-Em
                        ],
                        'scale': [57, 59, 60, 62, 64, 65, 67, 69, 71, 72, 74, 76, 77, 79, 81, 83, 84, 86, 88, 89]
                    },
                    'Emin': {
                        'name': 'E minor',
                        'progressions': [
                            [[64, 67, 71], [71, 74, 78], [72, 76, 79], [60, 64, 67]],  # i-v-VI-III: Em-Bm-C-G
                            [[64, 67, 71], [72, 76, 79], [74, 78, 81], [71, 74, 78]],  # i-VI-VII-v: Em-C-D-Bm
                        ],
                        'scale': [52, 54, 55, 57, 59, 60, 62, 64, 66, 67, 69, 71, 72, 74, 76, 78, 79, 81, 83, 84]
                    },
                    'Dmin': {
                        'name': 'D minor',
                        'progressions': [
                            [[62, 65, 69], [69, 72, 76], [70, 74, 77], [67, 71, 74]],  # i-v-VI-III: Dm-Am-Bb-F
                            [[62, 65, 69], [70, 74, 77], [72, 76, 79], [69, 72, 76]],  # i-VI-VII-v: Dm-Bb-C-Am
                        ],
                        'scale': [50, 52, 53, 55, 57, 58, 60, 62, 64, 65, 67, 69, 70, 72, 74, 76, 77, 79, 81, 82]
                    },
                    'Fmaj': {
                        'name': 'F major',
                        'progressions': [
                            [[65, 69, 72], [72, 76, 79], [74, 77, 81], [70, 74, 77]],  # I-V-vi-IV: F-C-Dm-Bb
                            [[65, 69, 72], [74, 77, 81], [70, 74, 77], [72, 76, 79]],  # I-vi-IV-V
                        ],
                        'scale': [53, 55, 57, 58, 60, 62, 64, 65, 67, 69, 70, 72, 74, 76, 77, 79, 81, 82, 84, 86]
                    },
                    'Gmin': {
                        'name': 'G minor',
                        'progressions': [
                            [[67, 70, 74], [74, 77, 81], [75, 79, 82], [72, 76, 79]],  # i-v-VI-III: Gm-Dm-Eb-Bb
                            [[67, 70, 74], [75, 79, 82], [77, 81, 84], [74, 77, 81]],  # i-VI-VII-v: Gm-Eb-F-Dm
                        ],
                        'scale': [55, 57, 58, 60, 62, 63, 65, 67, 69, 70, 72, 74, 75, 77, 79, 81, 82, 84, 86, 87]
                    },
                    'Cmin': {
                        'name': 'C minor',
                        'progressions': [
                            [[60, 63, 67], [67, 70, 74], [68, 72, 75], [65, 69, 72]],  # i-v-VI-III: Cm-Gm-Ab-Eb
                            [[60, 63, 67], [68, 72, 75], [70, 74, 77], [67, 70, 74]],  # i-VI-VII-v: Cm-Ab-Bb-Gm
                        ],
                        'scale': [48, 50, 51, 53, 55, 56, 58, 60, 62, 63, 65, 67, 68, 70, 72, 74, 75, 77, 79, 80]
                    },
                    'Bmaj': {
                        'name': 'B major',
                        'progressions': [
                            [[71, 75, 78], [78, 82, 85], [80, 83, 87], [76, 80, 83]],  # I-V-vi-IV: B-F#-G#m-E
                            [[71, 75, 78], [80, 83, 87], [76, 80, 83], [78, 82, 85]],  # I-vi-IV-V
                        ],
                        'scale': [59, 61, 63, 64, 66, 68, 70, 71, 73, 75, 76, 78, 80, 82, 83, 85, 87, 88, 90, 92]
                    },
                    'Bmin': {
                        'name': 'B minor',
                        'progressions': [
                            [[71, 74, 78], [78, 81, 85], [76, 80, 83], [73, 76, 80]],  # i-v-VI-III: Bm-F#m-G-D
                            [[71, 74, 78], [76, 80, 83], [78, 82, 85], [78, 81, 85]],  # i-VI-VII-v: Bm-G-A-F#m
                        ],
                        'scale': [59, 61, 62, 64, 66, 67, 69, 71, 73, 74, 76, 78, 79, 81, 83, 85, 86, 88, 90, 91]
                    },
                    'Fmin': {
                        'name': 'F minor',
                        'progressions': [
                            [[65, 68, 72], [72, 75, 79], [73, 77, 80], [70, 74, 77]],  # i-v-VI-III: Fm-Cm-Db-Ab
                            [[65, 68, 72], [73, 77, 80], [75, 79, 82], [72, 75, 79]],  # i-VI-VII-v: Fm-Db-Eb-Cm
                        ],
                        'scale': [53, 55, 56, 58, 60, 61, 63, 65, 67, 68, 70, 72, 73, 75, 77, 79, 80, 82, 84, 85]
                    },
                }

                # Get the key data (default to D major if not found)
                key_data = key_progressions.get(key_info, key_progressions['Dmaj'])
                print(f"[Absynth-VST] Using: {key_data['name']}")

                chord_progression = random.choice(key_data['progressions'])
                scale = key_data['scale']

                # Generate music
                for bar_idx in range(bars):
                    bar_start_time = bar_idx * 4.0
                    chord = chord_progression[bar_idx % len(chord_progression)]

                    # Arpeggios (16th notes)
                    arp_pattern = random.choice([
                        [0, 1, 2, 1] * 4,      # Up-down
                        [0, 2, 1, 2] * 4,      # Bouncy
                        [0, 1, 2, 0, 1, 2] * 2 # Progressive
                    ])

                    for i, idx in enumerate(arp_pattern):
                        note = chord[idx % len(chord)]
                        events.append({'time': bar_start_time + i * 0.25, 'note': note, 'duration': 0.2, 'velocity': random.randint(80, 100), 'channel': 0})

                    # Melody (70% chord tones, 30% scale)
                    if bar_idx % 2 == 0:
                        for i in range(4):
                            if random.random() < 0.7:
                                # Chord tone (harmonic!)
                                note = random.choice(chord + [n + 12 for n in chord])
                            else:
                                # Scale passing tone
                                note = random.choice(scale[10:18])
                            note = max(60, min(84, note))
                            events.append({'time': bar_start_time + i, 'note': note, 'duration': 0.8, 'velocity': random.randint(90, 110), 'channel': 0})

                    # Bass (chord root, two octaves down)
                    bass = max(24, chord[0] - 24)
                    events.append({'time': bar_start_time, 'note': bass, 'duration': 4.0, 'velocity': 105, 'channel': 0})
            
            midi_events = []
            for event in events:
                time_ticks = int(event['time'] * 480)
                midi_events.append({'time': time_ticks, 'type': 'note_on', 'note': event['note'], 'velocity': event['velocity'], 'channel': event['channel']})
                midi_events.append({'time': time_ticks + int(event['duration'] * 480), 'type': 'note_off', 'note': event['note'], 'velocity': 0, 'channel': event['channel']})
            
            midi_events.sort(key=lambda x: (x['time'], x['type'] == 'note_off'))
            
            last_time = 0
            for event in midi_events:
                delta = event['time'] - last_time
                if event['type'] == 'note_on':
                    track.append(mido.Message('note_on', note=event['note'], velocity=event['velocity'], channel=event['channel'], time=delta))
                else:
                    track.append(mido.Message('note_off', note=event['note'], velocity=0, channel=event['channel'], time=delta))
                last_time = event['time']
            
            track.append(mido.MetaMessage('end_of_track', time=0))
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            mid.save(output_path)
            
            print(f"")
            print(f"[Absynth-VST] ╔═══════════════════════════════════════╗")
            print(f"[Absynth-VST] ║      LOCAL GENERATION: SUCCESS ✓      ║")
            print(f"[Absynth-VST] ╚═══════════════════════════════════════╝")
            print(f"[Absynth-VST] Genre: {detected_genre.upper()}")
            print(f"[Absynth-VST] Events: {len(events)}")
            print(f"[Absynth-VST] File: {os.path.basename(output_path)}")
            print(f"")
            return output_path
            
        except Exception as e:
            print(f"[Absynth-VST] ✗ Error: {e}")
            import traceback
            traceback.print_exc()
            return output_path


class AbsynthVSTMixerNode:
    """4-Channel Mixer with Faders and Pan Controls (Like Cubase)"""
    
    VERSION = "1.0"
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                # Track Names
                "track_1_name": ("STRING", {"default": "Track 1", "multiline": False}),
                "track_2_name": ("STRING", {"default": "Track 2", "multiline": False}),
                "track_3_name": ("STRING", {"default": "Track 3", "multiline": False}),
                "track_4_name": ("STRING", {"default": "Track 4", "multiline": False}),
                
                # Fader 1 (von unten nach oben = 0.0 bis 2.0)
                "track_1_fader": ("FLOAT", {
                    "default": 0.8, 
                    "min": 0.0, 
                    "max": 2.0, 
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "track_1_pan": ("FLOAT", {
                    "default": 0.0,  # -1.0 = Links, 0.0 = Center, 1.0 = Rechts
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                
                # Fader 2
                "track_2_fader": ("FLOAT", {
                    "default": 0.8,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "track_2_pan": ("FLOAT", {
                    "default": 0.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                
                # Fader 3
                "track_3_fader": ("FLOAT", {
                    "default": 0.8,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "track_3_pan": ("FLOAT", {
                    "default": 0.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                
                # Fader 4
                "track_4_fader": ("FLOAT", {
                    "default": 0.8,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                "track_4_pan": ("FLOAT", {
                    "default": 0.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
                
                # Master Fader
                "master_fader": ("FLOAT", {
                    "default": 1.0,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "round": 0.01
                }),
            },
            "optional": {
                "audio_1": ("AUDIO",),
                "audio_2": ("AUDIO",),
                "audio_3": ("AUDIO",),
                "audio_4": ("AUDIO",),
            }
        }
    
    RETURN_TYPES = ("AUDIO", "AUDIO", "AUDIO", "AUDIO", "AUDIO")
    RETURN_NAMES = ("track_1_out", "track_2_out", "track_3_out", "track_4_out", "mix_output")
    FUNCTION = "mix_audio"
    CATEGORY = "absynth-vst"
    
    def apply_pan(self, audio_stereo, pan_value):
        """
        Wendet Panning auf Stereo-Audio an.
        pan_value: -1.0 (Links), 0.0 (Center), 1.0 (Rechts)
        """
        # Constant Power Panning (wie in Cubase)
        import math
        
        # Pan von -1.0...1.0 zu 0...π/2 konvertieren
        pan_angle = (pan_value + 1.0) * (math.pi / 4.0)
        
        left_gain = math.cos(pan_angle)
        right_gain = math.sin(pan_angle)
        
        # Auf beide Kanäle anwenden
        panned_audio = audio_stereo.clone()
        panned_audio[:, 0, :] *= left_gain   # Linker Kanal
        panned_audio[:, 1, :] *= right_gain  # Rechter Kanal
        
        return panned_audio
    
    def process_track(self, audio_input, fader, pan):
        """Verarbeitet einen Track mit Fader und Pan"""
        if audio_input is None:
            # Leeres Audio zurückgeben wenn kein Input
            return {"waveform": torch.zeros((1, 2, 1)), "sample_rate": 48000}
        
        waveform = audio_input["waveform"]
        sample_rate = audio_input["sample_rate"]
        
        # Sicherstellen dass wir Stereo haben
        if waveform.shape[1] == 1:
            # Mono zu Stereo
            waveform = torch.cat([waveform, waveform], dim=1)
        
        # Fader anwenden (Lautstärke)
        waveform = waveform * fader
        
        # Pan anwenden
        waveform = self.apply_pan(waveform, pan)
        
        return {"waveform": waveform, "sample_rate": sample_rate}
    
    def mix_audio(self, track_1_name, track_2_name, track_3_name, track_4_name,
                  track_1_fader, track_1_pan, track_2_fader, track_2_pan,
                  track_3_fader, track_3_pan, track_4_fader, track_4_pan,
                  master_fader, audio_1=None, audio_2=None, audio_3=None, audio_4=None):
        
        print(f"[Absynth-VST Mixer] ═══════════════════════════════")
        print(f"[Absynth-VST Mixer] 🎚️  4-CHANNEL MIXER v1.0")
        print(f"[Absynth-VST Mixer] ═══════════════════════════════")
        
        # Verarbeite jeden Track
        track_1_processed = self.process_track(audio_1, track_1_fader, track_1_pan)
        track_2_processed = self.process_track(audio_2, track_2_fader, track_2_pan)
        track_3_processed = self.process_track(audio_3, track_3_fader, track_3_pan)
        track_4_processed = self.process_track(audio_4, track_4_fader, track_4_pan)
        
        # Benutze die Custom Track-Namen in den Logs
        def format_pan(pan):
            if pan < -0.01:
                return f"L{abs(pan):.2f}"
            elif pan > 0.01:
                return f"R{pan:.2f}"
            else:
                return "C"
        
        print(f"[Absynth-VST Mixer] 🎵 {track_1_name:12s}: Vol={track_1_fader:.2f}, Pan={format_pan(track_1_pan)}")
        print(f"[Absynth-VST Mixer] 🎵 {track_2_name:12s}: Vol={track_2_fader:.2f}, Pan={format_pan(track_2_pan)}")
        print(f"[Absynth-VST Mixer] 🎵 {track_3_name:12s}: Vol={track_3_fader:.2f}, Pan={format_pan(track_3_pan)}")
        print(f"[Absynth-VST Mixer] 🎵 {track_4_name:12s}: Vol={track_4_fader:.2f}, Pan={format_pan(track_4_pan)}")
        print(f"[Absynth-VST Mixer] 🎛️  Master Fader: {master_fader:.2f}")
        
        # Finde die längste Audio-Datei für Mix-Länge
        max_length = 1
        sample_rate = 48000
        
        tracks = [track_1_processed, track_2_processed, track_3_processed, track_4_processed]
        valid_tracks = [t for t in tracks if t["waveform"].shape[2] > 1]
        
        if valid_tracks:
            max_length = max(t["waveform"].shape[2] for t in valid_tracks)
            sample_rate = valid_tracks[0]["sample_rate"]
        
        # Erstelle Mix-Buffer
        mix_buffer = torch.zeros((1, 2, max_length))
        
        # Summiere alle Tracks
        for track in tracks:
            waveform = track["waveform"]
            track_length = waveform.shape[2]
            
            if track_length > 1:  # Nur wenn Audio vorhanden
                # Auf Mix-Länge padden wenn nötig
                if track_length < max_length:
                    padding = torch.zeros((1, 2, max_length - track_length))
                    waveform = torch.cat([waveform, padding], dim=2)
                
                mix_buffer += waveform
        
        # Master Fader auf Mix anwenden
        mix_buffer = mix_buffer * master_fader
        
        # Limitiere auf -1.0 bis +1.0 (verhindert Clipping)
        mix_buffer = torch.clamp(mix_buffer, -1.0, 1.0)
        
        mix_output = {"waveform": mix_buffer, "sample_rate": sample_rate}
        
        # Audio-Peak-Analyse
        if max_length > 1:
            peak = torch.max(torch.abs(mix_buffer)).item()
            print(f"[Absynth-VST Mixer] Mix Peak: {peak:.3f} ({peak*100:.1f}%)")
            if peak > 0.95:
                print(f"[Absynth-VST Mixer] ⚠️  WARNING: Signal is close to clipping!")
        
        print(f"[Absynth-VST Mixer] ═══════════════════════════════")
        
        return (track_1_processed, track_2_processed, track_3_processed, track_4_processed, mix_output)


class AbsynthLLMStatusDisplayNode:
    """Prominent LLM Status Display with Big Beautiful Text"""
    VERSION = "1.2.5"

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"status": ("STRING", {"forceInput": True})}}

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("formatted_status",)
    FUNCTION = "display_status"
    CATEGORY = "absynth-vst"
    OUTPUT_NODE = True

    def display_status(self, status):
        """Create big, beautiful status display"""

        lines = []

        # Parse status string
        if status.startswith("SUCCESS:"):
            parts = status.split(":")
            if len(parts) >= 2:
                source = parts[1]  # LOCAL or LLM
                model = parts[2] if len(parts) > 2 else "Unknown"

                lines.append("")
                lines.append("╔═════════════════════════════════════════════════════════════╗")
                lines.append("║                                                             ║")
                lines.append("║            ✨  LLM MIDI GENERATION SUCCESS!  ✨            ║")
                lines.append("║                                                             ║")
                lines.append("╚═════════════════════════════════════════════════════════════╝")
                lines.append("")
                lines.append("   ███████╗██╗   ██╗ ██████╗ ██████╗███████╗███████╗███████╗")
                lines.append("   ██╔════╝██║   ██║██╔════╝██╔════╝██╔════╝██╔════╝██╔════╝")
                lines.append("   ███████╗██║   ██║██║     ██║     █████╗  ███████╗███████╗")
                lines.append("   ╚════██║██║   ██║██║     ██║     ██╔══╝  ╚════██║╚════██║")
                lines.append("   ███████║╚██████╔╝╚██████╗╚██████╗███████╗███████║███████║")
                lines.append("   ╚══════╝ ╚═════╝  ╚═════╝ ╚═════╝╚══════╝╚══════╝╚══════╝")
                lines.append("")

                if source == "LOCAL":
                    lines.append("   🏠  SOURCE: Local Generation (Built-in)")
                else:
                    lines.append(f"   🤖  SOURCE: LLM - {model}")

                lines.append("")
                lines.append("   ✓ MIDI file created successfully")
                lines.append("   ✓ Ready to use with Absynth-VST Player")
                lines.append("")
                lines.append("═" * 63)

        elif status.startswith("FAILED:"):
            parts = status.split(":")
            error_type = parts[1] if len(parts) > 1 else "UNKNOWN"
            model = parts[2] if len(parts) > 2 else "Unknown"
            error_msg = parts[3] if len(parts) > 3 else "No details"

            lines.append("")
            lines.append("╔═════════════════════════════════════════════════════════════╗")
            lines.append("║                                                             ║")
            lines.append("║             ✗  LLM MIDI GENERATION FAILED  ✗               ║")
            lines.append("║                                                             ║")
            lines.append("╚═════════════════════════════════════════════════════════════╝")
            lines.append("")
            lines.append("   ███████╗ █████╗ ██╗██╗     ███████╗██████╗ ")
            lines.append("   ██╔════╝██╔══██╗██║██║     ██╔════╝██╔══██╗")
            lines.append("   █████╗  ███████║██║██║     █████╗  ██║  ██║")
            lines.append("   ██╔══╝  ██╔══██║██║██║     ██╔══╝  ██║  ██║")
            lines.append("   ██║     ██║  ██║██║███████╗███████╗██████╔╝")
            lines.append("   ╚═╝     ╚═╝  ╚═╝╚═╝╚══════╝╚══════╝╚═════╝ ")
            lines.append("")

            if error_type == "LLM":
                lines.append(f"   ⚠️  MODEL: {model}")
                lines.append(f"   ⚠️  ERROR: {error_msg}")
                lines.append("")
                lines.append("   SUGGESTIONS:")
                lines.append("   1. Try your prompt again")
                lines.append("   2. Simplify your prompt")
                lines.append("   3. Try a different LLM model")
                lines.append("   4. Check API connection/key")
                lines.append("   5. Use 'local' provider as fallback")
            elif error_type == "EXCEPTION":
                lines.append(f"   ⚠️  EXCEPTION: {error_msg}")
                lines.append("")
                lines.append("   SUGGESTIONS:")
                lines.append("   1. Try your prompt again")
                lines.append("   2. Check console for full error trace")
                lines.append("   3. Verify midiutil is installed")
                lines.append("   4. Report bug if persists")

            lines.append("")
            lines.append("═" * 63)

        else:
            # Unknown status format
            lines.append("")
            lines.append("╔═══════════════════════════════════╗")
            lines.append("║    LLM MIDI GENERATOR STATUS      ║")
            lines.append("╚═══════════════════════════════════╝")
            lines.append("")
            lines.append(f"Status: {status}")
            lines.append("")

        formatted = "\n".join(lines)
        print(formatted)  # Also print to console
        return (formatted,)


class AbsynthAudioPreviewNode:
    """Beautiful Audio Preview with Neon Teal Waveform - Play, Stop, Download"""
    VERSION = "1.3.2"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "audio": ("AUDIO", {"forceInput": True}),
            }
        }

    RETURN_TYPES = ("AUDIO", "STRING",)
    RETURN_NAMES = ("audio", "audio_info",)
    FUNCTION = "preview_audio"
    CATEGORY = "absynth-vst"
    OUTPUT_NODE = True

    def preview_audio(self, audio):
        """Create beautiful audio preview with waveform visualization"""
        import os
        import base64
        import tempfile
        import time
        import soundfile as sf
        import numpy as np

        # Audio is a dict: {"waveform": tensor, "sample_rate": int}
        # We need to save it to a file first
        try:
            waveform = audio["waveform"]  # Shape: (batch, channels, samples)
            sample_rate = audio["sample_rate"]

            # Convert tensor to numpy
            audio_np = waveform[0].cpu().numpy()  # Remove batch dimension, shape: (channels, samples)

            # Transpose to (samples, channels) for soundfile
            audio_np = audio_np.T

            # VALIDATE BEFORE SAVING - Check duration
            num_samples = len(audio_np)
            duration = num_samples / sample_rate

            if duration < 0.1:  # Less than 100ms
                error_msg = f"""
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║              ⚠️  AUDIO TOO SHORT - NOT SAVED  ⚠️              ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝

⚠️  Duration: {duration:.4f} seconds (minimum: 0.1s)
⚠️  Samples: {num_samples}

The audio is too short to save or display.
This usually means the audio input was empty or silent.
"""
                print(error_msg)
                return {
                    "ui": {},  # Empty UI data - widget will show "NO AUDIO"
                    "result": (audio, error_msg,)
                }

            # VALIDATE BEFORE SAVING - Check silence
            max_amplitude = np.max(np.abs(audio_np))
            if max_amplitude < 0.0001:  # Essentially silent
                error_msg = f"""
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║              🔇  SILENT AUDIO - NOT SAVED  🔇                 ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝

🔇 Max amplitude: {max_amplitude:.6f} (too quiet)
⏱️  Duration: {duration:.2f}s
📊 Samples: {num_samples}

The audio contains no audible signal (silent or near-silent).
This usually means the audio input was empty or the VST didn't generate sound.
"""
                print(error_msg)
                return {
                    "ui": {},  # Empty UI data - widget will show "NO AUDIO"
                    "result": (audio, error_msg,)
                }

            # Audio is valid - save it
            from folder_paths import get_output_directory
            output_dir = get_output_directory()
            filename = f"absynth_preview_{int(time.time() * 1000)}.wav"
            audio_path = os.path.join(output_dir, filename)

            # Save to WAV
            sf.write(audio_path, audio_np, sample_rate, subtype='PCM_16', format='WAV')
            print(f"[Absynth Audio Preview] ✓ Saved valid audio: {filename} ({duration:.2f}s, peak: {max_amplitude:.3f})")

        except Exception as e:
            error_msg = f"❌ Failed to process audio: {str(e)}"
            return {
                "ui": {
                    "error": [error_msg]
                },
                "result": (audio, error_msg,)
            }

        if not os.path.exists(audio_path):
            error_msg = f"❌ Audio file not created: {audio_path}"
            return {
                "ui": {
                    "error": [error_msg]
                },
                "result": (audio, error_msg,)
            }

        try:
            # We already have the audio data from above! Use it directly
            audio_data = audio_np  # This is already (samples, channels)

            # Convert stereo to mono for waveform
            if len(audio_data.shape) > 1:
                audio_mono = np.mean(audio_data, axis=1)
            else:
                audio_mono = audio_data

            # Generate accurate waveform using peak values (like DAWs do)
            num_samples = 2000  # High quality waveform
            chunk_size = max(1, len(audio_mono) // num_samples)

            waveform_data = []
            for i in range(num_samples):
                start = i * chunk_size
                end = min(start + chunk_size, len(audio_mono))

                if start < len(audio_mono):
                    chunk = audio_mono[start:end]
                    if len(chunk) > 0:
                        # Use peak value for this chunk (like waveform displays in DAWs)
                        peak = np.max(np.abs(chunk))
                        # Keep the sign of the loudest sample
                        max_sample = chunk[np.argmax(np.abs(chunk))]
                        waveform_data.append(float(max_sample))
                    else:
                        waveform_data.append(0.0)
                else:
                    break

            # Normalize to -1 to 1
            waveform_data = np.array(waveform_data)
            if np.max(np.abs(waveform_data)) > 0:
                waveform_data = waveform_data / np.max(np.abs(waveform_data))

            # Convert to list for JSON
            waveform_list = waveform_data.tolist()

            # Get file info (audio already validated before saving)
            duration = len(audio_data) / sample_rate
            file_size = os.path.getsize(audio_path) / (1024 * 1024)  # MB
            filename = os.path.basename(audio_path)
            max_amplitude = np.max(np.abs(audio_data))

            # Create text preview for console
            text_preview = f"""
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║              🎵  AUDIO PREVIEW - NEON TEAL  🎵               ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝

📁 FILE: {filename}
⏱️  DURATION: {duration:.2f} seconds
📊 SAMPLE RATE: {sample_rate} Hz
💾 FILE SIZE: {file_size:.2f} MB
🎚️  CHANNELS: {'Stereo' if len(audio_data.shape) > 1 else 'Mono'}

═══════════════════════════════════════════════════════════════

🎨 WAVEFORM VISUALIZATION:
   [Neon Teal visualization with {len(waveform_list)} samples]
   Peak amplitude: {np.max(np.abs(waveform_data)):.3f}

═══════════════════════════════════════════════════════════════

💡 CONTROLS:
   ▶️  Play   ⏸️  Pause   ⏹️  Stop   💾 Download

📂 Path: {audio_path}

═══════════════════════════════════════════════════════════════
"""

            print(text_preview)

            # Return data for custom widget (pass through audio + add preview text)
            # ComfyUI's /view endpoint expects just the filename, not full path
            return {
                "ui": {
                    "audio_path": [filename],  # Just filename for /view endpoint
                    "waveform": [waveform_list],
                    "duration": [duration],
                    "sample_rate": [sample_rate],
                    "filename": [filename]
                },
                "result": (audio, text_preview,)
            }

        except Exception as e:
            error_msg = f"""
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║                  ❌  AUDIO PREVIEW ERROR  ❌                  ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝

ERROR: {str(e)}

FILE: {audio_path}

═══════════════════════════════════════════════════════════════
"""
            print(error_msg)
            return {
                "ui": {
                    "error": [str(e)]
                },
                "result": (audio, error_msg,)
            }


NODE_CLASS_MAPPINGS = {
    "AbsynthVST": AbsynthVSTNode,
    "AbsynthVSTParameterLister": AbsynthVSTParameterListerNode,
    "AbsynthMIDICreator": AbsynthMIDICreatorNode,
    "AbsynthVSTInfoDisplay": AbsynthVSTInfoDisplayNode,
    "AbsynthLLMMIDIGenerator": AbsynthLLMMIDIGeneratorNode,
    "AbsynthLLMStatusDisplay": AbsynthLLMStatusDisplayNode,
    "AbsynthAudioPreview": AbsynthAudioPreviewNode,
    "AbsynthVSTMixer": AbsynthVSTMixerNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AbsynthVST": "Absynth-VST Player v1.2.5",
    "AbsynthVSTParameterLister": "Absynth-VST Parameter Lister v1.2.5",
    "AbsynthMIDICreator": "Absynth-VST MIDI Creator v1.2.5",
    "AbsynthVSTInfoDisplay": "Absynth-VST Info Display v1.2.5",
    "AbsynthLLMMIDIGenerator": "Absynth-VST LLM MIDI Generator v1.2.5",
    "AbsynthLLMStatusDisplay": "Absynth-VST LLM Status Display v1.2.5 ✨",
    "AbsynthAudioPreview": "Absynth-VST Audio Preview v1.2.5 🎵",
    "AbsynthVSTMixer": "Absynth-VST Mixer v1.0 🎚️"
}

# Tell ComfyUI where to find our JavaScript extensions
WEB_DIRECTORY = "./web"