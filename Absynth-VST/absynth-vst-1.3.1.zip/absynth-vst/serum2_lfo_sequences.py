#!/usr/bin/env python3
"""
Serum 2 LFO Sequence Generator

Creates trance-style sequences using Serum 2's LFO system.

HOW SERUM 2 SEQUENCES WORK:
===========================
1. LFOs have multi-point curves (step sequencers)
2. ModSlots route LFOs to parameters (filter freq, volume, etc.)

LFO STRUCTURE:
-------------
{
  "curveData": {
    "numPoints": 16,              # Number of steps
    "xVals": [0.0, 0.25, ...],    # Time positions (0.0-1.0)
    "yVals": [1.0, 0.5, ...],     # Values at each point (0.0-1.0)
    "curveVals": [0.5, 0.5, ...], # Curve shapes (0.5 = linear)
    "loopbackPointNum": 65        # Special value for looping
  },
  "plainParams": {
    "kParamDefaultMode": 0.0,     # REQUIRED - prevents crashes!
    "kParamMode": "Free",         # "Free" mode (NOT "bar" - that's UI only!)
    "kParamRate": 8.0             # 8.0 displays as 1/2 note in Serum
  }
}

MODULATION ROUTING:
------------------
{
  "source": [6, 0],                # [sourceType, sourceID] - LFO0 is [6, 0]
  "destModuleTypeString": "VoiceFilter",
  "destModuleID": 0,
  "destModuleParamName": "kParamFreq",
  "plainParams": {
    "kParamAmount": 52.3           # Modulation depth
  }
}

CRITICAL: VoiceFilter MUST be enabled!
---------------------------------------
{
  "VoiceFilter0": {
    "plainParams": {
      "kParamEnable": 1.0,         # REQUIRED - filter must be enabled!
      "kParamFreq": 0.45,          # 450 Hz - optimal for sequences
      "kParamReso": 0.2            # Resonance amount
    }
  }
}
Without kParamEnable: 1.0, the LFO modulation will have no effect!

SOURCE TYPE MAPPING (discovered):
---------------------------------
LFO0 = source [6, 0]
LFO1 = source [1, 0]
LFO2 = source [7, 0]
LFO3 = source [?, ?]  # TBD
"""

def create_step_sequence_lfo(num_steps=16, values=None, rate=8.0, mode="Free"):
    """
    Create an LFO with step sequence

    Args:
        num_steps: Number of steps in the sequence
        values: List of values (0.0-1.0) for each step, or None for random
        rate: LFO rate (Hz if Free, or tempo division if Sync)
        mode: "Free" or "Sync"

    Returns:
        dict: LFO configuration
    """
    import random

    if values is None:
        # Generate random sequence values
        values = [random.random() for _ in range(num_steps)]

    # Normalize values to 0.0-1.0
    values = [max(0.0, min(1.0, v)) for v in values]

    # Create time positions (evenly spaced)
    x_vals = [i / num_steps for i in range(num_steps)]
    x_vals.append(1.0)  # Add endpoint

    # Y values (the actual step values)
    y_vals = values.copy()
    y_vals.append(values[0])  # Loop back to first value

    # Curve values (0.5 = linear, creates hard steps)
    curve_vals = [0.5] * (num_steps + 1)

    return {
        "curveData": {
            "curveVals": curve_vals,
            "loopbackPointNum": 65,
            "numPoints": num_steps,
            "xVals": x_vals,
            "yVals": y_vals
        },
        "pathData": {},
        "plainParams": {
            "kParamDefaultMode": 0.0,  # IMPORTANT: This is required!
            "kParamMode": mode,
            "kParamRate": rate
        }
    }


def create_trance_gate_sequence(num_steps=16):
    """
    Create a classic trance gate pattern (HalfBar Backbeat style)

    Returns a sequence with on/off pattern typical of trance music
    """
    # Classic trance gate: 1001 1001 1001 1000 pattern
    pattern = [
        1.0, 0.0, 0.0, 1.0,  # Bar 1
        1.0, 0.0, 0.0, 1.0,  # Bar 2
        1.0, 0.0, 0.0, 1.0,  # Bar 3
        1.0, 0.0, 0.0, 0.0   # Bar 4 (variation)
    ]

    # Extend or trim to match num_steps
    if len(pattern) < num_steps:
        pattern = (pattern * ((num_steps // len(pattern)) + 1))[:num_steps]
    else:
        pattern = pattern[:num_steps]

    return create_step_sequence_lfo(num_steps, pattern, rate=8.0, mode="bar")


def create_halfbar_trance_pattern():
    """
    HalfBar Trance pattern (inspired by Serum's built-in)

    A 16-step pattern with emphasis on beats 1 and 3, with variations
    Similar to the built-in "HalfBar Trance" LFO shape
    """
    pattern = [
        0.60,  # Beat 1 (kick) - medium intensity
        1.0,   # Peak
        0.99,  # Sustain high
        0.36,  # Drop (ghost)
        1.0,   # Beat 2 - full intensity
        1.0,
        1.0,
        0.20,  # Drop
        1.0,   # Beat 3 (kick)
        1.0,
        1.0,
        1.0,
        0.0,   # Complete drop
        0.99,  # Quick rise
        0.99,
        1.0    # Beat 4
    ]

    return create_step_sequence_lfo(16, pattern, rate=8.0, mode="Free")


def create_sidechain_pump_pattern():
    """
    Sidechain-style pumping pattern

    Creates a ducking effect typical of sidechain compression in trance
    """
    pattern = [
        0.0,   # Duck on kick
        0.2,   # Fast rise
        0.5,
        0.7,
        0.85,
        0.95,
        1.0,   # Full volume
        1.0,
        0.0,   # Duck again
        0.2,
        0.5,
        0.7,
        0.85,
        0.95,
        1.0,
        1.0
    ]

    return create_step_sequence_lfo(16, pattern, rate=8.0, mode="Free")


def create_bar_backbeat_pattern():
    """
    Bar Backbeat pattern

    Full bar pattern with emphasis on 2 and 4 (backbeats)
    """
    pattern = [
        0.6, 0.3, 0.3, 0.3,  # Beat 1 (kick), then quiet
        1.0, 0.4, 0.4, 0.4,  # Beat 2 (snare) - LOUD
        0.7, 0.3, 0.3, 0.3,  # Beat 3 (kick)
        1.0, 0.5, 0.5, 0.3   # Beat 4 (snare) - LOUD
    ]

    return create_step_sequence_lfo(16, pattern, rate=8.0, mode="Free")


def create_filter_sweep_sequence(num_steps=8, start=0.2, end=1.0):
    """
    Create a rising filter sweep sequence

    Args:
        num_steps: Number of steps
        start: Starting value (0.0-1.0)
        end: Ending value (0.0-1.0)
    """
    # Linear ramp
    values = [start + (end - start) * i / (num_steps - 1) for i in range(num_steps)]

    return create_step_sequence_lfo(num_steps, values, rate=8.0, mode="Free")


def create_modulation_routing(source_lfo_id=0, dest_module="VoiceFilter", dest_param="kParamFreq",
                              dest_module_id=0, amount=50.0):
    """
    Create a modulation routing (ModSlot)

    Args:
        source_lfo_id: Which LFO (0-3)
        dest_module: Target module type ("VoiceFilter", "Oscillator", etc.)
        dest_param: Target parameter name
        dest_module_id: Which instance of the module
        amount: Modulation amount (-100 to +100)

    Returns:
        dict: ModSlot configuration
    """
    # Map LFO ID to source type (discovered from analysis)
    source_map = {
        0: [6, 0],  # LFO0
        1: [1, 0],  # LFO1
        2: [7, 0],  # LFO2
        3: [2, 0],  # LFO3 (guessed)
    }

    source = source_map.get(source_lfo_id, [6, 0])

    return {
        "destModuleID": dest_module_id,
        "destModuleParamID": 3 if dest_param == "kParamFreq" else 1,  # Need to map properly
        "destModuleParamName": dest_param,
        "destModuleTypeString": dest_module,
        "plainParams": {
            "kParamAmount": amount
        },
        "source": source
    }


def add_sequence_to_preset(preset_data, lfo_id=0, sequence_lfo=None, mod_routing=None):
    """
    Add an LFO sequence and its modulation routing to a preset

    Args:
        preset_data: The preset dict (with 'data' key)
        lfo_id: Which LFO slot to use (0-3)
        sequence_lfo: LFO configuration (from create_step_sequence_lfo)
        mod_routing: Modulation routing (from create_modulation_routing)
    """
    if 'data' not in preset_data:
        raise ValueError("preset_data must have 'data' key")

    # Add LFO
    lfo_key = f"LFO{lfo_id}"
    preset_data['data'][lfo_key] = sequence_lfo

    # Add modulation routing (find first available ModSlot)
    if mod_routing:
        for i in range(64):  # Serum has 64 mod slots
            slot_key = f"ModSlot{i}"
            if slot_key not in preset_data['data'] or preset_data['data'][slot_key] == "default":
                preset_data['data'][slot_key] = mod_routing
                break

    return preset_data


# Example usage
if __name__ == "__main__":
    # Create a trance gate sequence
    gate_lfo = create_trance_gate_sequence(16)

    # Create modulation routing: LFO0 -> Filter Frequency
    filter_mod = create_modulation_routing(
        source_lfo_id=0,
        dest_module="VoiceFilter",
        dest_param="kParamFreq",
        amount=51.0
    )

    print("Trance Gate LFO:")
    print(f"  Steps: {gate_lfo['curveData']['numPoints']}")
    print(f"  Values: {gate_lfo['curveData']['yVals']}")
    print(f"  Rate: {gate_lfo['plainParams']['kParamRate']} Hz")

    print("\nModulation Routing:")
    print(f"  Source: LFO{0} {filter_mod['source']}")
    print(f"  Destination: {filter_mod['destModuleTypeString']}.{filter_mod['destModuleParamName']}")
    print(f"  Amount: {filter_mod['plainParams']['kParamAmount']}")
