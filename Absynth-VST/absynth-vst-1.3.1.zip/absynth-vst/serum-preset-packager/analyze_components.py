"""
Analyze Serum 2 preset components to find effects-related parameters
"""
import json

with open('init_unpacked.json', 'r') as f:
    data = json.load(f)

print("=" * 80)
print("SERUM 2 COMPONENT ANALYSIS")
print("=" * 80)

components = data['data']
print(f"\nTotal components: {len(components)}")

# Group components by type
fx_components = [k for k in components.keys() if 'FX' in k]
osc_components = [k for k in components.keys() if 'Oscillator' in k]
env_components = [k for k in components.keys() if 'Env' in k]
lfo_components = [k for k in components.keys() if 'LFO' in k]
filter_components = [k for k in components.keys() if 'Filter' in k]
other_components = [k for k in components.keys() if k not in fx_components + osc_components + env_components + lfo_components + filter_components]

print(f"\nFX-related components ({len(fx_components)}):")
for comp in fx_components:
    print(f"  - {comp}")

print(f"\nOscillator components ({len(osc_components)}):")
for comp in osc_components:
    print(f"  - {comp}")

print(f"\nEnvelope components ({len(env_components)}):")
for comp in env_components:
    print(f"  - {comp}")

print(f"\nLFO components ({len(lfo_components)}):")
for comp in lfo_components:
    print(f"  - {comp}")

print(f"\nFilter components ({len(filter_components)}):")
for comp in filter_components:
    print(f"  - {comp}")

print(f"\nOther components ({len(other_components)}):")
for comp in other_components:
    print(f"  - {comp}")

# Show structure of FXRack components
print("\n" + "=" * 80)
print("FXRack Structure:")
print("=" * 80)
for fx_comp in fx_components:
    if 'Rack' in fx_comp:
        print(f"\n{fx_comp}:")
        print(f"  Structure: {json.dumps(components[fx_comp], indent=4)}")
