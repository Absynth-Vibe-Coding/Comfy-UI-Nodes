// Absynth-VST Audio Preview Widget v1.3.2
// Neon Teal Waveform with Play/Stop/Download - No empty files saved to disk

import { app } from "../../scripts/app.js";

const NEON_TEAL = "#00CED1";
const NEON_TEAL_GLOW = "#00FFFF";
const DARK_BG = "#1a1a2e";
const GRID_COLOR = "#2a2a3e";

app.registerExtension({
    name: "Absynth.AudioPreview",

    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        if (nodeData.name === "AbsynthAudioPreview") {

            // Add custom widget after node is created
            const onNodeCreated = nodeType.prototype.onNodeCreated;
            nodeType.prototype.onNodeCreated = function() {
                const result = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;

                // Create audio preview widget
                const widget = this.addCustomWidget(createAudioPreviewWidget());
                widget.name = "audio_preview";

                // Resize node to fit widget
                this.size = [600, 400];

                // Override node's mouse handler to route to widget
                const self = this;
                const originalOnMouseDown = this.onMouseDown;
                this.onMouseDown = function(e, localPos, canvas) {
                    // Check if click is within widget area
                    const audioWidget = self.widgets?.find(w => w.name === "audio_preview");
                    if (audioWidget && audioWidget.mouse) {
                        const handled = audioWidget.mouse(e, localPos, self);
                        if (handled) {
                            return true;
                        }
                    }

                    // Fall back to original handler
                    if (originalOnMouseDown) {
                        return originalOnMouseDown.apply(this, arguments);
                    }
                    return false;
                };

                return result;
            };

            // Handle execution
            const onExecuted = nodeType.prototype.onExecuted;
            nodeType.prototype.onExecuted = function(message) {
                if (onExecuted) {
                    onExecuted.apply(this, arguments);
                }

                // Get audio data from backend
                const audioWidget = this.widgets?.find(w => w.name === "audio_preview");
                if (audioWidget) {
                    console.log('[Absynth Audio Preview] onExecuted called, message:', message);

                    // Check if message has valid audio data
                    // Backend sends empty {} when audio is invalid/silent
                    const hasValidAudioPath = message &&
                                             typeof message === 'object' &&
                                             Object.keys(message).length > 0 &&  // Not empty object
                                             message.audio_path &&
                                             Array.isArray(message.audio_path) &&
                                             message.audio_path.length > 0 &&
                                             message.audio_path[0] !== null &&
                                             message.audio_path[0] !== "" &&
                                             message.audio_path[0] !== undefined;

                    if (hasValidAudioPath) {
                        const audioPath = message.audio_path[0];
                        const waveform = message.waveform ? message.waveform[0] : null;
                        const duration = message.duration ? message.duration[0] : 0;
                        console.log('[Absynth Audio Preview] Loading audio:', audioPath);
                        audioWidget.loadAudio(audioPath, waveform, duration);
                    } else {
                        // No valid audio received - clear the widget
                        console.log('[Absynth Audio Preview] No valid audio data (empty, silent, or invalid), clearing widget');
                        audioWidget.clearAudio();
                    }
                }
            };
        }
    }
});

function createAudioPreviewWidget() {
    const widget = {
        type: "audio_preview",
        name: "audio_preview",
        audioPath: null,  // MUST be null initially - no audio loaded
        audioElement: null,
        waveformData: null,
        canvas: null,
        ctx: null,
        isPlaying: false,
        isLooping: false,
        isAudioReady: false,  // MUST be false initially - not ready
        currentTime: 0,
        duration: 0,
        animationFrameId: null,
        loopRegion: null,  // {start: 0.0, end: 1.0} in seconds
        isDragging: false,
        dragStartX: null,
        _lastLoggedState: null,  // Track for debug logging

        draw: function(ctx, node, widgetWidth, widgetY, widgetHeight) {
            const margin = 10;
            const waveformHeight = 200;
            const controlsHeight = 60;

            // Store widget position for mouse handling
            this.widgetY = widgetY;
            this.widgetWidth = widgetWidth;
            this.margin = margin;

            // Background
            ctx.fillStyle = DARK_BG;
            ctx.fillRect(margin, widgetY + margin, widgetWidth - margin * 2, widgetHeight - margin * 2);

            // Title
            ctx.save();
            ctx.shadowBlur = 0;
            ctx.shadowColor = "transparent";
            ctx.fillStyle = NEON_TEAL_GLOW;
            ctx.font = "bold 14px Arial";
            ctx.textAlign = "center";
            ctx.textBaseline = "top";
            ctx.fillText("AUDIO PREVIEW", widgetWidth / 2, widgetY + margin + 20);
            ctx.restore();

            // Waveform area
            const waveformY = widgetY + margin + 40;
            const waveformWidth = widgetWidth - margin * 2;

            // Store waveform bounds for click detection
            this.waveformBounds = {
                x: margin,
                y: waveformY,
                width: waveformWidth,
                height: waveformHeight
            };

            this.drawWaveform(ctx, margin, waveformY, waveformWidth, waveformHeight);

            // Timeline
            const timelineY = waveformY + waveformHeight + 10;
            this.drawTimeline(ctx, margin, timelineY, widgetWidth - margin * 2);

            // Controls
            const controlsY = timelineY + 30;
            this.drawControls(ctx, margin, controlsY, widgetWidth - margin * 2, controlsHeight);
        },

        drawWaveform: function(ctx, x, y, width, height) {
            // Border
            ctx.strokeStyle = NEON_TEAL;
            ctx.lineWidth = 2;
            ctx.strokeRect(x, y, width, height);

            // Grid lines
            ctx.strokeStyle = GRID_COLOR;
            ctx.lineWidth = 1;
            for (let i = 1; i < 4; i++) {
                const lineY = y + (height / 4) * i;
                ctx.beginPath();
                ctx.moveTo(x, lineY);
                ctx.lineTo(x + width, lineY);
                ctx.stroke();
            }

            // Center line
            ctx.strokeStyle = GRID_COLOR;
            ctx.lineWidth = 1;
            const centerY = y + height / 2;
            ctx.beginPath();
            ctx.moveTo(x, centerY);
            ctx.lineTo(x + width, centerY);
            ctx.stroke();

            // Draw waveform if available
            if (this.waveformData && this.waveformData.length > 0) {
                const step = width / this.waveformData.length;
                const progress = this.duration > 0 ? (this.currentTime / this.duration) : 0;
                const progressSample = Math.floor(this.waveformData.length * progress);

                // Draw played portion (brighter)
                if (progressSample > 0) {
                    ctx.strokeStyle = NEON_TEAL_GLOW;
                    ctx.lineWidth = 2;
                    ctx.shadowBlur = 15;
                    ctx.shadowColor = NEON_TEAL_GLOW;

                    ctx.beginPath();
                    for (let i = 0; i < progressSample; i++) {
                        const amp = this.waveformData[i];
                        const xPos = x + i * step;
                        const yPos = centerY + (amp * height * 0.45);

                        if (i === 0) {
                            ctx.moveTo(xPos, yPos);
                        } else {
                            ctx.lineTo(xPos, yPos);
                        }
                    }
                    ctx.stroke();
                    ctx.shadowBlur = 0;
                }

                // Draw unplayed portion (dimmer)
                if (progressSample < this.waveformData.length) {
                    ctx.strokeStyle = NEON_TEAL;
                    ctx.lineWidth = 1.5;
                    ctx.globalAlpha = 0.5;

                    ctx.beginPath();
                    for (let i = progressSample; i < this.waveformData.length; i++) {
                        const amp = this.waveformData[i];
                        const xPos = x + i * step;
                        const yPos = centerY + (amp * height * 0.45);

                        if (i === progressSample) {
                            ctx.moveTo(xPos, yPos);
                        } else {
                            ctx.lineTo(xPos, yPos);
                        }
                    }
                    ctx.stroke();
                    ctx.globalAlpha = 1.0;
                }

                // Draw progress indicator line
                if (this.duration > 0) {
                    const progressX = x + (width * progress);

                    ctx.strokeStyle = "#FFFFFF";
                    ctx.lineWidth = 2;
                    ctx.globalAlpha = 0.8;
                    ctx.beginPath();
                    ctx.moveTo(progressX, y);
                    ctx.lineTo(progressX, y + height);
                    ctx.stroke();
                    ctx.globalAlpha = 1.0;
                }

                // Draw loop region if set
                if (this.loopRegion && this.duration > 0) {
                    const regionStartX = x + (width * (this.loopRegion.start / this.duration));
                    const regionEndX = x + (width * (this.loopRegion.end / this.duration));
                    const regionWidth = regionEndX - regionStartX;

                    // Semi-transparent white overlay
                    ctx.fillStyle = "rgba(255, 255, 255, 0.15)";
                    ctx.fillRect(regionStartX, y, regionWidth, height);

                    // White borders
                    ctx.strokeStyle = "#FFFFFF";
                    ctx.lineWidth = 2;
                    ctx.globalAlpha = 0.8;
                    ctx.beginPath();
                    ctx.moveTo(regionStartX, y);
                    ctx.lineTo(regionStartX, y + height);
                    ctx.stroke();

                    ctx.beginPath();
                    ctx.moveTo(regionEndX, y);
                    ctx.lineTo(regionEndX, y + height);
                    ctx.stroke();
                    ctx.globalAlpha = 1.0;
                }
            } else {
                // No waveform loaded
                ctx.fillStyle = GRID_COLOR;
                ctx.font = "12px Arial";
                ctx.textAlign = "center";
                ctx.fillText("No audio loaded", x + width / 2, centerY);
            }
        },

        drawTimeline: function(ctx, x, y, width) {
            // Save context state
            ctx.save();

            // Reset all text settings
            ctx.shadowBlur = 0;
            ctx.shadowColor = "transparent";
            ctx.globalAlpha = 1.0;

            ctx.fillStyle = NEON_TEAL;
            ctx.font = "bold 12px monospace";

            // Left time
            ctx.textAlign = "left";
            ctx.textBaseline = "top";
            ctx.fillText(this.formatTime(this.currentTime), x, y);

            // Right time
            ctx.textAlign = "right";
            ctx.fillText(this.formatTime(this.duration), x + width, y);

            // Restore context
            ctx.restore();
        },

        drawControls: function(ctx, x, y, width, height) {
            const buttonWidth = 70;
            const buttonHeight = 35;
            const spacing = 10;
            const totalWidth = buttonWidth * 4 + spacing * 3;
            const startX = x + (width - totalWidth) / 2;

            // Check if we actually have audio loaded
            const hasAudio = this.audioPath !== null && this.audioPath !== "";

            // SAFETY CHECK: If isAudioReady is true but no audio path, force it false
            if (this.isAudioReady && !hasAudio) {
                console.warn('[Absynth Audio Preview] WARNING: isAudioReady=true but no audio path! Forcing to false.');
                this.isAudioReady = false;
            }

            // Debug logging (only log occasionally to avoid spam)
            if (!this._lastLoggedState || this._lastLoggedState !== `${hasAudio}_${this.isAudioReady}_${this.isPlaying}`) {
                console.log(`[Absynth Audio Preview] State: hasAudio=${hasAudio}, isReady=${this.isAudioReady}, isPlaying=${this.isPlaying}, path="${this.audioPath}"`);
                this._lastLoggedState = `${hasAudio}_${this.isAudioReady}_${this.isPlaying}`;
            }

            // Play/Pause button - show status based on audio availability
            let playLabel = "PLAY";
            if (this.isPlaying) {
                playLabel = "PAUSE";
            } else if (!hasAudio) {
                playLabel = "NO AUDIO";
            } else if (!this.isAudioReady) {
                playLabel = "LOAD...";
            }

            const playBtn = {
                x: startX,
                y: y,
                width: buttonWidth,
                height: buttonHeight,
                label: playLabel
            };

            // Stop button
            const stopBtn = {
                x: startX + buttonWidth + spacing,
                y: y,
                width: buttonWidth,
                height: buttonHeight,
                label: "STOP"
            };

            // Loop button
            const loopBtn = {
                x: startX + (buttonWidth + spacing) * 2,
                y: y,
                width: buttonWidth,
                height: buttonHeight,
                label: "LOOP"
            };

            // Download button
            const downloadBtn = {
                x: startX + (buttonWidth + spacing) * 3,
                y: y,
                width: buttonWidth,
                height: buttonHeight,
                label: "SAVE"
            };

            // Draw buttons
            ctx.save();

            // Reset all effects
            ctx.shadowBlur = 0;
            ctx.shadowColor = "transparent";
            ctx.globalAlpha = 1.0;

            [playBtn, stopBtn, loopBtn, downloadBtn].forEach(btn => {
                // Check if we have audio loaded
                const hasAudio = this.audioPath !== null && this.audioPath !== "";

                // Dim play button if audio is loading or not available
                const isPlayDisabled = (btn === playBtn && (!hasAudio || (!this.isAudioReady && !this.isPlaying)));

                // Button background - highlight loop if active
                if (btn === loopBtn && this.isLooping) {
                    ctx.fillStyle = NEON_TEAL;
                } else {
                    ctx.fillStyle = DARK_BG;
                }
                ctx.fillRect(btn.x, btn.y, btn.width, btn.height);

                // Button border - dimmed if disabled/loading
                if (isPlayDisabled) {
                    ctx.strokeStyle = GRID_COLOR;  // Dimmed border when not ready
                    ctx.globalAlpha = 0.5;
                } else {
                    ctx.strokeStyle = NEON_TEAL;
                }
                ctx.lineWidth = 2;
                ctx.strokeRect(btn.x, btn.y, btn.width, btn.height);
                ctx.globalAlpha = 1.0;

                // Button text - invert color if loop is active
                if (btn === loopBtn && this.isLooping) {
                    ctx.fillStyle = DARK_BG;
                } else if (isPlayDisabled) {
                    ctx.fillStyle = GRID_COLOR;  // Dimmed text when not ready
                } else {
                    ctx.fillStyle = NEON_TEAL;
                }

                // Draw text cleanly without double rendering
                ctx.font = "bold 12px Arial";
                ctx.textAlign = "center";
                ctx.textBaseline = "middle";
                ctx.fillText(btn.label, btn.x + btn.width / 2, btn.y + btn.height / 2);
            });

            ctx.restore();

            // Store button positions for click detection
            this.playButton = playBtn;
            this.stopButton = stopBtn;
            this.loopButton = loopBtn;
            this.downloadButton = downloadBtn;
        },

        formatTime: function(seconds) {
            if (isNaN(seconds) || seconds === 0) return "00:00";
            const mins = Math.floor(seconds / 60);
            const secs = Math.floor(seconds % 60);
            return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        },

        loadAudio: async function(audioPath, waveformData = null, duration = null) {
            this.audioPath = audioPath;
            this.isAudioReady = false;  // Track if audio is ready to play

            // Create audio element
            if (!this.audioElement) {
                this.audioElement = new Audio();
                this.audioElement.preload = "auto";  // Ensure audio preloads
                this.audioElement.addEventListener('timeupdate', () => {
                    this.currentTime = this.audioElement.currentTime;

                    // Check if we need to loop a region
                    if (this.isLooping && this.loopRegion && this.isPlaying) {
                        if (this.currentTime >= this.loopRegion.end) {
                            // Jump back to region start
                            this.audioElement.currentTime = this.loopRegion.start;
                            this.currentTime = this.loopRegion.start;
                        }
                    }
                });
                this.audioElement.addEventListener('ended', () => {
                    // If looping whole track (no region), restart from beginning
                    if (this.isLooping && !this.loopRegion) {
                        this.audioElement.currentTime = 0;
                        this.currentTime = 0;
                        this.audioElement.play();
                    } else if (!this.isLooping) {
                        this.isPlaying = false;
                        this.currentTime = 0;
                        this.stopAnimationLoop();
                        if (app.canvas) {
                            app.canvas.setDirty(true);
                        }
                    }
                });
                this.audioElement.addEventListener('loadedmetadata', () => {
                    if (!duration) {
                        this.duration = this.audioElement.duration;
                    }
                    if (app.canvas) {
                        app.canvas.setDirty(true);
                    }
                });
                this.audioElement.addEventListener('canplaythrough', () => {
                    this.isAudioReady = true;
                    console.log('[Absynth Audio Preview] Audio ready to play');
                    if (app.canvas) {
                        app.canvas.setDirty(true);
                    }
                });
                this.audioElement.addEventListener('error', (e) => {
                    console.error('[Absynth Audio Preview] Audio loading error:', e);
                    this.isAudioReady = false;
                    this.audioPath = null;
                    if (app.canvas) {
                        app.canvas.setDirty(true);
                    }
                });
            }

            // Set loop state (disable native loop, we handle it manually for regions)
            this.audioElement.loop = false;

            // Reset ready state when loading new audio
            this.isAudioReady = false;

            // Load audio and wait for it to be ready
            this.audioElement.src = `/view?filename=${encodeURIComponent(audioPath)}`;
            this.audioElement.load();  // Explicitly trigger load

            // Use provided waveform data from backend or generate demo data
            if (waveformData && waveformData.length > 0) {
                this.waveformData = waveformData;
            } else {
                await this.generateWaveformData();
            }

            // Set duration if provided
            if (duration) {
                this.duration = duration;
            }

            // Trigger UI update
            if (app.canvas) {
                app.canvas.setDirty(true);
            }
        },

        generateWaveformData: async function() {
            // Fallback: Generate demo waveform if backend data not available
            const samples = 2000;
            this.waveformData = [];
            for (let i = 0; i < samples; i++) {
                const t = i / samples;
                // Generate a simple waveform pattern for demo
                this.waveformData.push(
                    Math.sin(t * Math.PI * 4) * 0.8 * Math.exp(-t * 2)
                );
            }
        },

        clearAudio: function() {
            console.log('[Absynth Audio Preview] Clearing audio state');

            // Stop playback if playing
            if (this.isPlaying && this.audioElement) {
                this.audioElement.pause();
                this.isPlaying = false;
                this.stopAnimationLoop();
            }

            // Reset all audio state
            this.audioPath = null;
            this.isAudioReady = false;
            this.currentTime = 0;
            this.duration = 0;
            this.waveformData = null;
            this.loopRegion = null;
            this.isLooping = false;

            // Clear audio element source
            if (this.audioElement) {
                this.audioElement.src = "";
                this.audioElement.load();
            }

            // Trigger UI update
            if (app.canvas) {
                app.canvas.setDirty(true);
            }
        },

        mouse: function(event, pos, node) {
            const nodeX = pos[0];
            const nodeY = pos[1];

            if (event.type === "pointerdown" || event.type === "mousedown" || !event.type) {
                // Check button clicks FIRST (they have priority over waveform)
                if (this.playButton && this.isInsideButton(nodeX, nodeY, this.playButton)) {
                    this.togglePlay();
                    return true;
                }

                if (this.stopButton && this.isInsideButton(nodeX, nodeY, this.stopButton)) {
                    this.stop();
                    return true;
                }

                if (this.loopButton && this.isInsideButton(nodeX, nodeY, this.loopButton)) {
                    this.toggleLoop();
                    return true;
                }

                if (this.downloadButton && this.isInsideButton(nodeX, nodeY, this.downloadButton)) {
                    this.download();
                    return true;
                }

                // Check waveform click (start drag or seek)
                if (this.waveformBounds && this.isInsideWaveform(nodeX, nodeY)) {
                    // Start drag for region selection
                    this.isDragging = true;
                    this.dragStartX = nodeX;
                    return true;
                }
            }

            if (event.type === "pointermove" || event.type === "mousemove") {
                if (this.isDragging && this.waveformBounds) {
                    // Update region during drag
                    this.updateDragRegion(nodeX);
                    return true;
                }
            }

            if (event.type === "pointerup" || event.type === "mouseup") {
                if (this.isDragging) {
                    this.finalizeDragRegion(nodeX);
                    this.isDragging = false;
                    this.dragStartX = null;
                    return true;
                }
            }

            return false;
        },

        isInsideWaveform: function(localX, localY) {
            if (!this.waveformBounds) return false;
            const bounds = this.waveformBounds;
            return localX >= bounds.x && localX <= bounds.x + bounds.width &&
                   localY >= bounds.y && localY <= bounds.y + bounds.height;
        },

        updateDragRegion: function(currentX) {
            if (!this.dragStartX || !this.waveformBounds || this.duration <= 0) return;

            // Calculate times from X positions
            const startX = Math.min(this.dragStartX, currentX);
            const endX = Math.max(this.dragStartX, currentX);

            const startProgress = (startX - this.waveformBounds.x) / this.waveformBounds.width;
            const endProgress = (endX - this.waveformBounds.x) / this.waveformBounds.width;

            const startTime = Math.max(0, Math.min(this.duration, startProgress * this.duration));
            const endTime = Math.max(0, Math.min(this.duration, endProgress * this.duration));

            // Temporarily set region for visual feedback
            this.loopRegion = {
                start: startTime,
                end: endTime
            };

            // Trigger redraw
            if (app.canvas) {
                app.canvas.setDirty(true);
            }
        },

        finalizeDragRegion: function(endX) {
            if (!this.dragStartX || !this.waveformBounds || this.duration <= 0) return;

            const dragDistance = Math.abs(endX - this.dragStartX);

            // If drag was very short (< 5px), treat as simple seek click
            if (dragDistance < 5) {
                this.loopRegion = null;
                this.seekToPosition(this.dragStartX);
                return;
            }

            // Otherwise, finalize the loop region
            const startX = Math.min(this.dragStartX, endX);
            const endXClamped = Math.max(this.dragStartX, endX);

            const startProgress = (startX - this.waveformBounds.x) / this.waveformBounds.width;
            const endProgress = (endXClamped - this.waveformBounds.x) / this.waveformBounds.width;

            const startTime = Math.max(0, Math.min(this.duration, startProgress * this.duration));
            const endTime = Math.max(0, Math.min(this.duration, endProgress * this.duration));

            this.loopRegion = {
                start: startTime,
                end: endTime
            };

            // Auto-enable loop if region is set
            if (!this.isLooping) {
                this.toggleLoop();
            }

            console.log(`[Absynth Audio Preview] Loop region set: ${startTime.toFixed(2)}s - ${endTime.toFixed(2)}s`);

            // Trigger redraw
            if (app.canvas) {
                app.canvas.setDirty(true);
            }
        },

        seekToPosition: function(localX) {
            if (!this.audioElement || !this.waveformBounds || this.duration <= 0) return;

            // Calculate click position relative to waveform
            const clickX = localX - this.waveformBounds.x;
            const progress = clickX / this.waveformBounds.width;

            // Clamp to 0-1
            const clampedProgress = Math.max(0, Math.min(1, progress));

            // Set audio position
            const newTime = clampedProgress * this.duration;
            this.audioElement.currentTime = newTime;
            this.currentTime = newTime;

            // Trigger redraw to show new position
            if (app.canvas) {
                app.canvas.setDirty(true);
            }
        },

        isInsideButton: function(localX, localY, button) {
            return localX >= button.x && localX <= button.x + button.width &&
                   localY >= button.y && localY <= button.y + button.height;
        },

        togglePlay: function() {
            // Check if we have audio loaded
            if (!this.audioPath || this.audioPath === "") {
                console.log('[Absynth Audio Preview] No audio loaded');
                return;
            }

            if (!this.audioElement) {
                console.log('[Absynth Audio Preview] No audio element');
                return;
            }

            // If audio isn't ready yet, try to force it
            if (!this.isAudioReady) {
                console.log('[Absynth Audio Preview] Audio not ready, forcing load...');
                this.audioElement.load();
                // Still try to play - browser will handle buffering
            }

            if (this.isPlaying) {
                this.audioElement.pause();
                this.isPlaying = false;
                this.stopAnimationLoop();
                if (app.canvas) {
                    app.canvas.setDirty(true);
                }
            } else {
                // If loop region is set and we're at the end or before the region, start from region start
                if (this.loopRegion && this.isLooping) {
                    if (this.currentTime < this.loopRegion.start || this.currentTime >= this.loopRegion.end) {
                        this.audioElement.currentTime = this.loopRegion.start;
                        this.currentTime = this.loopRegion.start;
                    }
                }

                // Play immediately - browser will buffer if needed
                const playPromise = this.audioElement.play();
                if (playPromise !== undefined) {
                    // Set playing state immediately for instant UI feedback
                    this.isPlaying = true;
                    this.startAnimationLoop();
                    if (app.canvas) {
                        app.canvas.setDirty(true);
                    }

                    playPromise.catch(e => {
                        console.error('[Absynth Audio Preview] Play failed:', e);
                        this.isPlaying = false;
                        this.stopAnimationLoop();
                        if (app.canvas) {
                            app.canvas.setDirty(true);
                        }
                    });
                }
            }
        },

        startAnimationLoop: function() {
            if (this.animationFrameId) return;

            const animate = () => {
                // Trigger redraw
                if (this.isPlaying && app.canvas) {
                    app.canvas.setDirty(true);
                    this.animationFrameId = requestAnimationFrame(animate);
                } else {
                    this.animationFrameId = null;
                }
            };

            this.animationFrameId = requestAnimationFrame(animate);
        },

        stopAnimationLoop: function() {
            if (this.animationFrameId) {
                cancelAnimationFrame(this.animationFrameId);
                this.animationFrameId = null;
            }
        },

        stop: function() {
            if (!this.audioElement) return;

            this.audioElement.pause();
            this.audioElement.currentTime = 0;
            this.currentTime = 0;
            this.isPlaying = false;
            this.stopAnimationLoop();

            // Trigger one final redraw to update UI
            if (app.canvas) {
                app.canvas.setDirty(true);
            }
        },

        toggleLoop: function() {
            this.isLooping = !this.isLooping;

            // Note: We don't use native loop anymore, we handle it manually for regions
            // So we don't set this.audioElement.loop

            // If turning loop off, clear the region
            if (!this.isLooping) {
                this.loopRegion = null;
            }

            // Trigger redraw to update button
            if (app.canvas) {
                app.canvas.setDirty(true);
            }
        },

        download: function() {
            if (!this.audioPath) return;

            const a = document.createElement('a');
            a.href = `/view?filename=${encodeURIComponent(this.audioPath)}`;
            a.download = this.audioPath.split('/').pop() || 'audio.wav';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        },

        computeSize: function(width) {
            return [width, 400];
        }
    };

    return widget;
}
