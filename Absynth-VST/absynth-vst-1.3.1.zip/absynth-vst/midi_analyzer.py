#!/usr/bin/env python3
"""
Comprehensive MIDI Analysis Tool for Trance Melodies
Analyzes 45 trance MIDI files to extract musical DNA patterns
"""

import os
import glob
import json
from collections import defaultdict, Counter
from statistics import mean, mode, median
import mido
from mido import MidiFile
import numpy as np

class MIDIAnalyzer:
    def __init__(self):
        self.note_names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
        self.key_signatures = {
            0: 'C major / A minor',
            1: 'G major / E minor',
            2: 'D major / B minor',
            3: 'A major / F# minor',
            4: 'E major / C# minor',
            5: 'B major / G# minor',
            6: 'F# major / D# minor',
            7: 'C# major / A# minor',
            -1: 'F major / D minor',
            -2: 'Bb major / G minor',
            -3: 'Eb major / C minor',
            -4: 'Ab major / F minor',
            -5: 'Db major / Bb minor',
            -6: 'Gb major / Eb minor',
            -7: 'Cb major / Ab minor'
        }

    def note_to_name(self, note_num):
        """Convert MIDI note number to note name with octave"""
        octave = note_num // 12 - 1
        note = self.note_names[note_num % 12]
        return f"{note}{octave}"

    def note_to_pitch_class(self, note_num):
        """Convert MIDI note to pitch class (0-11)"""
        return note_num % 12

    def calculate_interval(self, note1, note2):
        """Calculate interval in semitones between two notes"""
        return note2 - note1

    def analyze_single_file(self, filepath):
        """Analyze a single MIDI file and return comprehensive data"""
        try:
            mid = MidiFile(filepath)
            analysis = {
                'filename': os.path.basename(filepath),
                'tempo': 120,  # Default
                'time_signature': (4, 4),  # Default
                'key_signature': 0,  # C major default
                'notes': [],
                'note_events': [],
                'durations': [],
                'velocities': [],
                'intervals': [],
                'pitch_classes': [],
                'note_ranges': {'min': 127, 'max': 0},
                'total_ticks': 0,
                'tracks': len(mid.tracks),
                'ticks_per_beat': mid.ticks_per_beat
            }

            # Process all tracks
            current_time = 0
            active_notes = {}  # note_num: start_time

            for track in mid.tracks:
                current_time = 0
                for msg in track:
                    current_time += msg.time

                    if msg.type == 'set_tempo':
                        analysis['tempo'] = mido.tempo2bpm(msg.tempo)
                    elif msg.type == 'time_signature':
                        analysis['time_signature'] = (msg.numerator, msg.denominator)
                    elif msg.type == 'key_signature':
                        analysis['key_signature'] = msg.key
                    elif msg.type == 'note_on' and msg.velocity > 0:
                        active_notes[msg.note] = {
                            'start_time': current_time,
                            'velocity': msg.velocity
                        }
                        analysis['note_events'].append({
                            'type': 'note_on',
                            'note': msg.note,
                            'time': current_time,
                            'velocity': msg.velocity
                        })
                    elif msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0):
                        if msg.note in active_notes:
                            start_info = active_notes[msg.note]
                            duration = current_time - start_info['start_time']

                            note_data = {
                                'note_num': msg.note,
                                'note_name': self.note_to_name(msg.note),
                                'pitch_class': self.note_to_pitch_class(msg.note),
                                'start_time': start_info['start_time'],
                                'duration': duration,
                                'velocity': start_info['velocity']
                            }

                            analysis['notes'].append(note_data)
                            analysis['durations'].append(duration)
                            analysis['velocities'].append(start_info['velocity'])
                            analysis['pitch_classes'].append(self.note_to_pitch_class(msg.note))

                            # Update note range
                            analysis['note_ranges']['min'] = min(analysis['note_ranges']['min'], msg.note)
                            analysis['note_ranges']['max'] = max(analysis['note_ranges']['max'], msg.note)

                            del active_notes[msg.note]

            analysis['total_ticks'] = current_time

            # Calculate intervals between consecutive notes
            if len(analysis['notes']) > 1:
                for i in range(1, len(analysis['notes'])):
                    interval = self.calculate_interval(
                        analysis['notes'][i-1]['note_num'],
                        analysis['notes'][i]['note_num']
                    )
                    analysis['intervals'].append(interval)

            return analysis

        except Exception as e:
            print(f"Error analyzing {filepath}: {str(e)}")
            return None

    def analyze_collection(self, directory_path):
        """Analyze all MIDI files in directory"""
        midi_files = glob.glob(os.path.join(directory_path, "*.mid"))
        midi_files.sort()

        all_analyses = []

        print(f"Found {len(midi_files)} MIDI files to analyze...")

        for i, filepath in enumerate(midi_files):
            print(f"Analyzing {i+1}/{len(midi_files)}: {os.path.basename(filepath)}")
            analysis = self.analyze_single_file(filepath)
            if analysis:
                all_analyses.append(analysis)

        return all_analyses

    def extract_patterns(self, all_analyses):
        """Extract comprehensive musical patterns from all analyses"""
        patterns = {
            'total_files': len(all_analyses),
            'note_statistics': {},
            'interval_statistics': {},
            'rhythm_statistics': {},
            'harmonic_statistics': {},
            'melodic_statistics': {},
            'key_statistics': {},
            'phrase_statistics': {},
            'velocity_statistics': {}
        }

        # Aggregate all data
        all_notes = []
        all_intervals = []
        all_durations = []
        all_velocities = []
        all_pitch_classes = []
        all_tempos = []
        all_keys = []
        all_note_ranges = []

        for analysis in all_analyses:
            all_notes.extend([n['note_num'] for n in analysis['notes']])
            all_intervals.extend(analysis['intervals'])
            all_durations.extend(analysis['durations'])
            all_velocities.extend(analysis['velocities'])
            all_pitch_classes.extend(analysis['pitch_classes'])
            all_tempos.append(analysis['tempo'])
            all_keys.append(analysis['key_signature'])
            if analysis['notes']:
                all_note_ranges.append({
                    'range': analysis['note_ranges']['max'] - analysis['note_ranges']['min'],
                    'min': analysis['note_ranges']['min'],
                    'max': analysis['note_ranges']['max']
                })

        # Note Statistics
        patterns['note_statistics'] = {
            'total_notes': len(all_notes),
            'unique_notes': len(set(all_notes)),
            'most_common_notes': Counter(all_notes).most_common(12),
            'note_range': {
                'overall_min': min(all_notes) if all_notes else 0,
                'overall_max': max(all_notes) if all_notes else 0,
                'average_range': mean([r['range'] for r in all_note_ranges]) if all_note_ranges else 0
            },
            'pitch_class_distribution': Counter(all_pitch_classes).most_common(12)
        }

        # Interval Statistics
        interval_counter = Counter(all_intervals)
        patterns['interval_statistics'] = {
            'total_intervals': len(all_intervals),
            'most_common_intervals': interval_counter.most_common(20),
            'step_vs_leap': {
                'steps': sum(1 for i in all_intervals if abs(i) <= 2),
                'small_leaps': sum(1 for i in all_intervals if 3 <= abs(i) <= 4),
                'large_leaps': sum(1 for i in all_intervals if abs(i) > 4)
            },
            'direction_tendency': {
                'ascending': sum(1 for i in all_intervals if i > 0),
                'descending': sum(1 for i in all_intervals if i < 0),
                'unison': sum(1 for i in all_intervals if i == 0)
            }
        }

        # Rhythm Statistics
        duration_ticks = all_durations
        if duration_ticks:
            patterns['rhythm_statistics'] = {
                'duration_variety': len(set(duration_ticks)),
                'common_durations': Counter(duration_ticks).most_common(10),
                'average_duration': mean(duration_ticks),
                'shortest_note': min(duration_ticks),
                'longest_note': max(duration_ticks)
            }

        # Velocity Statistics
        if all_velocities:
            patterns['velocity_statistics'] = {
                'velocity_range': {
                    'min': min(all_velocities),
                    'max': max(all_velocities),
                    'average': mean(all_velocities)
                },
                'common_velocities': Counter(all_velocities).most_common(10),
                'velocity_variance': np.var(all_velocities) if len(all_velocities) > 1 else 0
            }

        # Key Statistics
        patterns['key_statistics'] = {
            'key_distribution': Counter(all_keys).most_common(),
            'most_common_key': mode(all_keys) if all_keys else 0,
            'key_names': {k: self.key_signatures.get(k, f"Unknown ({k})") for k in set(all_keys)}
        }

        # Tempo Statistics
        if all_tempos:
            patterns['tempo_statistics'] = {
                'tempo_range': {
                    'min': min(all_tempos),
                    'max': max(all_tempos),
                    'average': mean(all_tempos)
                },
                'common_tempos': Counter(all_tempos).most_common(10)
            }

        return patterns

    def generate_report(self, patterns):
        """Generate a comprehensive text report"""
        report = []
        report.append("=" * 80)
        report.append("COMPREHENSIVE TRANCE MIDI ANALYSIS REPORT")
        report.append("=" * 80)
        report.append(f"Total files analyzed: {patterns['total_files']}")
        report.append("")

        # Note Analysis
        report.append("1. NOTE SEQUENCE ANALYSIS")
        report.append("-" * 40)
        note_stats = patterns['note_statistics']
        report.append(f"Total notes analyzed: {note_stats['total_notes']}")
        report.append(f"Unique note values: {note_stats['unique_notes']}")
        report.append(f"Overall note range: {self.note_to_name(note_stats['note_range']['overall_min'])} to {self.note_to_name(note_stats['note_range']['overall_max'])}")
        report.append(f"Average melody range: {note_stats['note_range']['average_range']:.1f} semitones")
        report.append("")
        report.append("Most common notes:")
        for note_num, count in note_stats['most_common_notes']:
            percentage = (count / note_stats['total_notes']) * 100
            report.append(f"  {self.note_to_name(note_num)}: {count} times ({percentage:.1f}%)")
        report.append("")
        report.append("Pitch class distribution:")
        for pitch_class, count in note_stats['pitch_class_distribution']:
            percentage = (count / note_stats['total_notes']) * 100
            report.append(f"  {self.note_names[pitch_class]}: {count} times ({percentage:.1f}%)")
        report.append("")

        # Interval Analysis
        report.append("2. INTERVAL ANALYSIS")
        report.append("-" * 40)
        interval_stats = patterns['interval_statistics']
        report.append(f"Total intervals: {interval_stats['total_intervals']}")
        report.append("")
        report.append("Melodic movement tendencies:")
        direction = interval_stats['direction_tendency']
        total = sum(direction.values())
        if total > 0:
            report.append(f"  Ascending: {direction['ascending']} ({direction['ascending']/total*100:.1f}%)")
            report.append(f"  Descending: {direction['descending']} ({direction['descending']/total*100:.1f}%)")
            report.append(f"  Unison: {direction['unison']} ({direction['unison']/total*100:.1f}%)")
        report.append("")
        report.append("Step vs Leap analysis:")
        step_leap = interval_stats['step_vs_leap']
        total_movement = sum(step_leap.values())
        if total_movement > 0:
            report.append(f"  Steps (1-2 semitones): {step_leap['steps']} ({step_leap['steps']/total_movement*100:.1f}%)")
            report.append(f"  Small leaps (3-4 semitones): {step_leap['small_leaps']} ({step_leap['small_leaps']/total_movement*100:.1f}%)")
            report.append(f"  Large leaps (5+ semitones): {step_leap['large_leaps']} ({step_leap['large_leaps']/total_movement*100:.1f}%)")
        report.append("")
        report.append("Most common intervals:")
        for interval, count in interval_stats['most_common_intervals'][:15]:
            percentage = (count / interval_stats['total_intervals']) * 100
            direction = "up" if interval > 0 else "down" if interval < 0 else "unison"
            report.append(f"  {interval:+3d} semitones ({direction}): {count} times ({percentage:.1f}%)")
        report.append("")

        # Rhythm Analysis
        if 'rhythm_statistics' in patterns:
            report.append("3. RHYTHMIC PATTERN ANALYSIS")
            report.append("-" * 40)
            rhythm_stats = patterns['rhythm_statistics']
            report.append(f"Duration variety: {rhythm_stats['duration_variety']} different note lengths")
            report.append(f"Average note duration: {rhythm_stats['average_duration']:.1f} ticks")
            report.append(f"Shortest note: {rhythm_stats['shortest_note']} ticks")
            report.append(f"Longest note: {rhythm_stats['longest_note']} ticks")
            report.append("")
            report.append("Most common note durations:")
            for duration, count in rhythm_stats['common_durations']:
                report.append(f"  {duration} ticks: {count} times")
            report.append("")

        # Velocity Analysis
        if 'velocity_statistics' in patterns:
            report.append("4. VELOCITY/DYNAMICS ANALYSIS")
            report.append("-" * 40)
            velocity_stats = patterns['velocity_statistics']
            vel_range = velocity_stats['velocity_range']
            report.append(f"Velocity range: {vel_range['min']} - {vel_range['max']} (average: {vel_range['average']:.1f})")
            report.append(f"Velocity variance: {velocity_stats['velocity_variance']:.1f}")
            report.append("")
            report.append("Most common velocities:")
            for velocity, count in velocity_stats['common_velocities']:
                report.append(f"  {velocity}: {count} times")
            report.append("")

        # Key Analysis
        report.append("5. KEY SIGNATURE ANALYSIS")
        report.append("-" * 40)
        key_stats = patterns['key_statistics']
        report.append(f"Most common key: {patterns['key_statistics']['key_names'].get(key_stats['most_common_key'], 'Unknown')}")
        report.append("")
        report.append("Key distribution:")
        for key_sig, count in key_stats['key_distribution']:
            key_name = key_stats['key_names'].get(key_sig, f"Unknown ({key_sig})")
            percentage = (count / patterns['total_files']) * 100
            report.append(f"  {key_name}: {count} files ({percentage:.1f}%)")
        report.append("")

        # Tempo Analysis
        if 'tempo_statistics' in patterns:
            report.append("6. TEMPO ANALYSIS")
            report.append("-" * 40)
            tempo_stats = patterns['tempo_statistics']
            tempo_range = tempo_stats['tempo_range']
            report.append(f"Tempo range: {tempo_range['min']:.1f} - {tempo_range['max']:.1f} BPM (average: {tempo_range['average']:.1f})")
            report.append("")
            report.append("Common tempos:")
            for tempo, count in tempo_stats['common_tempos']:
                report.append(f"  {tempo:.1f} BPM: {count} files")
            report.append("")

        # Musical DNA Summary
        report.append("7. TRANCE MUSICAL DNA SUMMARY")
        report.append("-" * 40)
        report.append("Key characteristics identified:")

        # Analyze patterns for trance-specific traits
        note_stats = patterns['note_statistics']
        interval_stats = patterns['interval_statistics']

        # Common trance characteristics
        if interval_stats['step_vs_leap']['steps'] / sum(interval_stats['step_vs_leap'].values()) > 0.6:
            report.append("  * Predominantly stepwise motion (typical of trance melodies)")

        if note_stats['note_range']['average_range'] > 12:
            report.append("  * Wide melodic range (creates emotional impact)")

        # Most common intervals analysis
        common_intervals = [interval for interval, count in interval_stats['most_common_intervals'][:5]]
        if 1 in common_intervals or -1 in common_intervals:
            report.append("  * Frequent use of semitone steps (creates tension)")

        if 2 in common_intervals or -2 in common_intervals:
            report.append("  * Frequent use of whole tone steps (smooth melodic flow)")

        # Pitch class analysis for trance-common notes
        pitch_distribution = dict(note_stats['pitch_class_distribution'])
        if pitch_distribution.get(0, 0) > 0:  # C
            report.append("  * Frequent use of root notes and stable pitches")

        report.append("")
        report.append("=" * 80)

        return "\n".join(report)

def main():
    # Directory containing the MIDI files
    midi_directory = r"C:\Users\drasko\Downloads\midi\MIDI Klowd - Trance MIDI Melodies 1\TRANCE_MIDI_MELODIES_1\Trance_MIDI_Melodies_1"

    print("Starting comprehensive MIDI analysis...")

    analyzer = MIDIAnalyzer()

    # Analyze all files
    all_analyses = analyzer.analyze_collection(midi_directory)

    if not all_analyses:
        print("No MIDI files could be analyzed!")
        return

    print(f"Successfully analyzed {len(all_analyses)} files")

    # Extract patterns
    print("Extracting musical patterns...")
    patterns = analyzer.extract_patterns(all_analyses)

    # Generate report
    print("Generating comprehensive report...")
    report = analyzer.generate_report(patterns)

    # Save results
    output_dir = os.path.dirname(os.path.abspath(__file__))

    # Save detailed analysis as JSON
    json_file = os.path.join(output_dir, "trance_midi_analysis.json")
    with open(json_file, 'w') as f:
        json.dump({
            'patterns': patterns,
            'individual_analyses': all_analyses
        }, f, indent=2)

    # Save human-readable report
    report_file = os.path.join(output_dir, "trance_midi_report.txt")
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(report)

    print(f"\nAnalysis complete!")
    print(f"Detailed data saved to: {json_file}")
    print(f"Human-readable report saved to: {report_file}")
    print("\n" + "="*80)
    print("REPORT PREVIEW:")
    print("="*80)
    print(report)

if __name__ == "__main__":
    main()