"""
Create valid VST3 preset files following the exact Steinberg VST3 preset format.
Based on analysis of working Serum 2 presets.
"""
import struct
import json
import zstandard as zstd

def create_vst3_preset(
    output_file,
    plugin_classid,
    plugin_name,
    plugin_vendor,
    plugin_category,
    preset_name,
    preset_author="",
    preset_description="",
    component_data=None,
    controller_data=None,
    component_json=None,
    controller_json=None
):
    """
    Create a valid VST3 preset file.

    Args:
        output_file: Path to save the .vstpreset file
        plugin_classid: Plugin class ID as hex string (e.g., "56534558667350736572756D203200" for Serum 2)
        plugin_name: Plugin name (e.g., "Serum 2")
        plugin_vendor: Vendor name (e.g., "Xfer Records")
        plugin_category: Category (e.g., "Instrument|Synth")
        preset_name: Name of the preset
        preset_author: Author of the preset (optional)
        preset_description: Description (optional)
        component_data: Binary component state data (compressed parameters)
        controller_data: Binary controller state data (compressed parameters)
        component_json: Dict with component JSON metadata (will be auto-generated if None)
        controller_json: Dict with controller JSON metadata (will be auto-generated if None)
    """

    # Default empty data if not provided
    if component_data is None:
        component_data = b''
    if controller_data is None:
        controller_data = b''

    # Create component JSON
    if component_json is None:
        component_json = {
            "component": "processor",
            "hash": "5ff6cd1dd68eed398d560c8fedbe5458",  # Default hash
            "product": plugin_name.replace(" ", ""),
            "productVersion": "1.0.0",
            "url": "",
            "vendor": plugin_vendor,
            "version": 7.0
        }

    # Create controller JSON
    if controller_json is None:
        controller_json = {
            "component": "controller",
            "hash": "d74f95ef2c3adc11e1f19011cd6b1c0f",  # Default hash
            "presetAuthor": preset_author,
            "presetDescription": preset_description,
            "presetName": preset_name,
            "product": plugin_name.replace(" ", ""),
            "productVersion": "1.0.0",
            "url": "",
            "vendor": plugin_vendor,
            "version": 7.0
        }

    # Serialize JSONs
    comp_json_bytes = json.dumps(component_json).encode('utf-8')
    cont_json_bytes = json.dumps(controller_json).encode('utf-8')

    # Compress binary data with ZSTD (Serum uses ZSTD compression)
    cctx = zstd.ZstdCompressor(level=3)  # Level 3 is default
    component_data_compressed = cctx.compress(component_data) if component_data else b''
    controller_data_compressed = cctx.compress(controller_data) if controller_data else b''

    # Build Component chunk
    comp_chunk = bytearray()
    comp_chunk.extend(b'XferJson')
    comp_chunk.extend(b'\x00')  # Null terminator
    comp_chunk.extend(struct.pack('<Q', len(comp_json_bytes)))  # JSON size (LITTLE-endian 64-bit)
    comp_chunk.extend(comp_json_bytes)
    # Add binary data header (8 bytes: compressed_size + type)
    comp_chunk.extend(struct.pack('<I', len(component_data_compressed)))  # Compressed size (4 bytes)
    comp_chunk.extend(struct.pack('<I', 2))  # Type field (4 bytes, value=2)
    comp_chunk.extend(component_data_compressed)

    # Build Controller chunk
    cont_chunk = bytearray()
    cont_chunk.extend(b'XferJson')
    cont_chunk.extend(b'\x00')  # Null terminator
    cont_chunk.extend(struct.pack('<Q', len(cont_json_bytes)))  # JSON size (LITTLE-endian 64-bit)
    cont_chunk.extend(cont_json_bytes)
    # Add binary data header (8 bytes: compressed_size + type)
    cont_chunk.extend(struct.pack('<I', len(controller_data_compressed)))  # Compressed size (4 bytes)
    cont_chunk.extend(struct.pack('<I', 2))  # Type field (4 bytes, value=2)
    cont_chunk.extend(controller_data_compressed)

    # Build Info chunk (XML metadata)
    info_xml = f'''<?xml version="1.0" encoding="utf-8"?>
<MetaInfo>
\t<Attribute id="MediaType" value="VstPreset" type="string" flags="writeProtected"/>
\t<Attribute id="PlugInCategory" value="{plugin_category}" type="string" flags="writeProtected"/>
\t<Attribute id="PlugInName" value="{plugin_name}" type="string" flags="writeProtected"/>
\t<Attribute id="PlugInVendor" value="{plugin_vendor}" type="string" flags="writeProtected"/>
</MetaInfo>
'''
    info_chunk = info_xml.encode('utf-8')

    # Build the main file structure
    # We need to calculate List offset first, then build header

    # Calculate where List chunk will be:
    # Header (48 bytes) + Comp chunk + Cont chunk + Info chunk = List offset
    header_size = 48
    list_offset = header_size + len(comp_chunk) + len(cont_chunk) + len(info_chunk)

    output = bytearray()

    # 1. Header (48 bytes total)
    output.extend(b'VST3')  # Magic (4 bytes)
    output.extend(struct.pack('<I', 1))  # Version (4 bytes, little-endian)

    # 2. Class ID (32 bytes - store hex string as ASCII)
    # Working presets store the hex string itself, NOT the decoded bytes!
    classid_section = bytearray(plugin_classid.encode('ascii'))
    # Pad to 32 bytes
    while len(classid_section) < 32:
        classid_section.append(0)
    output.extend(classid_section)

    # 3. Offset to List chunk (8 bytes, little-endian)
    output.extend(struct.pack('<Q', list_offset))

    # Remember where chunks start (after 48 byte header)
    comp_offset = len(output)

    # 4. Component chunk
    output.extend(comp_chunk)
    cont_offset = len(output)

    # 5. Controller chunk
    output.extend(cont_chunk)
    info_offset = len(output)

    # 6. Info chunk
    output.extend(info_chunk)

    # 7. List chunk (chunk directory)
    list_chunk = bytearray()
    list_chunk.extend(b'List')
    list_chunk.extend(struct.pack('<I', 3))  # Number of chunks (little-endian)

    # Add Comp entry
    list_chunk.extend(b'Comp')
    list_chunk.extend(struct.pack('<Q', comp_offset))  # Offset (little-endian 64-bit)
    list_chunk.extend(struct.pack('<Q', len(comp_chunk)))  # Size (little-endian 64-bit)

    # Add Cont entry
    list_chunk.extend(b'Cont')
    list_chunk.extend(struct.pack('<Q', cont_offset))
    list_chunk.extend(struct.pack('<Q', len(cont_chunk)))

    # Add Info entry
    list_chunk.extend(b'Info')
    list_chunk.extend(struct.pack('<Q', info_offset))
    list_chunk.extend(struct.pack('<Q', len(info_chunk)))

    output.extend(list_chunk)

    # Write to file
    with open(output_file, 'wb') as f:
        f.write(output)

    print(f"Created VST3 preset: {output_file}")
    print(f"  Total size: {len(output)} bytes")
    print(f"  Component offset: {comp_offset}, size: {len(comp_chunk)}")
    print(f"  Controller offset: {cont_offset}, size: {len(cont_chunk)}")
    print(f"  Info offset: {info_offset}, size: {len(info_chunk)}")
    print(f"  List offset: {list_offset}, size: {len(list_chunk)}")

    return True


# Test: Create a minimal Serum 2 preset
if __name__ == "__main__":
    output_file = "C:/Users/drasko/Documents/VST3 Presets/Xfer Records/Serum 2/LLM_TEST_MINIMAL.vstpreset"

    # Serum 2 class ID
    serum2_classid = "56534558667350736572756D203200"

    success = create_vst3_preset(
        output_file=output_file,
        plugin_classid=serum2_classid,
        plugin_name="Serum 2",
        plugin_vendor="Xfer Records",
        plugin_category="Instrument|Synth",
        preset_name="LLM Test Preset",
        preset_author="Claude",
        preset_description="Test preset created by AI"
    )

    if success:
        print("\n[SUCCESS] Created test preset! Try loading it in Cubase.")
    else:
        print("\n[FAILED] Could not create preset")
