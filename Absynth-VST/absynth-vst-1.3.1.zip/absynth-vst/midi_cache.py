#!/usr/bin/env python3
"""
MIDI Generation Cache System - Persistent memory for LLM-generated MIDIs
Stores generation history on user's PC to prevent repetitive outputs
"""

import os
import json
import hashlib
import time
from collections import defaultdict
from .midi_analyzer import MIDIAnalyzer


class MIDIGenerationCache:
    """Persistent cache system for tracking MIDI generations"""

    def __init__(self, cache_file="midi_generation_cache.json"):
        self._script_dir = os.path.dirname(os.path.abspath(__file__))
        self.cache_file = os.path.join(self._script_dir, cache_file)
        self.analyzer = MIDIAnalyzer()
        self.cache = self._load_cache()

    def _load_cache(self):
        """Load generation history from disk"""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"[Cache] Warning: Could not load cache: {e}")
                return self._empty_cache()
        return self._empty_cache()

    def _empty_cache(self):
        """Create empty cache structure"""
        return {
            "version": "1.0",
            "created": time.time(),
            "total_generations": 0,
            "generations": [],
            "musical_signatures": {}
        }

    def _save_cache(self):
        """Save cache to user's PC"""
        try:
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.cache, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[Cache] Warning: Could not save cache: {e}")

    def _extract_musical_signature(self, midi_path):
        """Extract musical fingerprint from MIDI file for similarity comparison"""
        try:
            analysis = self.analyzer.analyze_single_file(midi_path)
            if not analysis:
                return None

            # Create a compact signature of the MIDI's musical characteristics
            signature = {
                "note_sequence_hash": self._hash_sequence([n['note_num'] for n in analysis['notes'][:32]]),  # First 32 notes
                "interval_pattern": analysis['intervals'][:20] if len(analysis['intervals']) > 0 else [],
                "pitch_class_distribution": dict([(pc, count) for pc, count in
                    sorted([(pc, analysis['pitch_classes'].count(pc)) for pc in set(analysis['pitch_classes'])],
                           key=lambda x: x[1], reverse=True)[:6]]),
                "note_range": {
                    "min": analysis['note_ranges']['min'],
                    "max": analysis['note_ranges']['max'],
                    "span": analysis['note_ranges']['max'] - analysis['note_ranges']['min']
                },
                "tempo": analysis['tempo'],
                "key": analysis['key_signature'],
                "total_notes": len(analysis['notes']),
                "avg_duration": sum(analysis['durations']) / len(analysis['durations']) if analysis['durations'] else 0,
                "avg_velocity": sum(analysis['velocities']) / len(analysis['velocities']) if analysis['velocities'] else 0,
                "rhythm_variety": len(set(analysis['durations'])) if analysis['durations'] else 0
            }

            return signature

        except Exception as e:
            print(f"[Cache] Warning: Could not extract signature: {e}")
            return None

    def _hash_sequence(self, sequence):
        """Create hash from note sequence"""
        return hashlib.md5(str(sequence).encode()).hexdigest()[:16]

    def add_generation(self, midi_path, prompt, llm_provider, model, temperature, seed, metadata=None):
        """Store new generation in cache"""
        try:
            signature = self._extract_musical_signature(midi_path)

            generation_record = {
                "id": self.cache["total_generations"] + 1,
                "timestamp": time.time(),
                "midi_path": midi_path,
                "filename": os.path.basename(midi_path),
                "prompt": prompt,
                "llm_provider": llm_provider,
                "model": model,
                "temperature": temperature,
                "seed": seed,
                "signature": signature,
                "metadata": metadata or {}
            }

            self.cache["generations"].append(generation_record)
            self.cache["total_generations"] += 1

            # Store signature for quick lookup
            if signature:
                sig_hash = self._hash_sequence(signature.get("interval_pattern", []))
                if sig_hash not in self.cache["musical_signatures"]:
                    self.cache["musical_signatures"][sig_hash] = []
                self.cache["musical_signatures"][sig_hash].append(generation_record["id"])

            self._save_cache()

            print(f"[Cache] ✓ Stored generation #{generation_record['id']}")
            return generation_record["id"]

        except Exception as e:
            print(f"[Cache] Warning: Could not store generation: {e}")
            return None

    def get_recent_generations(self, limit=30):
        """Get recent generations for context"""
        return self.cache["generations"][-limit:] if self.cache["generations"] else []

    def get_total_generations(self):
        """Get total number of generations"""
        return self.cache["total_generations"]

    def calculate_similarity(self, signature1, signature2):
        """Calculate similarity score between two musical signatures (0.0 - 1.0)"""
        if not signature1 or not signature2:
            return 0.0

        try:
            similarity_scores = []

            # Compare interval patterns (most important)
            intervals1 = signature1.get("interval_pattern", [])
            intervals2 = signature2.get("interval_pattern", [])
            if intervals1 and intervals2:
                # Compare first N intervals
                n = min(len(intervals1), len(intervals2), 15)
                matching = sum(1 for i in range(n) if intervals1[i] == intervals2[i])
                interval_similarity = matching / n if n > 0 else 0
                similarity_scores.append(interval_similarity * 3.0)  # Weight heavily

            # Compare pitch class distribution
            pc_dist1 = signature1.get("pitch_class_distribution", {})
            pc_dist2 = signature2.get("pitch_class_distribution", {})
            if pc_dist1 and pc_dist2:
                common_pcs = set(pc_dist1.keys()) & set(pc_dist2.keys())
                pc_similarity = len(common_pcs) / max(len(pc_dist1), len(pc_dist2)) if pc_dist1 or pc_dist2 else 0
                similarity_scores.append(pc_similarity * 1.5)

            # Compare note range
            range1 = signature1.get("note_range", {})
            range2 = signature2.get("note_range", {})
            if range1 and range2:
                span_diff = abs(range1.get("span", 0) - range2.get("span", 0))
                range_similarity = max(0, 1.0 - (span_diff / 24))  # 24 semitones = 2 octaves
                similarity_scores.append(range_similarity * 0.5)

            # Compare tempo
            tempo1 = signature1.get("tempo", 120)
            tempo2 = signature2.get("tempo", 120)
            tempo_diff = abs(tempo1 - tempo2)
            tempo_similarity = max(0, 1.0 - (tempo_diff / 60))  # 60 BPM difference
            similarity_scores.append(tempo_similarity * 0.3)

            # Compare rhythm variety
            rhythm1 = signature1.get("rhythm_variety", 0)
            rhythm2 = signature2.get("rhythm_variety", 0)
            if rhythm1 > 0 and rhythm2 > 0:
                rhythm_similarity = min(rhythm1, rhythm2) / max(rhythm1, rhythm2)
                similarity_scores.append(rhythm_similarity * 0.5)

            # Calculate weighted average
            total_similarity = sum(similarity_scores) / sum([3.0, 1.5, 0.5, 0.3, 0.5])

            return min(1.0, total_similarity)

        except Exception as e:
            print(f"[Cache] Warning: Could not calculate similarity: {e}")
            return 0.0

    def find_similar_generations(self, midi_path, threshold=0.7, limit=10):
        """Find similar MIDIs in cache history"""
        try:
            current_signature = self._extract_musical_signature(midi_path)
            if not current_signature:
                return []

            similar = []

            for gen in self.cache["generations"]:
                if gen.get("signature"):
                    similarity = self.calculate_similarity(current_signature, gen["signature"])
                    if similarity >= threshold:
                        similar.append({
                            "generation": gen,
                            "similarity": similarity
                        })

            # Sort by similarity (highest first)
            similar.sort(key=lambda x: x["similarity"], reverse=True)

            return similar[:limit]

        except Exception as e:
            print(f"[Cache] Warning: Could not find similar: {e}")
            return []

    def get_diversity_report(self):
        """Generate report on musical diversity in cache"""
        if not self.cache["generations"]:
            return "No generations in cache yet."

        total = len(self.cache["generations"])

        # Analyze diversity
        unique_keys = set()
        unique_tempos = set()
        unique_patterns = set()

        for gen in self.cache["generations"]:
            sig = gen.get("signature")
            if sig:
                unique_keys.add(sig.get("key", 0))
                unique_tempos.add(int(sig.get("tempo", 120)))
                pattern_hash = self._hash_sequence(sig.get("interval_pattern", []))
                unique_patterns.add(pattern_hash)

        diversity_score = len(unique_patterns) / total if total > 0 else 0

        report = f"""
╔════════════════════════════════════════╗
║      MIDI GENERATION DIVERSITY         ║
╚════════════════════════════════════════╝

Total Generations: {total}
Unique Patterns: {len(unique_patterns)}
Unique Keys: {len(unique_keys)}
Unique Tempos: {len(unique_tempos)}

Diversity Score: {diversity_score:.1%}
"""

        if diversity_score < 0.5:
            report += "\n⚠️  Low diversity detected - generations may be repetitive"
        elif diversity_score > 0.8:
            report += "\n✓ Excellent diversity - wide variety of patterns"
        else:
            report += "\n✓ Good diversity - varied outputs"

        return report

    def create_anti_repetition_prompt(self, limit=20):
        """Create prompt context from recent generations to avoid repetition"""
        recent = self.get_recent_generations(limit)

        if not recent:
            return ""

        context_parts = [
            "\n=== IMPORTANT: AVOID REPETITION ===",
            f"You have generated {len(recent)} MIDIs recently. Create something DIFFERENT from these:",
            ""
        ]

        for i, gen in enumerate(recent[-10:], 1):  # Last 10 only
            sig = gen.get("signature")
            if sig:
                intervals = sig.get("interval_pattern", [])[:8]
                pitch_classes = list(sig.get("pitch_class_distribution", {}).keys())[:4]

                context_parts.append(
                    f"{i}. Previous: intervals={intervals}, "
                    f"pitches={pitch_classes}, "
                    f"tempo={sig.get('tempo', 120):.0f}"
                )

        context_parts.extend([
            "",
            "AVOID:",
            "- Using the same interval patterns as above",
            "- Starting with the same notes",
            "- Using identical rhythmic patterns",
            "- Repeating the same melodic contours",
            "",
            "INSTEAD:",
            "- Try DIFFERENT starting notes",
            "- Use DIFFERENT interval jumps and patterns",
            "- Vary the rhythm and note durations",
            "- Create a UNIQUE melodic shape",
            "=================================\n"
        ])

        return "\n".join(context_parts)

    def clear_cache(self):
        """Clear all cache data (use with caution!)"""
        self.cache = self._empty_cache()
        self._save_cache()
        print("[Cache] ✓ Cache cleared")

    def get_cache_stats(self):
        """Get cache statistics"""
        return {
            "total_generations": self.cache["total_generations"],
            "cache_size_kb": os.path.getsize(self.cache_file) / 1024 if os.path.exists(self.cache_file) else 0,
            "oldest_generation": self.cache["generations"][0]["timestamp"] if self.cache["generations"] else None,
            "newest_generation": self.cache["generations"][-1]["timestamp"] if self.cache["generations"] else None,
            "unique_patterns": len(self.cache["musical_signatures"])
        }


# Example usage
if __name__ == "__main__":
    cache = MIDIGenerationCache()

    print("=== MIDI Generation Cache Test ===\n")

    stats = cache.get_cache_stats()
    print(f"Total generations: {stats['total_generations']}")
    print(f"Cache size: {stats['cache_size_kb']:.2f} KB")
    print(f"Unique patterns: {stats['unique_patterns']}")

    print("\n" + cache.get_diversity_report())

    # Test anti-repetition prompt
    anti_rep_prompt = cache.create_anti_repetition_prompt()
    if anti_rep_prompt:
        print("\n=== Anti-Repetition Context ===")
        print(anti_rep_prompt[:500] + "..." if len(anti_rep_prompt) > 500 else anti_rep_prompt)
